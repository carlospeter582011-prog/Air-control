import 'package:flutter_test/flutter_test.dart';
import 'package:air_control/native.dart';

void main() {
  test('every default-mapped action id exists in kActions', () {
    const defaults = [
      'TAP', 'DOUBLE_TAP', 'LONG_PRESS', 'DRAG', 'SCROLL_DOWN', 'SCROLL_UP', 'BACK', 'RECENTS',
      'HOME', 'NONE', 'PLAY_PAUSE', 'NOTIFICATIONS', 'QUICK_SETTINGS', 'NEXT_TRACK', 'PREV_TRACK',
      'VOLUME_UP', 'VOLUME_DOWN',
      'SOCIAL_LIKE', 'SOCIAL_NEXT', 'SOCIAL_PREV', 'SOCIAL_PLAY_PAUSE', 'SOCIAL_COMMENTS', 'SOCIAL_SHARE',
      'SOCIAL_COMMENTS_SCROLL_DOWN', 'SOCIAL_COMMENTS_SCROLL_UP', 'TOGGLE_VIDEO_STYLE', 'TOGGLE_SOCIAL_MODE',
    ];
    final ids = kActions.map((a) => a.id).toSet();
    for (final d in defaults) {
      expect(ids.contains(d), true, reason: d);
    }
  });

  test('pausing no longer exists as an action', () {
    expect(kActions.any((a) => a.id == 'PAUSE_TOGGLE'), false);
  });

  test('gesture ids are unique and every gesture has a group', () {
    final ids = kGestures.map((g) => g.id).toList();
    expect(ids.toSet().length, ids.length);
    expect(kGestures.every((g) => g.group.isNotEmpty), true);
    expect(ids.contains('pinch_middle') && ids.contains('rock_hold') && ids.contains('three_hold'), true);
  });

  test('action ids are unique', () {
    final ids = kActions.map((a) => a.id).toList();
    expect(ids.toSet().length, ids.length);
  });

  test('status parsing is tolerant', () {
    final s = TrackingStatus.fromMap({'running': true, 'fps': 18, 'social': true});
    expect(s.running, true);
    expect(s.gated, false);
    expect(s.social, true);
    expect(s.fps, 18);
    expect(s.videoStyle, 'short');
  });
}
