import 'package:flutter_test/flutter_test.dart';
import 'package:air_control/native.dart';

void main() {
  test('every default-mapped action id exists in kActions', () {
    const defaults = [
      'TAP', 'DOUBLE_TAP', 'LONG_PRESS', 'DRAG', 'SCROLL_DOWN', 'SCROLL_UP', 'BACK', 'RECENTS',
      'HOME', 'PAUSE_TOGGLE', 'PLAY_PAUSE', 'VOLUME_UP', 'VOLUME_DOWN',
    ];
    final ids = kActions.map((a) => a.id).toSet();
    for (final d in defaults) {
      expect(ids.contains(d), true, reason: d);
    }
  });

  test('gesture ids are unique', () {
    final ids = kGestures.map((g) => g.id).toList();
    expect(ids.toSet().length, ids.length);
  });

  test('status parsing is tolerant', () {
    final s = TrackingStatus.fromMap({'running': true, 'fps': 18});
    expect(s.running, true);
    expect(s.paused, false);
    expect(s.fps, 18);
  });
}
