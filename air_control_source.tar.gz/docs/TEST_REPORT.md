# Air Control 1.1.0 — Test report

Written 2026-10-24. **No APK has been built and nothing has run on a phone or emulator.**
The sandbox that produced this source could not reach pub.dev, dl.google.com, Google Maven,
Maven Central or the Gradle distribution server (all refused by the network policy), so Flutter,
the Android SDK and Gradle could not be installed. Only GitHub was reachable.

## Passed (actually executed)

| Item | How |
|---|---|
| `GestureEngine.kt` + `Config.kt` compile (Kotlin 2.0.21) | `kotlinc` against small stubs for `org.json`, `android.content.Context`, JUnit |
| 16 gesture-engine unit tests pass | held pinch never repeats; tap / double tap; drag released when hand lost; volume repeats while held and stops when the pose changes or the hand disappears; one-shot holds fire once; rock / three-finger / call / little-finger poses; middle-finger pinch; a fist does not trigger finger pinches; same action on many gestures; Social mapping; hand loss never pauses |
| `tools/build.sh` shell syntax | `bash -n` |
| Manifest, accessibility config, strings are well-formed XML | parsed with Python |
| CI workflow is valid YAML | parsed with Python |

The unit tests used stubs, not the real `org.json`, so they validate logic only.

## Not verified (written but never compiled or run)

- `AirAccessibilityService.kt`, `TrackingService.kt`, `MainActivity.kt`, `Bridge.kt`: need the Android SDK to compile. They use CameraX 1.3.4 and MediaPipe tasks-vision 0.10.14 APIs from memory of the documentation. **Expect to fix a few compile errors on the first real build.**
- All Dart code (`lib/`, `test/`): never run through `flutter analyze` or `flutter test`.
- `android_overlay/app_build.gradle.kts` and the overlay approach against whatever Flutter template version you have.
- MediaPipe model loading, camera start, landmark accuracy, FPS on a Galaxy A23.
- Every Android-side behaviour: accessibility activation, tap/swipe/drag injection, global actions, media keys, brightness, pointer overlay, foreground-service camera on Android 14+, notification buttons, Samsung battery behaviour, permission wizard detection.
- APK size, package metadata, install and launch.

## Manual device checklist (run after you build)

1. Install debug APK; app opens; Setup shows camera/accessibility/notifications as not granted.
2. Grant camera → Setup flips to Granted on return. Deny → stays not granted.
3. Enable accessibility (use "Allow restricted settings" if greyed) → Granted.
4. Live test: hand outline appears, fps shown, "No hand" when you leave view. Test mode sends no touches.
5. Calibrate four corners; pointer reaches all screen corners with Start tracking.
6. Open a browser: pinch taps a link; pinch-hold long-presses; pinch-move drags; palm sweep scrolls.
7. Back / Home / Recents / notification shade / volume / play-pause gestures.
8. Fist hold pauses; notification Pause/Resume/Stop work; Stop turns off the camera indicator.
9. Cover the camera or leave the frame: held drag releases within the "Release if hand lost" time.
10. Revoke accessibility while running: status shows the reason; no crash.
11. Lock screen / switch apps for 10 minutes on the A23: note whether Android stops the service and that the reason is shown.
