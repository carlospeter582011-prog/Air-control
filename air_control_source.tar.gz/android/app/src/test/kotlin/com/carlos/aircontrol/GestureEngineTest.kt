package com.carlos.aircontrol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * JVM unit tests for GestureEngine. Run with: ./gradlew :app:testDebugUnitTest
 * Note: org.json is stubbed on the JVM, so tests build the engine through TestConfig below
 * using Robolectric-free defaults (see build script: testOptions.unitTests.returnDefaultValues=true and
 * org.json:json test dependency).
 */
class GestureEngineTest {

    private class Rec : GestureEngine.Output {
        val actions = mutableListOf<String>()
        var drags = 0; var dragEnds = 0
        var paused = false
        override fun pointer(x: Float, y: Float) {}
        override fun action(action: String, gesture: String, x: Float, y: Float) { actions += action }
        override fun dragStart(x: Float, y: Float) { drags++ }
        override fun dragMove(x: Float, y: Float) {}
        override fun dragEnd(x: Float, y: Float) { dragEnds++ }
        override fun pauseChanged(paused: Boolean) { this.paused = paused }
        override fun info(pose: String, pinchRatio: Float) {}
    }

    /** Index finger extended, other fingers curled; thumb tip distance to index tip is [pinchGap]. */
    private fun hand(tipX: Float = 0.5f, tipY: Float = 0.4f, pinchGap: Float = 0.2f, palmX: Float = 0.5f, open: Boolean = false, mcpX: Float = 0.45f): FloatArray {
        val lm = FloatArray(42)
        fun set(i: Int, x: Float, y: Float) { lm[2 * i] = x; lm[2 * i + 1] = y }
        set(0, 0.5f, 0.9f)               // wrist
        set(9, palmX, 0.6f)              // middle MCP => palm size 0.3
        set(5, mcpX, 0.62f); set(17, 0.58f, 0.66f)
        set(3, 0.42f, 0.7f)
        set(4, tipX - pinchGap, tipY + 0.02f)
        // index
        set(6, 0.45f, 0.55f); set(8, tipX, tipY)
        // middle
        set(10, 0.5f, 0.56f); set(12, 0.5f, if (open) 0.3f else 0.62f)
        set(14, 0.54f, 0.57f); set(16, 0.54f, if (open) 0.3f else 0.64f)
        set(18, 0.58f, 0.6f); set(20, 0.58f, if (open) 0.32f else 0.7f)
        return lm
    }

    private fun cfg() = Config(org.json.JSONObject())

    @Test fun holdingPinchFiresNothingRepeatedly() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = 1000L
        repeat(10) { e.onHand(hand(), t); t += 50 }
        repeat(60) { e.onHand(hand(pinchGap = 0.0f), t); t += 50 } // held 3 s, drags none
        assertEquals(1, rec.actions.count { it == "LONG_PRESS" })
        assertFalse(rec.actions.contains("TAP"))
    }

    @Test fun shortPinchIsSingleTapAfterDoubleWindow() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = 1000L
        repeat(10) { e.onHand(hand(), t); t += 50 }
        repeat(3) { e.onHand(hand(pinchGap = 0.0f), t); t += 50 }
        repeat(20) { e.onHand(hand(), t); t += 50 }
        assertEquals(listOf("TAP"), rec.actions)
    }

    @Test fun twoQuickPinchesAreOneDoubleTap() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = 1000L
        repeat(10) { e.onHand(hand(), t); t += 40 }
        repeat(2) {
            repeat(2) { e.onHand(hand(pinchGap = 0.0f), t); t += 40 }
            repeat(2) { e.onHand(hand(), t); t += 40 }
        }
        repeat(20) { e.onHand(hand(), t); t += 40 }
        assertEquals(listOf("DOUBLE_TAP"), rec.actions)
    }

    @Test fun losingHandReleasesDrag() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = 1000L
        repeat(10) { e.onHand(hand(), t); t += 50 }
        e.onHand(hand(pinchGap = 0.0f), t); t += 50
        // drag: the whole hand (knuckle) moves while pinching
        for (k in 1..12) { e.onHand(hand(pinchGap = 0.0f, tipX = 0.5f + 0.02f * k, mcpX = 0.45f + 0.02f * k), t); t += 50 }
        assertTrue(rec.drags >= 1)
        e.onNoHand(t + 100)
        e.onNoHand(t + 900)
        assertEquals(rec.drags, rec.dragEnds)
    }

    @Test fun pausedEngineSendsNoActions() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        e.setPaused(true)
        var t = 1000L
        repeat(10) { e.onHand(hand(), t); t += 50 }
        repeat(3) { e.onHand(hand(pinchGap = 0.0f), t); t += 50 }
        repeat(20) { e.onHand(hand(), t); t += 50 }
        assertTrue(rec.actions.isEmpty())
    }
}
