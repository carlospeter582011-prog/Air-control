package com.carlos.aircontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Cross-app touch injection and global actions.
 * Declared with canPerformGestures=true and NO event types / no window content retrieval, so it never
 * reads screen contents. The pointer dot is an accessibility overlay window, which needs no extra
 * "draw over other apps" permission.
 */
class AirAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: AirAccessibilityService? = null
        fun isEnabled() = instance != null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var dot: View? = null
    private var dotParams: WindowManager.LayoutParams? = null
    private val dotSize = 56

    // drag state
    private var dragStroke: GestureDescription.StrokeDescription? = null
    private var dragLastX = 0f
    private var dragLastY = 0f
    private var dragTargetX = 0f
    private var dragTargetY = 0f
    private var dragBusy = false
    private var dragActive = false

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Bridge.emitStatus()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* intentionally ignored */ }
    override fun onInterrupt() { cancelDrag() }

    override fun onUnbind(intent: Intent?): Boolean {
        cancelDrag(); removeDot(); instance = null
        Bridge.reason = "Accessibility access was turned off"
        Bridge.emitStatus()
        return super.onUnbind(intent)
    }

    override fun onDestroy() { cancelDrag(); removeDot(); instance = null; super.onDestroy() }

    fun screenSize(): Pair<Float, Float> {
        val m = resources.displayMetrics
        return Pair(m.widthPixels.toFloat(), m.heightPixels.toFloat())
    }

    // ------------------------------------------------------------------ pointer dot

    fun showDot(show: Boolean) = main.post {
        if (!show) { removeDot(); return@post }
        if (dot != null) return@post
        try {
            val v = View(this)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.argb(190, 0, 200, 255))
            bg.setStroke(4, Color.WHITE)
            v.background = bg
            val p = WindowManager.LayoutParams(
                dotSize, dotSize,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.START
            wm?.addView(v, p)
            dot = v; dotParams = p
        } catch (e: Exception) { dot = null }
    }

    fun moveDot(x: Float, y: Float) = main.post {
        val v = dot ?: return@post
        val p = dotParams ?: return@post
        p.x = (x - dotSize / 2).toInt(); p.y = (y - dotSize / 2).toInt()
        try { wm?.updateViewLayout(v, p) } catch (_: Exception) { }
    }

    fun flashDot() = main.post {
        val v = dot ?: return@post
        v.animate().cancel()
        v.scaleX = 1.6f; v.scaleY = 1.6f
        v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
    }

    private fun removeDot() {
        val v = dot ?: return
        try { wm?.removeView(v) } catch (_: Exception) { }
        dot = null
    }

    // ------------------------------------------------------------------ touch injection

    private fun stroke(path: Path, start: Long, dur: Long, cont: Boolean = false) =
        GestureDescription.StrokeDescription(path, start, dur.coerceAtLeast(1), cont)

    private fun dispatch(g: GestureDescription, onDone: (() -> Unit)? = null): Boolean {
        return dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { onDone?.invoke() }
            override fun onCancelled(d: GestureDescription?) { onDone?.invoke() }
        }, null)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.Builder().addStroke(stroke(p, 0, 50)).build())
    }

    fun doubleTap(x: Float, y: Float): Boolean {
        val p1 = Path().apply { moveTo(x, y) }
        val p2 = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.Builder()
            .addStroke(stroke(p1, 0, 40)).addStroke(stroke(p2, 140, 40)).build())
    }

    fun longPress(x: Float, y: Float, ms: Long = 700): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.Builder().addStroke(stroke(p, 0, ms)).build())
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 280): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return dispatch(GestureDescription.Builder().addStroke(stroke(p, 0, ms)).build())
    }

    /** dir: "up" scrolls content up (finger moves up) etc. amount is a screen fraction. */
    fun scroll(dir: String, amount: Float): Boolean {
        val (w, h) = screenSize()
        val cx = w / 2; val cy = h / 2
        val dy = h * 0.3f * amount; val dx = w * 0.3f * amount
        return when (dir) {
            "up" -> swipe(cx, cy + dy, cx, cy - dy)
            "down" -> swipe(cx, cy - dy, cx, cy + dy)
            "left" -> swipe(cx + dx, cy, cx - dx, cy)
            "right" -> swipe(cx - dx, cy, cx + dx, cy)
            else -> false
        }
    }

    // ---- drag via continued strokes (API 26+; minSdk is 26)

    @Synchronized fun dragStart(x: Float, y: Float) {
        if (dragActive) cancelDrag()
        val p = Path().apply { moveTo(x, y) }
        val s = stroke(p, 0, 60, true)
        dragStroke = s; dragLastX = x; dragLastY = y
        dragTargetX = x; dragTargetY = y
        dragActive = true; dragBusy = true
        dispatch(GestureDescription.Builder().addStroke(s).build()) { onDragStep() }
    }

    @Synchronized fun dragMove(x: Float, y: Float) {
        if (!dragActive) return
        dragTargetX = x; dragTargetY = y
        if (!dragBusy) pumpDrag(false)
    }

    @Synchronized fun dragEnd(x: Float, y: Float) {
        if (!dragActive) return
        dragTargetX = x; dragTargetY = y
        if (dragBusy) { dragActive = false; pendingEnd = true } else pumpDrag(true)
    }

    private var pendingEnd = false

    @Synchronized private fun onDragStep() {
        dragBusy = false
        if (pendingEnd) { pendingEnd = false; dragActive = true; pumpDrag(true); return }
        if (dragActive && (dragTargetX != dragLastX || dragTargetY != dragLastY)) pumpDrag(false)
    }

    private fun pumpDrag(last: Boolean) {
        val prev = dragStroke ?: run { dragActive = false; return }
        val p = Path().apply { moveTo(dragLastX, dragLastY); lineTo(dragTargetX, dragTargetY) }
        val next = try { prev.continueStroke(p, 0, 50, !last) } catch (e: Exception) { null }
        if (next == null) { dragActive = false; dragStroke = null; return }
        dragLastX = dragTargetX; dragLastY = dragTargetY
        dragStroke = if (last) null else next
        if (last) dragActive = false
        dragBusy = true
        val ok = dispatch(GestureDescription.Builder().addStroke(next).build()) { onDragStep() }
        if (!ok) { dragBusy = false; if (last) dragActive = false }
    }

    /** Releases any held virtual touch immediately. Safe to call at any time. */
    @Synchronized fun cancelDrag() {
        if (dragStroke != null && dragActive) {
            try {
                val p = Path().apply { moveTo(dragLastX, dragLastY) }
                val end = dragStroke!!.continueStroke(p, 0, 1, false)
                dispatchGesture(GestureDescription.Builder().addStroke(end).build(), null, null)
            } catch (_: Exception) { }
        }
        dragStroke = null; dragActive = false; dragBusy = false; pendingEnd = false
    }

    // ------------------------------------------------------------------ high-level actions

    /** Returns null on success or a short human-readable reason on failure. */
    fun perform(action: String, x: Float, y: Float, cfg: Config): String? {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (action) {
            "NONE" -> null
            "TAP" -> if (tap(x, y)) { if (cfg.b("clickFeedback", true)) flashDot(); null } else "Tap was rejected by Android"
            "DOUBLE_TAP" -> if (doubleTap(x, y)) { if (cfg.b("clickFeedback", true)) flashDot(); null } else "Double tap rejected"
            "LONG_PRESS" -> if (longPress(x, y)) { if (cfg.b("clickFeedback", true)) flashDot(); null } else "Long press rejected"
            "DRAG" -> null // handled by dragStart/Move/End
            "SCROLL_UP" -> ok(scroll("up", cfg.f("scrollSpeed", 1f).coerceIn(0.3f, 2.5f)))
            "SCROLL_DOWN" -> ok(scroll("down", cfg.f("scrollSpeed", 1f).coerceIn(0.3f, 2.5f)))
            "SCROLL_LEFT" -> ok(scroll("left", cfg.f("scrollSpeed", 1f).coerceIn(0.3f, 2.5f)))
            "SCROLL_RIGHT" -> ok(scroll("right", cfg.f("scrollSpeed", 1f).coerceIn(0.3f, 2.5f)))
            "SWIPE_UP" -> { val (w, h) = screenSize(); ok(swipe(w / 2, h * 0.7f, w / 2, h * 0.3f)) }
            "SWIPE_DOWN" -> { val (w, h) = screenSize(); ok(swipe(w / 2, h * 0.3f, w / 2, h * 0.7f)) }
            "SWIPE_LEFT" -> { val (w, h) = screenSize(); ok(swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)) }
            "SWIPE_RIGHT" -> { val (w, h) = screenSize(); ok(swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)) }
            "BACK" -> ok(performGlobalAction(GLOBAL_ACTION_BACK))
            "HOME" -> ok(performGlobalAction(GLOBAL_ACTION_HOME))
            "RECENTS" -> ok(performGlobalAction(GLOBAL_ACTION_RECENTS))
            "NOTIFICATIONS" -> ok(performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS))
            "QUICK_SETTINGS" -> ok(performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS))
            "POWER_DIALOG" -> ok(performGlobalAction(GLOBAL_ACTION_POWER_DIALOG))
            "LOCK_SCREEN" ->
                if (Build.VERSION.SDK_INT >= 28) ok(performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN))
                else "Lock screen needs Android 9+"
            "SCREENSHOT" ->
                if (Build.VERSION.SDK_INT >= 28) ok(performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT))
                else "Screenshot needs Android 9+"
            "VOLUME_UP" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); null }
            "VOLUME_DOWN" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); null }
            "VOLUME_PANEL" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI); null }
            "MUTE_TOGGLE" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI); null }
            "PLAY_PAUSE" -> media(am, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            "NEXT_TRACK" -> media(am, KeyEvent.KEYCODE_MEDIA_NEXT)
            "PREV_TRACK" -> media(am, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "BRIGHTNESS_UP" -> brightness(+0.1f)
            "BRIGHTNESS_DOWN" -> brightness(-0.1f)
            "OPEN_SETTINGS" -> launch(Intent(Settings.ACTION_SETTINGS))
            "OPEN_DISPLAY_SETTINGS" -> launch(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            "OPEN_ACCESSIBILITY_SETTINGS" -> launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "LAUNCH_APP" -> {
                val pkg = cfg.s("appPackage", "")
                val i = if (pkg.isEmpty()) null else packageManager.getLaunchIntentForPackage(pkg)
                if (i == null) "No app selected for LAUNCH_APP (choose one in Settings)" else launch(i)
            }
            "FOCUS_AND_TAP_FIELD" -> focusField()
            else -> "Unknown action $action"
        }
    }

    private fun ok(b: Boolean): String? = if (b) null else "Android refused this action in the current app"

    private fun media(am: AudioManager, code: Int): String? {
        return try {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            null
        } catch (e: Exception) { "Media key rejected" }
    }

    private fun launch(i: Intent): String? = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); null
    } catch (e: Exception) { "Could not open that screen" }

    /** Brightness needs WRITE_SETTINGS special access; we never grant it ourselves. */
    private fun brightness(delta: Float): String? {
        if (!Settings.System.canWrite(this)) return "Brightness needs 'Modify system settings' access (Setup → Optional)"
        return try {
            val cr = contentResolver
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (cur + delta * 255).toInt().coerceIn(5, 255))
            null
        } catch (e: Exception) { "Brightness change failed" }
    }

    /**
     * Deliberately NOT implemented via screen inspection: that would require the
     * canRetrieveWindowContent capability, which lets an accessibility service read what is on screen.
     * Air Control keeps that capability off. Point at the field and pinch-tap instead.
     */
    private fun focusField(): String? =
        "Not supported: needs screen-content access, which Air Control keeps off. Point at the field and pinch to tap."
}
