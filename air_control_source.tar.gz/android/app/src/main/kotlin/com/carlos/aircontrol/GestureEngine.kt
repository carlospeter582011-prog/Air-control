package com.carlos.aircontrol

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Pure-Kotlin gesture logic (no Android dependencies, so it is JVM-unit-testable).
 *
 * Input: 21 hand landmarks as x,y pairs (normalized 0..1, already upright and mirrored like a selfie view)
 * plus a millisecond timestamp. Output: pointer position, discrete actions and drag events through [Output].
 *
 * Safety rules baked in:
 *  - discrete gestures fire once per entry into a pose (holding a pose never repeats an action)
 *  - hold/swipe actions respect a cooldown
 *  - losing the hand for longer than lostTimeoutMs releases any held drag and resets all state
 *  - while paused only the pause-toggle gesture is evaluated
 */
class GestureEngine(initial: Config, private val out: Output) {

    interface Output {
        fun pointer(x: Float, y: Float)
        fun action(action: String, gesture: String, x: Float, y: Float)
        fun dragStart(x: Float, y: Float)
        fun dragMove(x: Float, y: Float)
        fun dragEnd(x: Float, y: Float)
        fun pauseChanged(paused: Boolean)
        fun info(pose: String, pinchRatio: Float)
    }

    enum class Pose { NONE, POINT, PINCH, PEACE, OPEN, FIST, THUMB_UP, THUMB_DOWN, OTHER }

    private class Sample(val t: Long, val x: Float, val y: Float)

    @Volatile
    var paused = false
        private set

    private var cfg = initial
    private var screenW = 1080f
    private var screenH = 2400f

    // smoothing
    private var haveSm = false
    private var smTipX = 0f
    private var smTipY = 0f
    private var smMcpX = 0f
    private var smMcpY = 0f

    // pointer
    private var ptrX = 540f
    private var ptrY = 1200f
    private var relPrevX = Float.NaN
    private var relPrevY = Float.NaN
    private val hist = ArrayDeque<Sample>()

    // pinch
    private var pinching = false
    private var pinchStartT = 0L
    private var startX = 0f
    private var startY = 0f
    private var startMapX = 0f
    private var startMapY = 0f
    private var dragging = false
    private var longFired = false
    private var pendingTapT = -1L
    private var pendX = 0f
    private var pendY = 0f

    // pose
    private var candidate = Pose.NONE
    private var candidateCount = 0
    private var stablePose = Pose.NONE
    private var poseSince = 0L
    private var holdFired = false

    // palm motion
    private val palmHist = ArrayDeque<Sample>()
    private var lastDiscrete = -100000L
    private var lastSeen = 0L

    @Synchronized fun setConfig(c: Config) { cfg = c }

    @Synchronized fun setScreen(w: Float, h: Float) { if (w > 0 && h > 0) { screenW = w; screenH = h } }

    @Synchronized fun setPaused(p: Boolean) {
        if (p == paused) return
        paused = p
        releaseAllLocked()
        out.pauseChanged(p)
    }

    @Synchronized fun releaseAll() = releaseAllLocked()

    /** Called for every result without a usable hand. */
    @Synchronized fun onNoHand(t: Long) {
        tickLocked(t)
        if (lastSeen != 0L && t - lastSeen > cfg.i("lostTimeoutMs", 500)) {
            releaseAllLocked()
            out.info("NONE", 0f)
        }
    }

    @Synchronized fun onHand(lm: FloatArray, t: Long) {
        lastSeen = t
        val palm = max(d(lm, 0, 9), 0.001f)
        val ratio = d(lm, 4, 8) / palm
        val ext = booleanArrayOf(ex(lm, 8, 6), ex(lm, 12, 10), ex(lm, 16, 14), ex(lm, 20, 18))
        val anyExt = ext[0] || ext[1] || ext[2] || ext[3]
        val thumbOut = d(lm, 4, 17) > d(lm, 3, 17) * 1.1f && d(lm, 4, 5) > 0.5f * palm

        smooth(lm)

        // ---- pinch transitions (never while paused)
        val on = 0.2f + 0.3f * cfg.f("pinchSensitivity", 0.5f)
        val off = on * 1.4f
        if (!paused) {
            if (!pinching && anyExt && ratio < on) startPinch(t)
            else if (pinching && ratio > off) endPinch(t)
        } else if (pinching) {
            endPinch(t)
        }

        // ---- pose
        val raw = when {
            pinching -> Pose.PINCH
            !ext[0] && !ext[1] && !ext[2] && !ext[3] -> {
                if (thumbOut) {
                    val tipY = lm[9]
                    val top = min(lm[1], lm[11])
                    val bottom = max(lm[1], lm[11])
                    when {
                        tipY < top - 0.3f * palm -> Pose.THUMB_UP
                        tipY > bottom + 0.3f * palm -> Pose.THUMB_DOWN
                        else -> Pose.OTHER
                    }
                } else Pose.FIST
            }
            ext[0] && !ext[1] && !ext[2] && !ext[3] -> Pose.POINT
            ext[0] && ext[1] && !ext[2] && !ext[3] -> Pose.PEACE
            ext[0] && ext[1] && ext[2] && ext[3] -> Pose.OPEN
            else -> Pose.OTHER
        }
        if (raw == candidate) candidateCount++ else { candidate = raw; candidateCount = 1 }
        if (candidateCount >= 3 && candidate != stablePose) {
            stablePose = candidate
            poseSince = t
            holdFired = false
        }

        // ---- pointer
        val pointerActive = !paused && (pinching || raw == Pose.POINT || stablePose == Pose.POINT)
        if (pointerActive) updatePointer(t) else { relPrevX = Float.NaN; relPrevY = Float.NaN }

        // ---- pinch behaviour (drag / long press)
        if (pinching && !paused) {
            val moved = hypot(ptrX - startX, ptrY - startY)
            if (!dragging && !longFired && moved > 0.04f * screenW && cfg.mapping("pinch_drag") == "DRAG") {
                dragging = true
                out.dragStart(startX, startY)
            }
            if (dragging) out.dragMove(ptrX, ptrY)
            else if (!longFired && moved <= 0.04f * screenW &&
                t - pinchStartT >= cfg.i("longPressMs", 600)) {
                longFired = true
                fire("pinch_hold", startX, startY)
            }
        }

        // ---- palm motion: swipes + hold-restart
        if (stablePose == Pose.OPEN && !paused) handleSwipe(lm, t) else palmHist.clear()
        if (stablePose == Pose.OPEN || stablePose == Pose.PEACE) restartHoldIfMoving(lm, t)

        // ---- hold gestures
        if (!holdFired && t - poseSince >= cfg.i("holdMs", 800)) {
            val key = when (stablePose) {
                Pose.OPEN -> "open_palm_hold"
                Pose.FIST -> "fist_hold"
                Pose.PEACE -> "peace_hold"
                Pose.THUMB_UP -> "thumbs_up_hold"
                Pose.THUMB_DOWN -> "thumbs_down_hold"
                else -> null
            }
            if (key != null) {
                holdFired = true
                fireWithCooldown(key, ptrX, ptrY, t)
            }
        }

        tickLocked(t)
        out.info(raw.name, ratio)
    }

    // ------------------------------------------------------------------ internals

    private fun d(lm: FloatArray, a: Int, b: Int) =
        hypot(lm[2 * a] - lm[2 * b], lm[2 * a + 1] - lm[2 * b + 1])

    /** Finger is extended when its tip is farther from the wrist than its PIP joint. */
    private fun ex(lm: FloatArray, tip: Int, pip: Int) = d(lm, 0, tip) > d(lm, 0, pip) * 1.05f

    private fun smooth(lm: FloatArray) {
        val alpha = 1f - cfg.f("smoothing", 0.5f).coerceIn(0f, 1f) * 0.92f
        val tx = lm[16]; val ty = lm[17]; val mx = lm[10]; val my = lm[11]
        if (!haveSm) {
            smTipX = tx; smTipY = ty; smMcpX = mx; smMcpY = my; haveSm = true
            return
        }
        // tiny dead zone suppresses sensor jitter when the hand is still
        if (hypot(tx - smTipX, ty - smTipY) > 0.0015f) {
            smTipX += alpha * (tx - smTipX); smTipY += alpha * (ty - smTipY)
        }
        if (hypot(mx - smMcpX, my - smMcpY) > 0.0015f) {
            smMcpX += alpha * (mx - smMcpX); smMcpY += alpha * (my - smMcpY)
        }
    }

    private fun mapX(nx: Float): Float {
        val lo = cfg.f("calXMin", 0.2f); val hi = max(cfg.f("calXMax", 0.8f), lo + 0.05f)
        val u = ((nx - lo) / (hi - lo)).coerceIn(0f, 1f)
        return (0.5f + (u - 0.5f) * cfg.f("pointerSpeed", 1f)).coerceIn(0f, 1f) * screenW
    }

    private fun mapY(ny: Float): Float {
        val lo = cfg.f("calYMin", 0.2f); val hi = max(cfg.f("calYMax", 0.7f), lo + 0.05f)
        val v = ((ny - lo) / (hi - lo)).coerceIn(0f, 1f)
        return (0.5f + (v - 0.5f) * cfg.f("pointerSpeed", 1f)).coerceIn(0f, 1f) * screenH
    }

    private fun updatePointer(t: Long) {
        val srcX = if (pinching) smMcpX else smTipX
        val srcY = if (pinching) smMcpY else smTipY
        if (cfg.s("pointerMode", "absolute") == "absolute") {
            if (pinching) {
                ptrX = (startX + (mapX(srcX) - startMapX)).coerceIn(0f, screenW)
                ptrY = (startY + (mapY(srcY) - startMapY)).coerceIn(0f, screenH)
            } else {
                ptrX = mapX(srcX); ptrY = mapY(srcY)
            }
        } else {
            if (!relPrevX.isNaN()) {
                val dx = srcX - relPrevX; val dy = srcY - relPrevY
                val mag = hypot(dx, dy)
                val gain = cfg.f("pointerSpeed", 1f) * (1f + cfg.f("pointerAccel", 0.3f) * min(mag * 25f, 3f))
                val spanX = max(cfg.f("calXMax", 0.8f) - cfg.f("calXMin", 0.2f), 0.05f)
                val spanY = max(cfg.f("calYMax", 0.7f) - cfg.f("calYMin", 0.2f), 0.05f)
                ptrX = (ptrX + dx / spanX * screenW * gain).coerceIn(0f, screenW)
                ptrY = (ptrY + dy / spanY * screenH * gain).coerceIn(0f, screenH)
            }
            relPrevX = srcX; relPrevY = srcY
        }
        hist.addLast(Sample(t, ptrX, ptrY))
        while (hist.size > 12 || (hist.size > 1 && t - hist.first().t > 400)) hist.removeFirst()
        out.pointer(ptrX, ptrY)
    }

    private fun startPinch(t: Long) {
        // Use the pointer position from ~120 ms ago: the fingertip moves while the pinch closes.
        var s: Sample? = null
        for (h in hist) { if (h.t <= t - 120) s = h }
        if (s == null && hist.isNotEmpty()) s = hist.first()
        startX = s?.x ?: ptrX
        startY = s?.y ?: ptrY
        startMapX = mapX(smMcpX); startMapY = mapY(smMcpY)
        ptrX = startX; ptrY = startY
        relPrevX = smMcpX; relPrevY = smMcpY
        pinching = true
        pinchStartT = t
        dragging = false
        longFired = false
    }

    private fun endPinch(t: Long) {
        pinching = false
        relPrevX = Float.NaN; relPrevY = Float.NaN
        if (dragging) {
            dragging = false
            out.dragEnd(ptrX, ptrY)
            return
        }
        if (longFired) { longFired = false; return }
        if (t - pinchStartT < 40) return // noise
        val dbl = cfg.mapping("pinch_double") != "NONE"
        if (dbl && pendingTapT >= 0 && t - pendingTapT <= cfg.i("doublePinchMs", 350)) {
            pendingTapT = -1
            fire("pinch_double", pendX, pendY)
        } else if (!dbl) {
            fire("pinch_click", startX, startY)
        } else {
            pendingTapT = t; pendX = startX; pendY = startY
        }
    }

    private fun tickLocked(t: Long) {
        if (pendingTapT >= 0 && t - pendingTapT > cfg.i("doublePinchMs", 350)) {
            pendingTapT = -1
            if (!paused) fire("pinch_click", pendX, pendY)
        }
    }

    private fun handleSwipe(lm: FloatArray, t: Long) {
        palmHist.addLast(Sample(t, lm[18], lm[19]))
        while (palmHist.size > 1 && t - palmHist.first().t > 350) palmHist.removeFirst()
        val a = palmHist.first()
        val dx = lm[18] - a.x
        val dy = lm[19] - a.y
        val dist = hypot(dx, dy)
        if (dist < cfg.f("swipeDistance", 0.18f)) return
        val key = when {
            abs(dx) > abs(dy) * 1.8f -> if (dx > 0) "swipe_right" else "swipe_left"
            abs(dy) > abs(dx) * 1.8f -> if (dy > 0) "swipe_down" else "swipe_up"
            else -> null
        }
        palmHist.clear()
        if (key != null) fireWithCooldown(key, ptrX, ptrY, t)
    }

    private fun restartHoldIfMoving(lm: FloatArray, t: Long) {
        if (palmHist.isEmpty()) return
        val a = palmHist.first()
        if (hypot(lm[18] - a.x, lm[19] - a.y) > 0.06f) poseSince = t
    }

    private fun fireWithCooldown(gesture: String, x: Float, y: Float, t: Long) {
        val action = cfg.mapping(gesture)
        if (action == "NONE") return
        if (t - lastDiscrete < cfg.i("cooldownMs", 900)) return
        lastDiscrete = t
        fire(gesture, x, y)
    }

    private fun fire(gesture: String, x: Float, y: Float) {
        val action = cfg.mapping(gesture)
        if (action == "NONE") return
        if (action == "PAUSE_TOGGLE") {
            paused = !paused
            releaseAllLocked()
            out.pauseChanged(paused)
            return
        }
        if (paused) return
        out.action(action, gesture, x, y)
    }

    private fun releaseAllLocked() {
        if (dragging) out.dragEnd(ptrX, ptrY)
        dragging = false
        pinching = false
        longFired = false
        pendingTapT = -1
        candidate = Pose.NONE; candidateCount = 0; stablePose = Pose.NONE; holdFired = true
        palmHist.clear(); hist.clear()
        haveSm = false
        relPrevX = Float.NaN; relPrevY = Float.NaN
        lastSeen = 0L
    }
}
