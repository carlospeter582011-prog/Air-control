package com.carlos.aircontrol

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val CH = "air_control/methods"
    private val EV = "air_control/events"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val msg = flutterEngine.dartExecutor.binaryMessenger
        EventChannel(msg, EV).setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, sink: EventChannel.EventSink?) { Bridge.sink = sink; Bridge.emitStatus() }
            override fun onCancel(args: Any?) { Bridge.sink = null; Bridge.frameStream = false }
        })
        MethodChannel(msg, CH).setMethodCallHandler { call, res -> handle(call, res) }
    }

    private fun handle(call: MethodCall, res: MethodChannel.Result) {
        try {
            when (call.method) {
                "permissions" -> res.success(permissions())
                "requestCamera" -> {
                    if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.CAMERA), 7)
                    res.success(null)
                }
                "requestNotifications" -> {
                    if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8)
                    res.success(null)
                }
                "openAccessibilitySettings" -> { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); res.success(null) }
                "openAppDetails" -> {
                    open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))); res.success(null)
                }
                "openWriteSettings" -> {
                    open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))); res.success(null)
                }
                "openBatterySettings" -> {
                    val i = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    open(i); res.success(null)
                }
                "start" -> {
                    val i = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
                    ContextCompat.startForegroundService(this, i)
                    res.success(null)
                }
                "stop" -> {
                    val s = TrackingService.instance
                    if (s != null) s.stopTracking("Stopped by you") else { Bridge.running = false; Bridge.emitStatus() }
                    res.success(null)
                }
                "setPaused" -> {
                    val p = call.argument<Boolean>("paused") ?: true
                    val a = if (p) TrackingService.ACTION_PAUSE else TrackingService.ACTION_RESUME
                    startService(Intent(this, TrackingService::class.java).setAction(a))
                    res.success(null)
                }
                "getConfig" -> res.success(Config.load(this).json.toString())
                "setConfig" -> {
                    val ok = Config.save(this, call.argument<String>("json") ?: "{}")
                    if (ok && Bridge.running) startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_CONFIG))
                    res.success(ok)
                }
                "defaultConfig" -> res.success(Config.defaults().toString())
                "setDryRun" -> { Bridge.dryRun = call.argument<Boolean>("on") ?: false; Bridge.emitStatus(); res.success(null) }
                "setFrameStream" -> { Bridge.frameStream = call.argument<Boolean>("on") ?: false; res.success(null) }
                "status" -> res.success(Bridge.statusMap())
                "installedApps" -> res.success(installedApps())
                "sdkInt" -> res.success(Build.VERSION.SDK_INT)
                "testAction" -> {
                    val svc = AirAccessibilityService.instance
                    if (svc == null) res.success("Accessibility access is off")
                    else {
                        val (w, h) = svc.screenSize()
                        res.success(svc.perform(call.argument<String>("action") ?: "NONE", w / 2, h / 2, Config.load(this)))
                    }
                }
                else -> res.notImplemented()
            }
        } catch (e: Exception) {
            res.error("native", e.javaClass.simpleName, null)
        }
    }

    private fun open(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }

    private fun permissions(): Map<String, Any> {
        val pm = getSystemService(PowerManager::class.java)
        return mapOf(
            "camera" to (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED),
            "accessibility" to AirAccessibilityService.isEnabled(),
            "notifications" to (if (Build.VERSION.SDK_INT >= 33)
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            else getSystemService(NotificationManager::class.java).areNotificationsEnabled()),
            "writeSettings" to (if (Build.VERSION.SDK_INT >= 23) Settings.System.canWrite(this) else true),
            "batteryUnrestricted" to (pm?.isIgnoringBatteryOptimizations(packageName) ?: false)
        )
    }

    private fun installedApps(): List<Map<String, String>> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { mapOf("pkg" to it.activityInfo.packageName, "name" to it.loadLabel(packageManager).toString()) }
            .filter { it["pkg"] != packageName }
            .sortedBy { it["name"]!!.lowercase() }
    }
}
