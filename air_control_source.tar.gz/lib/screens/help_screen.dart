import 'package:flutter/material.dart';
import '../native.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Help'),
          bottom: const TabBar(isScrollable: true, tabs: [
            Tab(text: 'Tutorial'),
            Tab(text: 'Actions'),
            Tab(text: 'Privacy'),
            Tab(text: 'Battery'),
            Tab(text: 'Troubleshooting'),
          ]),
        ),
        body: TabBarView(children: [
          _text(const [
            ('1. Position the phone', 'Prop it up on a stand about 30–60 cm from you, front camera facing you, with your hand in view against a plain, well-lit background.'),
            ('2. Set up access', 'Open Permissions and setup. Grant camera and notifications, then turn on the Air Control accessibility service.'),
            ('3. Calibrate', 'Open Live test and calibration. Check your hand outline appears, then tap "Calibrate pointer area" and capture the four screen corners with your index finger.'),
            ('4. Try gestures safely', 'The Live test screen runs in test mode: it shows what would happen without touching anything.'),
            ('5. Start tracking', 'Press Start tracking on the home screen. Then switch to any app. A notification shows the camera is on.'),
            ('6. Stop immediately', 'Pull down the notification and tap Stop (or Pause). Or hold a fist for the hold time (default mapping pauses). Turning off the accessibility service in Android Settings also stops all actions.'),
            ('Gestures', 'Point with your index finger to move the dot. Pinch thumb and index to tap. Pinch and move to drag. Pinch and hold for long-press. Sweep an open palm to scroll or go Back/Recents. Hold an open palm for Home.'),
          ]),
          ListView(children: [
            const Padding(padding: EdgeInsets.all(16), child: Text('What each action needs. Not every action works in every app or on every phone.')),
            for (final a in kActions)
              ListTile(dense: true, title: Text(a.label), subtitle: Text(a.note.isEmpty ? 'Needs accessibility service' : a.note)),
          ]),
          _text(const [
            ('Camera', 'Frames are processed on your phone by MediaPipe and discarded immediately. They are never stored and never sent anywhere. The release build has no internet permission.'),
            ('Accessibility', 'Android treats accessibility access as sensitive. Air Control\'s service is declared without the ability to read window contents or listen for events, so it cannot see your screen, passwords, OTPs or notification text. It can only inject taps/swipes, press Back/Home/Recents and draw the pointer dot.'),
            ('What is stored', 'Only your settings, on the phone, in app-private storage. No analytics, ads, accounts or tracking.'),
            ('Indicator', 'While the camera is on, a notification is always shown. You cannot hide it from inside the app.'),
          ]),
          _text(const [
            ('Samsung Galaxy A23 (One UI)', 'Settings → Apps → Air Control → Battery → Unrestricted. Settings → Battery → Background usage limits → Never sleeping apps → add Air Control. Turn off "Put unused apps to sleep".'),
            ('Performance', 'Lower "Max analysis rate" to 12–15 fps if the phone gets warm. Good light helps accuracy more than higher fps.'),
            ('Limits', 'Android may stop camera use when another app needs the camera, on some power-saving modes, or after a reboot. Start tracking again manually from the app; Air Control never starts the camera by itself.'),
          ]),
          _text(const [
            ('Accessibility switch is greyed out', 'Android 13+ restricts sideloaded apps. Settings → Apps → Air Control → ⋮ (top right) → Allow restricted settings, then enable the service.'),
            ('Nothing happens in other apps', 'Check the Home screen status: is accessibility on? Is test mode off? Some screens (banking apps, lock screen, system dialogs, secure windows) refuse injected touches by design.'),
            ('Pointer jumps around', 'Raise Smoothing, improve lighting, recalibrate the pointer area.'),
            ('Taps trigger too easily', 'Lower pinch sensitivity; raise cooldown.'),
            ('Tracking stopped by itself', 'The Home screen shows the reason. Usually battery limits (see Battery tab) or another app took the camera.'),
            ('Stuck touch', 'Press Stop or Pause: any held touch is released immediately. Losing the hand also releases it after the "Release if hand lost" time.'),
            ('Camera permission prompt never shows', 'Open Setup → Open App settings → Permissions → Camera → Allow while using the app.'),
          ]),
        ]),
      ),
    );
  }

  Widget _text(List<(String, String)> items) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final i in items) ...[
            Text(i.$1, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 4),
            Text(i.$2),
            const SizedBox(height: 16),
          ]
        ],
      );
}
