import 'package:flutter/material.dart';
import '../native.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> with WidgetsBindingObserver {
  Map<String, bool> _p = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    final p = await Native.permissions();
    if (mounted) setState(() => _p = p);
  }

  Widget _step({
    required String title,
    required bool? granted,
    required String why,
    required String without,
    required String button,
    required Future<void> Function() onTap,
    String? extra,
    bool optional = false,
  }) {
    final ok = granted == true;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(ok ? Icons.check_circle : Icons.radio_button_unchecked, color: ok ? Colors.greenAccent : null),
            const SizedBox(width: 10),
            Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium)),
            if (optional) const Chip(label: Text('optional')),
          ]),
          const SizedBox(height: 8),
          Text(why),
          const SizedBox(height: 6),
          Text('If denied: $without', style: const TextStyle(fontStyle: FontStyle.italic)),
          if (extra != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(extra)),
          const SizedBox(height: 10),
          if (!ok) FilledButton(onPressed: () async { await onTap(); await _refresh(); }, child: Text(button)),
          if (ok) const Text('Granted', style: TextStyle(color: Colors.greenAccent)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Setup')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text(
            'Status below is read live from Android. When you come back from a Settings screen it refreshes by itself. '
            'Nothing is shown as granted unless Android reports it.'),
        const SizedBox(height: 12),
        _step(
          title: '1. Camera',
          granted: _p['camera'],
          why: 'Needed to see your hand through the front camera. Frames are analysed on the phone and thrown away. Nothing is saved or sent.',
          without: 'Tracking cannot start.',
          button: 'Allow camera',
          onTap: () async {
            await Native.requestCamera();
            await Future.delayed(const Duration(seconds: 1));
          },
          extra: 'If the prompt does not appear, Android remembers a previous "deny": use App settings → Permissions → Camera.',
        ),
        if (_p['camera'] == false)
          TextButton(onPressed: Native.openAppDetails, child: const Text('Open App settings')),
        _step(
          title: '2. Accessibility service',
          granted: _p['accessibility'],
          why: 'Android only lets an accessibility service tap, swipe and press Back/Home inside other apps. '
              'Air Control\'s service is limited to sending those actions and showing the pointer dot. It is configured without screen-content access, so it cannot read your screen, passwords, OTPs or notifications.',
          without: 'Gestures are detected, but nothing happens in other apps.',
          button: 'Open Accessibility settings',
          onTap: Native.openAccessibilitySettings,
          extra: 'Settings → Accessibility → Installed apps (on Samsung: Installed apps) → Air Control hand gestures → On. '
              'On Android 13+ a sideloaded app may show it greyed out: open App settings → ⋮ → "Allow restricted settings", then try again.',
        ),
        if (_p['accessibility'] == false)
          TextButton(onPressed: Native.openAppDetails, child: const Text('Open App settings (for "Allow restricted settings")')),
        _step(
          title: '3. Notifications',
          granted: _p['notifications'],
          why: 'Android 13+ may hide the notification that shows the camera is on and holds the Pause and Stop buttons.',
          without: 'Tracking still works but the persistent indicator may be hidden. Use the in-app Stop button.',
          button: 'Allow notifications',
          onTap: () async {
            await Native.requestNotifications();
            await Future.delayed(const Duration(seconds: 1));
          },
        ),
        _step(
          title: '4. Pointer overlay',
          granted: _p['accessibility'],
          why: 'The pointer dot is drawn by the accessibility service itself, so no separate "Display over other apps" permission is requested.',
          without: 'Turn the pointer off in Settings if you do not want it.',
          button: 'See step 2',
          onTap: Native.openAccessibilitySettings,
        ),
        _step(
          title: '5. Modify system settings',
          granted: _p['writeSettings'],
          optional: true,
          why: 'Only for the brightness up/down actions.',
          without: 'Brightness gestures report "needs access"; everything else works.',
          button: 'Open Modify system settings',
          onTap: Native.openWriteSettings,
        ),
        _step(
          title: '6. Battery (Samsung and others)',
          granted: _p['batteryUnrestricted'],
          optional: true,
          why: 'Android and One UI may stop background camera apps to save power.',
          without: 'Tracking may stop on its own when the screen is off or after a while; the app will show why.',
          button: 'Open battery settings',
          onTap: Native.openBatterySettings,
          extra: 'Samsung: Settings → Apps → Air Control → Battery → Unrestricted. Also Settings → Battery → Background usage limits → Never sleeping apps → add Air Control.',
        ),
      ]),
    );
  }
}
