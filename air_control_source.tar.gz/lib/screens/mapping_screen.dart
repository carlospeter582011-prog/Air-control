import 'package:flutter/material.dart';
import '../native.dart';

class MappingScreen extends StatefulWidget {
  const MappingScreen({super.key});
  @override
  State<MappingScreen> createState() => _MappingScreenState();
}

class _MappingScreenState extends State<MappingScreen> {
  Map<String, dynamic>? _c;
  Map<String, dynamic>? _defaults;

  @override
  void initState() {
    super.initState();
    Native.getConfig().then((c) => mounted ? setState(() => _c = c) : null);
    Native.defaultConfig().then((c) => _defaults = c);
  }

  Map<String, dynamic> get _map => Map<String, dynamic>.from(_c!['mapping'] as Map);

  Future<void> _save(String gesture, String action) async {
    final m = _map..[gesture] = action;
    _c!['mapping'] = m;
    setState(() {});
    await Native.setConfig(_c!);
  }

  Future<void> _pick(GestureInfo g) async {
    final cur = _map[g.id] as String;
    final dupes = <String>[];
    final pick = await showDialog<String>(
      context: context,
      builder: (c) => SimpleDialog(
        title: Text(g.label),
        children: [
          SizedBox(
            width: double.maxFinite,
            height: 440,
            child: ListView(children: [
              for (final a in kActions)
                RadioListTile<String>(
                  value: a.id,
                  groupValue: cur,
                  title: Text(a.label),
                  subtitle: a.note.isEmpty ? null : Text(a.note),
                  onChanged: (v) => Navigator.pop(c, v),
                ),
            ]),
          ),
        ],
      ),
    );
    if (pick == null) return;
    for (final e in _map.entries) {
      if (e.key != g.id && e.value == pick && pick != 'NONE') dupes.add(e.key);
    }
    await _save(g.id, pick);
    if (dupes.isNotEmpty && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Note: ${actionLabel(pick)} is also used by another gesture. That is allowed but can trigger by mistake.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gesture mapping'),
        actions: [
          TextButton(
            onPressed: () async {
              if (_defaults == null) return;
              _c!['mapping'] = Map<String, dynamic>.from(_defaults!['mapping'] as Map);
              setState(() {});
              await Native.setConfig(_c!);
            },
            child: const Text('Restore defaults'),
          ),
        ],
      ),
      body: c == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                    'Pointing with your index finger always moves the pointer. Tap a row to change what a gesture does. '
                    'Changes apply immediately, even while tracking is running. The gesture set to "Pause / resume tracking" stops all other actions.'),
              ),
              for (final g in kGestures)
                ListTile(
                  title: Text(g.label),
                  subtitle: Text('${g.how}\n→ ${actionLabel(_map[g.id] as String)}'),
                  isThreeLine: true,
                  trailing: const Icon(Icons.edit),
                  onTap: () => _pick(g),
                ),
              const SizedBox(height: 40),
            ]),
    );
  }
}
