import 'package:flutter/material.dart';
import '../native.dart';

/// Gesture -> action editor. [profile] is 'mapping' (normal) or 'socialMapping' (Social mode).
/// Any number of gestures may use the same action.
class MappingScreen extends StatefulWidget {
  final String profile;
  const MappingScreen({super.key, this.profile = 'mapping'});
  @override
  State<MappingScreen> createState() => _MappingScreenState();
}

class _MappingScreenState extends State<MappingScreen> {
  Map<String, dynamic>? _c;
  Map<String, dynamic>? _defaults;

  bool get _social => widget.profile == 'socialMapping';

  @override
  void initState() {
    super.initState();
    Native.getConfig().then((c) => mounted ? setState(() => _c = c) : null);
    Native.defaultConfig().then((c) => _defaults = c);
  }

  Map<String, dynamic> get _map => Map<String, dynamic>.from((_c![widget.profile] as Map?) ?? const {});
  Map<String, dynamic> get _normal => Map<String, dynamic>.from((_c!['mapping'] as Map?) ?? const {});

  /// What the gesture does in this profile. Empty string in the social profile means "same as normal".
  String _effective(String g) {
    final v = (_map[g] as String?) ?? '';
    if (_social) return v.isEmpty ? ((_normal[g] as String?) ?? 'NONE') : v;
    return v.isEmpty ? 'NONE' : v;
  }

  bool _inherits(String g) => _social && ((_map[g] as String?) ?? '').isEmpty;

  Future<void> _save(String gesture, String action) async {
    final m = _map..[gesture] = action;
    _c![widget.profile] = m;
    setState(() {});
    await Native.setConfig(_c!);
  }

  Future<void> _pick(GestureInfo g) async {
    final cur = _inherits(g.id) ? '__same__' : _effective(g.id);
    final groups = <String>[];
    for (final a in kActions) {
      if (!groups.contains(a.group)) groups.add(a.group);
    }
    final pick = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(g.label),
        contentPadding: const EdgeInsets.only(top: 12),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(shrinkWrap: true, children: [
            if (_social)
              ListTile(
                selected: cur == '__same__',
                leading: const Icon(Icons.copy),
                title: const Text('Same as normal mode'),
                onTap: () => Navigator.pop(c, ''),
              ),
            for (final grp in groups) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Text(grp, style: TextStyle(color: Theme.of(c).colorScheme.primary, fontWeight: FontWeight.bold)),
              ),
              for (final a in kActions.where((a) => a.group == grp))
                ListTile(
                  dense: true,
                  selected: cur == a.id,
                  title: Text(a.label),
                  subtitle: a.note.isEmpty ? null : Text(a.note),
                  trailing: cur == a.id ? const Icon(Icons.check) : null,
                  onTap: () => Navigator.pop(c, a.id),
                ),
            ],
          ]),
        ),
      ),
    );
    if (pick != null) await _save(g.id, pick);
  }

  Future<void> _restore() async {
    if (_defaults == null) return;
    _c![widget.profile] = Map<String, dynamic>.from(_defaults![widget.profile] as Map);
    setState(() {});
    await Native.setConfig(_c!);
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    final groups = <String>[];
    for (final g in kGestures) {
      if (!groups.contains(g.group)) groups.add(g.group);
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(_social ? 'Social gestures' : 'Gesture mapping'),
        actions: [TextButton(onPressed: _restore, child: const Text('Restore defaults'))],
      ),
      body: c == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  '${_social ? 'These gestures apply while Social mode is active. A gesture set to "Same as normal mode" uses your normal mapping. ' : ''}'
                  'Pointing with your index finger always moves the pointer. Tap a row to change what a gesture does. '
                  'You can give several gestures the same action. Changes apply immediately, even while tracking is running.\n\n'
                  'Volume, brightness and scrolling actions keep going while you hold the gesture and stop as soon as you stop.',
                ),
              ),
              for (final grp in groups) ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
                  child: Text(grp, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
                ),
                for (final g in kGestures.where((g) => g.group == grp))
                  ListTile(
                    title: Text(g.label),
                    subtitle: Text('${g.how}\n→ ${actionLabel(_effective(g.id))}${_inherits(g.id) ? '  (same as normal)' : ''}'),
                    isThreeLine: true,
                    trailing: const Icon(Icons.edit),
                    onTap: () => _pick(g),
                  ),
              ],
              const SizedBox(height: 40),
            ]),
    );
  }
}
