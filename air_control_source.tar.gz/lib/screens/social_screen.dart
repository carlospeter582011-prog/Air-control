import 'package:flutter/material.dart';
import '../native.dart';
import 'app_picker.dart';
import 'mapping_screen.dart';

/// Social mode: easier control for TikTok, Instagram Reels, YouTube Shorts and Facebook, plus normal videos.
class SocialScreen extends StatefulWidget {
  const SocialScreen({super.key});
  @override
  State<SocialScreen> createState() => _SocialScreenState();
}

class _SocialScreenState extends State<SocialScreen> {
  Map<String, dynamic>? _c;
  Map<String, String> _names = {};
  String _target = 'comment'; // which button position the phone sketch edits

  @override
  void initState() {
    super.initState();
    Native.getConfig().then((c) => mounted ? setState(() => _c = c) : null);
    Native.installedApps().then((a) {
      if (mounted) setState(() => _names = {for (final e in a) e['pkg']!: e['name']!});
    });
  }

  void _set(String k, dynamic v) {
    setState(() => _c![k] = v);
    Native.setConfig(_c!);
  }

  Set<String> get _apps => ((_c!['socialApps'] as List?) ?? const []).map((e) => e.toString()).toSet();

  double _d(String k) => (_c![k] as num).toDouble();

  Future<void> _pickApps() async {
    final r = await Navigator.push<Set<String>>(
      context,
      MaterialPageRoute(builder: (_) => AppPicker(title: 'Social apps (for Auto mode)', initial: _apps)),
    );
    if (r != null) _set('socialApps', r.toList());
  }

  void _place(Offset local, Size size) {
    final x = (local.dx / size.width).clamp(0.05, 0.98);
    final y = (local.dy / size.height).clamp(0.05, 0.95);
    setState(() {
      if (_target == 'comment') {
        _c!['socialCommentX'] = x;
        _c!['socialCommentY'] = y;
      } else {
        _c!['socialShareX'] = x;
        _c!['socialShareY'] = y;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Social mode')),
      body: c == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              const Text(
                'Easier control for scrolling videos. While it is active: the pointer dot is bigger, pinch needs less precision, '
                'the pointer moves a little slower, hold gestures react faster, and a separate set of gestures does video things.',
              ),
              const SizedBox(height: 16),
              const Text('Social mode', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'off', label: Text('Off')),
                  ButtonSegment(value: 'on', label: Text('Always on')),
                  ButtonSegment(value: 'auto', label: Text('Auto')),
                ],
                selected: {c['socialMode'] as String},
                onSelectionChanged: (s) => _set('socialMode', s.first),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(switch (c['socialMode'] as String) {
                  'on' => 'Social gestures are active in every app.',
                  'auto' => 'Turns on by itself while one of your social apps is open, off again when you leave it.',
                  _ => 'Normal gestures everywhere. You can still switch it on with a gesture mapped to "Turn Social mode on / off".',
                }),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.apps),
                title: Text('Social apps for Auto (${_apps.length})'),
                subtitle: Text(_apps.map((p) => _names[p] ?? p).take(5).join(', ') + (_apps.length > 5 ? '…' : '')),
                onTap: _pickApps,
              ),
              const Divider(),
              const Text('Video style', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'short', label: Text('Short videos'), icon: Icon(Icons.smartphone)),
                  ButtonSegment(value: 'long', label: Text('Long videos'), icon: Icon(Icons.smart_display)),
                ],
                selected: {c['videoStyle'] as String},
                onSelectionChanged: (s) => _set('videoStyle', s.first),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text((c['videoStyle'] as String) == 'short'
                    ? 'Reels, TikTok, Shorts: next / previous video swipes the feed, double tap likes, tap plays or pauses.'
                    : 'Normal YouTube / Facebook videos: next / previous skip 10 s forward or back, tap plays or pauses. '
                        'Like, comments and share are not available in this style.'),
              ),
              const Divider(),
              const Text('Comments and share button positions', style: TextStyle(fontWeight: FontWeight.bold)),
              const Text(
                'Apps put these buttons in slightly different places. Choose a button, then tap where it is on your phone '
                'in the sketch. Short-video style only.',
              ),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'comment', label: Text('Comments')),
                  ButtonSegment(value: 'share', label: Text('Share')),
                ],
                selected: {_target},
                onSelectionChanged: (s) => setState(() => _target = s.first),
              ),
              const SizedBox(height: 8),
              Center(
                child: SizedBox(
                  width: 200,
                  child: AspectRatio(
                    aspectRatio: 9 / 19.5,
                    child: LayoutBuilder(builder: (context, box) {
                      final size = Size(box.maxWidth, box.maxHeight);
                      Widget marker(double x, double y, Color col, IconData ic) => Positioned(
                            left: x * size.width - 14,
                            top: y * size.height - 14,
                            child: Icon(ic, color: col, size: 28),
                          );
                      return GestureDetector(
                        onTapDown: (d) => _place(d.localPosition, size),
                        onTapUp: (_) => Native.setConfig(_c!),
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: cs.outline, width: 2),
                            borderRadius: BorderRadius.circular(20),
                            color: cs.surfaceContainerHighest,
                          ),
                          child: Stack(children: [
                            const Center(child: Text('video', style: TextStyle(color: Colors.white38))),
                            marker(_d('socialCommentX'), _d('socialCommentY'), Colors.cyanAccent, Icons.chat_bubble),
                            marker(_d('socialShareX'), _d('socialShareY'), Colors.amberAccent, Icons.share),
                          ]),
                        ),
                      );
                    }),
                  ),
                ),
              ),
              const Divider(),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.gesture),
                title: const Text('Social gestures'),
                subtitle: const Text('Choose what each gesture does while Social mode is active'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const MappingScreen(profile: 'socialMapping')),
                ),
              ),
              const SizedBox(height: 24),
            ]),
    );
  }
}
