import 'package:flutter/material.dart';
import '../native.dart';

/// Multi-select list of installed apps. Pops with the chosen set of package names.
class AppPicker extends StatefulWidget {
  final String title;
  final Set<String> initial;
  const AppPicker({super.key, required this.title, required this.initial});

  @override
  State<AppPicker> createState() => _AppPickerState();
}

class _AppPickerState extends State<AppPicker> {
  List<Map<String, String>> _apps = [];
  late Set<String> _sel;
  String _q = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _sel = {...widget.initial};
    Native.installedApps().then((a) {
      if (!mounted) return;
      // keep chosen apps that are no longer listed so they are not silently dropped
      final known = a.map((e) => e['pkg']).toSet();
      final extra = _sel.where((p) => !known.contains(p)).map((p) => {'pkg': p, 'name': p}).toList();
      setState(() {
        _apps = [...extra, ...a];
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final q = _q.toLowerCase();
    final shown = _apps.where((a) => q.isEmpty || a['name']!.toLowerCase().contains(q) || a['pkg']!.contains(q)).toList()
      ..sort((a, b) {
        final sa = _sel.contains(a['pkg']) ? 0 : 1;
        final sb = _sel.contains(b['pkg']) ? 0 : 1;
        return sa != sb ? sa - sb : a['name']!.toLowerCase().compareTo(b['name']!.toLowerCase());
      });
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [TextButton(onPressed: () => Navigator.pop(context, _sel), child: const Text('Done'))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search apps', border: OutlineInputBorder()),
                  onChanged: (v) => setState(() => _q = v),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: shown.length,
                  itemBuilder: (c, i) {
                    final a = shown[i];
                    final on = _sel.contains(a['pkg']);
                    return CheckboxListTile(
                      value: on,
                      title: Text(a['name']!),
                      subtitle: Text(a['pkg']!, style: const TextStyle(fontSize: 11)),
                      onChanged: (v) => setState(() => v == true ? _sel.add(a['pkg']!) : _sel.remove(a['pkg']!)),
                    );
                  },
                ),
              ),
            ]),
    );
  }
}
