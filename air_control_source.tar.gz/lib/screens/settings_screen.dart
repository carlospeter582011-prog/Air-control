import 'package:flutter/material.dart';
import '../native.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Map<String, dynamic>? _c;
  List<Map<String, String>> _apps = [];

  @override
  void initState() {
    super.initState();
    Native.getConfig().then((c) => mounted ? setState(() => _c = c) : null);
  }

  void _set(String k, dynamic v) {
    setState(() => _c![k] = v);
    Native.setConfig(_c!);
  }

  double _d(String k) => (_c![k] as num).toDouble();

  Widget _slider(String k, String title, double min, double max, {String sub = '', int? div, String unit = ''}) {
    final v = _d(k).clamp(min, max).toDouble();
    return ListTile(
      title: Text('$title: ${v.toStringAsFixed(max > 50 ? 0 : 2)}$unit'),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (sub.isNotEmpty) Text(sub, style: const TextStyle(fontSize: 12)),
        Slider(value: v, min: min, max: max, divisions: div, onChanged: (x) => setState(() => _c![k] = x), onChangeEnd: (x) => _set(k, x)),
      ]),
    );
  }

  Future<void> _pickApp() async {
    final apps = _apps.isEmpty ? await Native.installedApps() : _apps;
    _apps = apps;
    if (!mounted) return;
    final pick = await showDialog<String>(
      context: context,
      builder: (c) => SimpleDialog(
        title: const Text('App for "Launch chosen app"'),
        children: [
          SizedBox(
            width: double.maxFinite,
            height: 420,
            child: ListView(children: [
              for (final a in apps) ListTile(title: Text(a['name']!), subtitle: Text(a['pkg']!), onTap: () => Navigator.pop(c, a['pkg'])),
            ]),
          ),
        ],
      ),
    );
    if (pick != null) _set('appPackage', pick);
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pointer and gesture settings'),
        actions: [
          TextButton(
            onPressed: () async {
              final d = await Native.defaultConfig();
              await Native.setConfig(d);
              setState(() => _c = d);
            },
            child: const Text('Reset all'),
          ),
        ],
      ),
      body: c == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(children: [
              const _H('Pointer'),
              SwitchListTile(
                title: const Text('Floating start/stop button'),
                subtitle: const Text('Small round button always on screen. Drag it anywhere. Needs the accessibility service.'),
                value: c['floatButton'] == true,
                onChanged: (v) => _set('floatButton', v),
              ),
              SwitchListTile(title: const Text('Show pointer dot'), value: c['showPointer'] == true, onChanged: (v) => _set('showPointer', v)),
              SwitchListTile(title: const Text('Click feedback (dot pulses)'), value: c['clickFeedback'] == true, onChanged: (v) => _set('clickFeedback', v)),
              ListTile(
                title: const Text('Pointer mode'),
                subtitle: const Text('Absolute: fingertip position maps to a screen position. Relative: moves like a touchpad.'),
                trailing: DropdownButton<String>(
                  value: c['pointerMode'] as String,
                  items: const [DropdownMenuItem(value: 'absolute', child: Text('Absolute')), DropdownMenuItem(value: 'relative', child: Text('Relative'))],
                  onChanged: (v) => _set('pointerMode', v),
                ),
              ),
              _slider('pointerSpeed', 'Pointer speed', 0.5, 2.5, div: 40),
              _slider('pointerAccel', 'Acceleration (relative mode)', 0, 1, div: 20),
              _slider('smoothing', 'Smoothing / jitter reduction', 0, 1, sub: 'Higher = steadier but slower to follow.', div: 20),
              ListTile(
                title: const Text('Hand preference'),
                subtitle: const Text('Only matters if two hands are in view.'),
                trailing: DropdownButton<String>(
                  value: c['dominantHand'] as String,
                  items: const [
                    DropdownMenuItem(value: 'any', child: Text('Any')),
                    DropdownMenuItem(value: 'right', child: Text('Right')),
                    DropdownMenuItem(value: 'left', child: Text('Left')),
                  ],
                  onChanged: (v) => _set('dominantHand', v),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text('Pointer area is set with "Calibrate pointer area" on the Live test screen and can be redone any time.'),
              ),
              const _H('Gestures'),
              _slider('pinchSensitivity', 'Pinch sensitivity', 0, 1, sub: 'Higher = pinch triggers with a looser pinch.', div: 20),
              _slider('longPressMs', 'Long-press time', 300, 1500, div: 24, unit: ' ms'),
              _slider('doublePinchMs', 'Double-pinch window', 200, 700, div: 25, unit: ' ms'),
              _slider('holdMs', 'Hold time for hold gestures', 400, 2000, div: 32, unit: ' ms'),
              _slider('cooldownMs', 'Cooldown between swipe/hold actions', 300, 3000, div: 27, unit: ' ms', sub: 'Prevents repeats. A held pose never repeats on its own.'),
              _slider('swipeDistance', 'Swipe distance', 0.08, 0.4, div: 32, sub: 'Fraction of the camera view the palm must travel.'),
              _slider('scrollSpeed', 'Scroll distance', 0.3, 2.5, div: 22),
              _slider('lostTimeoutMs', 'Release a held drag if hand lost for', 200, 2000, div: 18, unit: ' ms', sub: 'Only releases a drag. Tracking never pauses.'),
              _slider('repeatMs', 'Repeat speed while held (volume, scroll)', 100, 600, div: 25, unit: ' ms', sub: 'Time between steps while you hold a volume or scroll gesture. Lower = faster.'),
              const _H('Detection and performance'),
              _slider('minDetection', 'Detection confidence', 0.2, 0.9, div: 14, sub: 'Raise if false hands appear, lower in dim light.'),
              _slider('minPresence', 'Presence confidence', 0.2, 0.9, div: 14),
              _slider('minTracking', 'Tracking confidence', 0.2, 0.9, div: 14),
              _slider('maxFps', 'Max analysis rate', 8, 30, div: 22, unit: ' fps', sub: 'Lower saves battery and heat. 15–20 suits mid-range phones.'),
              const _H('Launch app action'),
              ListTile(
                title: const Text('Selected app'),
                subtitle: Text((c['appPackage'] as String).isEmpty ? 'None' : c['appPackage'] as String),
                trailing: const Icon(Icons.apps),
                onTap: _pickApp,
              ),
              const SizedBox(height: 40),
            ]),
    );
  }
}

class _H extends StatelessWidget {
  final String t;
  const _H(this.t);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
        child: Text(t, style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Theme.of(context).colorScheme.primary)),
      );
}
