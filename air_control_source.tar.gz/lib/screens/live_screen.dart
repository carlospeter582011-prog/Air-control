import 'dart:async';
import 'package:flutter/material.dart';
import '../native.dart';

/// Live hand view + calibration. Runs tracking in TEST MODE (no touches are sent) so it is safe.
class LiveScreen extends StatefulWidget {
  const LiveScreen({super.key});
  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

const _bones = [
  [0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [17, 18], [18, 19], [19, 20], [0, 17],
];

class _LiveScreenState extends State<LiveScreen> {
  StreamSubscription? _fs, _ss;
  HandFrame? _f;
  TrackingStatus _s = const TrackingStatus();
  bool _startedHere = false;
  String? _err;
  // calibration
  int _calStep = -1; // 0..3 = corners
  final _corners = <Offset>[];
  static const _names = ['top-left', 'top-right', 'bottom-right', 'bottom-left'];

  @override
  void initState() {
    super.initState();
    _begin();
  }

  Future<void> _begin() async {
    final p = await Native.permissions();
    if (p['camera'] != true) {
      setState(() => _err = 'Camera permission is not granted. Open Setup first.');
      return;
    }
    _ss = Native.status.listen((s) => mounted ? setState(() => _s = s) : null);
    _fs = Native.frames.listen((f) => mounted ? setState(() => _f = f) : null);
    final st = await Native.events.first.timeout(const Duration(seconds: 2), onTimeout: () => {});
    final running = st['type'] == 'status' && st['running'] == true;
    await Native.setDryRun(true);
    await Native.setFrameStream(true);
    if (!running) {
      _startedHere = true;
      await Native.start();
    }
  }

  @override
  void dispose() {
    _fs?.cancel();
    _ss?.cancel();
    Native.setFrameStream(false);
    Native.setDryRun(false);
    if (_startedHere) Native.stop();
    super.dispose();
  }

  Future<void> _capture() async {
    final f = _f;
    if (f == null || !f.hand || f.lm.length < 42) return;
    _corners.add(Offset(f.lm[16], f.lm[17]));
    if (_corners.length == 4) {
      final xs = _corners.map((o) => o.dx).toList()..sort();
      final ys = _corners.map((o) => o.dy).toList()..sort();
      final c = await Native.getConfig();
      c['calXMin'] = (xs[0] + xs[1]) / 2;
      c['calXMax'] = (xs[2] + xs[3]) / 2;
      c['calYMin'] = (ys[0] + ys[1]) / 2;
      c['calYMax'] = (ys[2] + ys[3]) / 2;
      final ok = await Native.setConfig(c);
      if (mounted) {
        setState(() { _calStep = -1; _corners.clear(); });
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(ok ? 'Calibration saved. Applied immediately.' : 'Could not save calibration.')));
      }
    } else {
      setState(() => _calStep = _corners.length);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Live test and calibration')),
      body: _err != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_err!)))
          : Column(children: [
              Container(
                width: double.infinity,
                color: Colors.amber.withOpacity(0.2),
                padding: const EdgeInsets.all(8),
                child: const Text('Test mode: nothing you do here taps or swipes other apps. The camera image is not shown or stored; only the hand outline is drawn.'),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: AspectRatio(
                    aspectRatio: 3 / 4,
                    child: Container(
                      decoration: BoxDecoration(border: Border.all(color: Colors.white24), borderRadius: BorderRadius.circular(12)),
                      child: CustomPaint(painter: _HandPainter(_f, _corners)),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(children: [
                  Text(!_s.running
                      ? (_s.reason.isNotEmpty ? _s.reason : 'Starting camera…')
                      : (_f?.hand ?? false)
                          ? 'Hand found · pose ${_f!.pose} · pinch ${_f!.pinch.toStringAsFixed(2)} · ${_s.fps} fps'
                          : 'No hand detected. Check lighting and distance (30–60 cm).'),
                  if (_s.lastAction.isNotEmpty) Text('Would do: ${_s.lastAction}'),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: _calStep < 0
                    ? FilledButton.icon(
                        onPressed: () => setState(() { _calStep = 0; _corners.clear(); }),
                        icon: const Icon(Icons.crop_free),
                        label: const Text('Calibrate pointer area'))
                    : Column(children: [
                        Text('Point your index finger where the ${_names[_calStep]} of the screen should be, hold still, then tap Capture.'),
                        const SizedBox(height: 8),
                        Row(children: [
                          Expanded(child: FilledButton(onPressed: _capture, child: Text('Capture ${_calStep + 1}/4'))),
                          const SizedBox(width: 8),
                          TextButton(onPressed: () => setState(() { _calStep = -1; _corners.clear(); }), child: const Text('Cancel')),
                        ]),
                      ]),
              ),
            ]),
    );
  }
}

class _HandPainter extends CustomPainter {
  final HandFrame? f;
  final List<Offset> corners;
  _HandPainter(this.f, this.corners);

  @override
  void paint(Canvas c, Size s) {
    final dot = Paint()..color = Colors.redAccent;
    for (final o in corners) {
      c.drawCircle(Offset(o.dx * s.width, o.dy * s.height), 6, dot);
    }
    final h = f;
    if (h == null || !h.hand || h.lm.length < 42) return;
    Offset p(int i) => Offset(h.lm[2 * i] * s.width, h.lm[2 * i + 1] * s.height);
    final line = Paint()..color = Colors.cyanAccent..strokeWidth = 3;
    for (final b in _bones) {
      c.drawLine(p(b[0]), p(b[1]), line);
    }
    final pt = Paint()..color = Colors.white;
    for (var i = 0; i < 21; i++) {
      c.drawCircle(p(i), i == 8 || i == 4 ? 7 : 4, i == 8 ? (Paint()..color = Colors.greenAccent) : pt);
    }
  }

  @override
  bool shouldRepaint(covariant _HandPainter old) => true;
}
