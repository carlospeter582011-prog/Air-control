import 'dart:async';
import 'package:flutter/material.dart';
import '../native.dart';
import 'setup_screen.dart';
import 'settings_screen.dart';
import 'mapping_screen.dart';
import 'live_screen.dart';
import 'help_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  TrackingStatus _s = const TrackingStatus();
  Map<String, bool> _p = {};
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _sub = Native.status.listen((s) => mounted ? setState(() => _s = s) : null);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sub?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    try {
      final p = await Native.permissions();
      if (mounted) setState(() => _p = p);
    } catch (_) {}
  }

  // bool get _ready => (_p['camera'] ?? false); // unused

  Future<void> _start() async {
    if (!(_p['camera'] ?? false)) {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => const SetupScreen()));
      await _refresh();
      if (!(_p['camera'] ?? false)) return;
    }
    if (!(_p['accessibility'] ?? false) && mounted) {
      final go = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Accessibility is off'),
          content: const Text(
              'Without Air Control\'s accessibility service, gestures are detected but nothing is tapped or swiped in other apps. '
              'You can still use the live test screen.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Start anyway')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Set up')),
          ],
        ),
      );
      if (go == true && mounted) {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => const SetupScreen()));
        await _refresh();
        return;
      }
    }
    await Native.start();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final label = !_s.running
        ? 'Stopped'
        : _s.paused
            ? 'Paused (no actions are sent)'
            : _s.hand
                ? 'Tracking: hand detected'
                : 'Tracking: looking for your hand';
    final color = !_s.running ? cs.outline : _s.paused ? Colors.amber : (_s.hand ? Colors.greenAccent : cs.primary);
    return Scaffold(
      appBar: AppBar(title: const Text('Air Control')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.circle, size: 14, color: color),
                  const SizedBox(width: 10),
                  Expanded(child: Text(label, style: Theme.of(context).textTheme.titleMedium)),
                  if (_s.running) Text('${_s.fps} fps'),
                ]),
                if (_s.running && _s.dryRun)
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text('Test mode: gestures are detected but no touches are sent.'),
                  ),
                if (_s.lastAction.isNotEmpty && _s.running)
                  Padding(padding: const EdgeInsets.only(top: 6), child: Text('Last: ${_s.lastAction}')),
                if (_s.reason.isNotEmpty && !_s.running)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(_s.reason, style: TextStyle(color: cs.error)),
                  ),
                const SizedBox(height: 16),
                Row(children: [
                  Expanded(
                    child: _s.running
                        ? FilledButton.tonalIcon(
                            onPressed: () => Native.setPaused(!_s.paused),
                            icon: Icon(_s.paused ? Icons.play_arrow : Icons.pause),
                            label: Text(_s.paused ? 'Resume' : 'Pause'),
                          )
                        : FilledButton.icon(
                            onPressed: _start,
                            icon: const Icon(Icons.play_arrow),
                            label: const Text('Start tracking'),
                          ),
                  ),
                  if (_s.running) ...[
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: cs.error, foregroundColor: cs.onError),
                        onPressed: Native.stop,
                        icon: const Icon(Icons.stop),
                        label: const Text('Stop'),
                      ),
                    ),
                  ],
                ]),
                const SizedBox(height: 8),
                const Text(
                  'The camera is only on while the status says Tracking or Paused, and a notification is shown the whole time. '
                  'Stop turns the camera off.',
                  style: TextStyle(fontSize: 12),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          _tile(Icons.verified_user, 'Permissions and setup', _summary(), () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const SetupScreen()));
            _refresh();
          }),
          _tile(Icons.videocam, 'Live test and calibration', 'See your hand, test gestures safely, set the pointer area', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const LiveScreen()));
          }),
          _tile(Icons.tune, 'Pointer and gesture settings', 'Speed, smoothing, thresholds, cooldowns, handedness', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
          }),
          _tile(Icons.gesture, 'Gesture mapping', 'Choose what each gesture does', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MappingScreen()));
          }),
          _tile(Icons.help_outline, 'Tutorial, privacy and troubleshooting', 'How to use it, what it can and cannot do', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpScreen()));
          }),
        ],
      ),
    );
  }

  String _summary() {
    if (_p.isEmpty) return 'Checking…';
    final miss = <String>[
      if (!(_p['camera'] ?? false)) 'camera',
      if (!(_p['accessibility'] ?? false)) 'accessibility',
      if (!(_p['notifications'] ?? false)) 'notifications',
    ];
    return miss.isEmpty ? 'All required access granted' : 'Missing: ${miss.join(', ')}';
  }

  Widget _tile(IconData i, String t, String s, VoidCallback f) => Card(
        child: ListTile(leading: Icon(i), title: Text(t), subtitle: Text(s), trailing: const Icon(Icons.chevron_right), onTap: f),
      );
}
