import 'dart:async';
import 'package:flutter/material.dart';
import '../native.dart';
import 'setup_screen.dart';
import 'settings_screen.dart';
import 'mapping_screen.dart';
import 'live_screen.dart';
import 'help_screen.dart';
import 'apps_screen.dart';
import 'social_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  TrackingStatus _s = const TrackingStatus();
  Map<String, bool> _p = {};
  Map<String, dynamic> _c = {};
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _sub = Native.status.listen((s) => mounted ? setState(() => _s = s) : null);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sub?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    try {
      final p = await Native.permissions();
      final c = await Native.getConfig();
      if (mounted) {
        setState(() {
          _p = p;
          _c = c;
        });
      }
    } catch (_) {}
  }

  Future<void> _open(Widget screen) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
    _refresh();
  }

  Future<void> _start() async {
    if (!(_p['camera'] ?? false)) {
      await _open(const SetupScreen());
      if (!(_p['camera'] ?? false)) return;
    }
    if (!(_p['accessibility'] ?? false) && mounted) {
      final go = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Accessibility is off'),
          content: const Text(
              'Without Air Control\'s accessibility service, gestures are detected but nothing is tapped or swiped in other apps. '
              'You can still use the live test screen.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Start anyway')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Set up')),
          ],
        ),
      );
      if (go == true && mounted) {
        await _open(const SetupScreen());
        return;
      }
    }
    await Native.start();
  }

  Future<void> _setSocial(String mode) async {
    final c = {..._c, 'socialMode': mode};
    setState(() => _c = c);
    await Native.setConfig(c);
  }

  String get _statusText {
    if (!_s.running) return 'Stopped';
    if (_s.gated) {
      return _s.cameraOn ? 'Camera on, gestures off until a chosen app opens' : 'Camera off until a chosen app opens';
    }
    return _s.hand ? 'Tracking: hand detected' : 'Tracking: looking for your hand';
  }

  String get _whereSummary {
    if (_c.isEmpty) return '';
    if (_c['appMode'] != 'selected') return 'Everywhere, until you press Stop';
    final n = ((_c['apps'] as List?) ?? const []).length;
    final out = _c['outsideBehavior'] == 'camera_off' ? 'camera off outside' : 'gestures off outside';
    return 'Only in $n chosen app${n == 1 ? '' : 's'} ($out)';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final color = !_s.running
        ? cs.outline
        : _s.gated
            ? Colors.amber
            : (_s.hand ? Colors.greenAccent : cs.primary);
    final mode = (_c['socialMode'] as String?) ?? 'off';
    final showReason = _s.reason.isNotEmpty && _s.reason != 'Stopped by you';
    return Scaffold(
      appBar: AppBar(
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/logo.png', width: 32, height: 32)),
          const SizedBox(width: 10),
          const Text('Air Control'),
        ]),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.circle, size: 14, color: color),
                  const SizedBox(width: 10),
                  Expanded(child: Text(_statusText, style: Theme.of(context).textTheme.titleMedium)),
                  if (_s.running && _s.cameraOn) Text('${_s.fps} fps'),
                ]),
                if (_s.running && _s.social)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Chip(
                      avatar: const Icon(Icons.bolt, size: 18),
                      label: Text('Social mode · ${_s.videoStyle == 'long' ? 'long videos' : 'short videos'}'),
                    ),
                  ),
                if (_s.running && _s.dryRun)
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text('Test mode: gestures are detected but no touches are sent.'),
                  ),
                if (_s.lastAction.isNotEmpty && _s.running) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Last: ${_s.lastAction}')),
                if (showReason)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(_s.reason, style: TextStyle(color: cs.error)),
                  ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: _s.running
                      ? FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: cs.error, foregroundColor: cs.onError),
                          onPressed: Native.stop,
                          icon: const Icon(Icons.stop),
                          label: const Text('Stop'),
                        )
                      : FilledButton.icon(
                          onPressed: _start,
                          icon: const Icon(Icons.play_arrow),
                          label: const Text('Start tracking'),
                        ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'It keeps running until you press Stop (here or in the notification). The camera is on while the notification '
                  'is showing, unless "chosen apps" mode has turned it off.',
                  style: TextStyle(fontSize: 12),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Icon(Icons.bolt),
                  const SizedBox(width: 8),
                  Text('Social mode', style: Theme.of(context).textTheme.titleSmall),
                ]),
                const SizedBox(height: 10),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'off', label: Text('Off')),
                    ButtonSegment(value: 'on', label: Text('On')),
                    ButtonSegment(value: 'auto', label: Text('Auto')),
                  ],
                  selected: {mode},
                  onSelectionChanged: (s) => _setSocial(s.first),
                ),
                const SizedBox(height: 6),
                const Text('Easier control for TikTok, Reels, Shorts, Facebook and YouTube. Auto turns on in social apps only.',
                    style: TextStyle(fontSize: 12)),
              ]),
            ),
          ),
          _tile(Icons.phone_android, 'Where it works', _whereSummary, () => _open(const AppsScreen())),
          _tile(Icons.verified_user, 'Permissions and setup', _summary(), () => _open(const SetupScreen())),
          _tile(Icons.videocam, 'Live test and calibration', 'See your hand, test gestures safely, set the pointer area',
              () => _open(const LiveScreen())),
          _tile(Icons.gesture, 'Gesture mapping', 'Choose what each gesture does; many gestures can do the same thing',
              () => _open(const MappingScreen())),
          _tile(Icons.smart_display, 'Social mode settings', 'Video style, button positions, social gestures',
              () => _open(const SocialScreen())),
          _tile(Icons.tune, 'Pointer and gesture settings', 'Speed, smoothing, thresholds, cooldowns, handedness',
              () => _open(const SettingsScreen())),
          _tile(Icons.help_outline, 'Tutorial, privacy and troubleshooting', 'How to use it, what it can and cannot do',
              () => _open(const HelpScreen())),
        ],
      ),
    );
  }

  String _summary() {
    if (_p.isEmpty) return 'Checking…';
    final miss = <String>[
      if (!(_p['camera'] ?? false)) 'camera',
      if (!(_p['accessibility'] ?? false)) 'accessibility',
      if (!(_p['notifications'] ?? false)) 'notifications',
    ];
    return miss.isEmpty ? 'All required access granted' : 'Missing: ${miss.join(', ')}';
  }

  Widget _tile(IconData i, String t, String s, VoidCallback f) => Card(
        child: ListTile(leading: Icon(i), title: Text(t), subtitle: Text(s), trailing: const Icon(Icons.chevron_right), onTap: f),
      );
}
