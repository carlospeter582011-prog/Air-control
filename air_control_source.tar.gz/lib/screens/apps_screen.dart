import 'package:flutter/material.dart';
import '../native.dart';
import 'app_picker.dart';

/// Choose whether Air Control works everywhere or only in selected apps.
class AppsScreen extends StatefulWidget {
  const AppsScreen({super.key});
  @override
  State<AppsScreen> createState() => _AppsScreenState();
}

class _AppsScreenState extends State<AppsScreen> {
  Map<String, dynamic>? _c;
  Map<String, String> _names = {};

  @override
  void initState() {
    super.initState();
    Native.getConfig().then((c) => mounted ? setState(() => _c = c) : null);
    Native.installedApps().then((a) {
      if (mounted) setState(() => _names = {for (final e in a) e['pkg']!: e['name']!});
    });
  }

  void _set(String k, dynamic v) {
    setState(() => _c![k] = v);
    Native.setConfig(_c!);
  }

  Set<String> get _apps => ((_c!['apps'] as List?) ?? const []).map((e) => e.toString()).toSet();

  Future<void> _pick() async {
    final r = await Navigator.push<Set<String>>(
      context,
      MaterialPageRoute(builder: (_) => AppPicker(title: 'Apps that use hand control', initial: _apps)),
    );
    if (r != null) _set('apps', r.toList());
  }

  Widget _choice(String key, String value, String title, String sub) {
    final on = _c![key] == value;
    return ListTile(
      leading: Icon(on ? Icons.radio_button_checked : Icons.radio_button_unchecked,
          color: on ? Theme.of(context).colorScheme.primary : null),
      title: Text(title),
      subtitle: Text(sub),
      onTap: () => _set(key, value),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    return Scaffold(
      appBar: AppBar(title: const Text('Where it works')),
      body: c == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              _choice('appMode', 'all', 'Everywhere',
                  'Runs until you press Stop. Nothing pauses it, even when your hand is not seen.'),
              _choice('appMode', 'selected', 'Only in chosen apps',
                  'Works while a chosen app is open and switches off when you leave it.'),
              if (c['appMode'] == 'selected') ...[
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.apps),
                  title: Text('Chosen apps (${_apps.length})'),
                  subtitle: Text(_apps.isEmpty
                      ? 'None yet: tap to choose'
                      : _apps.map((p) => _names[p] ?? p).take(6).join(', ') + (_apps.length > 6 ? '…' : '')),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: _pick,
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
                  child: Text('When you are outside those apps:', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                _choice('outsideBehavior', 'gestures_off', 'Keep camera on, stop gestures (recommended)',
                    'Most reliable. Gestures start again the moment you open a chosen app. Uses more battery.'),
                _choice('outsideBehavior', 'camera_off', 'Turn the camera off',
                    'Saves battery. The camera turns back on when you open a chosen app. Android may refuse to restart '
                    'the camera from the background on some phones; if so, the app tells you and you press Start again.'),
              ],
              const SizedBox(height: 16),
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'To know which app is open, Air Control\'s accessibility service reads only the app\'s package name when a window '
                    'comes to the front. It does not read anything on the screen. If accessibility access is off, chosen-apps mode '
                    'cannot see your apps and stays off.',
                  ),
                ),
              ),
            ]),
    );
  }
}
