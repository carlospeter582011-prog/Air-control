import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() => runApp(const AirControlApp());

class AirControlApp extends StatelessWidget {
  const AirControlApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(seedColor: const Color(0xFF00B8D9), brightness: Brightness.dark);
    return MaterialApp(
      title: 'Air Control',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: scheme, useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}
