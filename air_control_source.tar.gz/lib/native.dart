import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';

/// Every action the native layer understands, with an honest support note.
class ActionInfo {
  final String id;
  final String label;
  final String note;
  const ActionInfo(this.id, this.label, [this.note = '']);
}

const kActions = <ActionInfo>[
  ActionInfo('NONE', 'Do nothing'),
  ActionInfo('TAP', 'Tap at pointer'),
  ActionInfo('DOUBLE_TAP', 'Double tap'),
  ActionInfo('LONG_PRESS', 'Long press'),
  ActionInfo('DRAG', 'Drag and drop', 'Only meaningful on "Pinch and move".'),
  ActionInfo('SCROLL_UP', 'Scroll up (content moves up)'),
  ActionInfo('SCROLL_DOWN', 'Scroll down (content moves down)'),
  ActionInfo('SCROLL_LEFT', 'Scroll left'),
  ActionInfo('SCROLL_RIGHT', 'Scroll right'),
  ActionInfo('SWIPE_UP', 'Swipe up'),
  ActionInfo('SWIPE_DOWN', 'Swipe down'),
  ActionInfo('SWIPE_LEFT', 'Swipe left'),
  ActionInfo('SWIPE_RIGHT', 'Swipe right'),
  ActionInfo('BACK', 'Back'),
  ActionInfo('HOME', 'Home'),
  ActionInfo('RECENTS', 'Recent apps'),
  ActionInfo('NOTIFICATIONS', 'Open notification shade'),
  ActionInfo('QUICK_SETTINGS', 'Open Quick Settings'),
  ActionInfo('POWER_DIALOG', 'Power menu', 'Android 5+; some makers block it.'),
  ActionInfo('LOCK_SCREEN', 'Lock screen', 'Android 9+.'),
  ActionInfo('SCREENSHOT', 'Take screenshot', 'Android 9+; apps can mark screens as protected.'),
  ActionInfo('VOLUME_UP', 'Volume up (media)'),
  ActionInfo('VOLUME_DOWN', 'Volume down (media)'),
  ActionInfo('VOLUME_PANEL', 'Show volume panel'),
  ActionInfo('MUTE_TOGGLE', 'Mute / unmute media'),
  ActionInfo('PLAY_PAUSE', 'Play / pause media', 'Works with apps that respond to media keys.'),
  ActionInfo('NEXT_TRACK', 'Next track', 'Works with apps that respond to media keys.'),
  ActionInfo('PREV_TRACK', 'Previous track', 'Works with apps that respond to media keys.'),
  ActionInfo('BRIGHTNESS_UP', 'Brightness up', 'Needs "Modify system settings" access.'),
  ActionInfo('BRIGHTNESS_DOWN', 'Brightness down', 'Needs "Modify system settings" access.'),
  ActionInfo('OPEN_SETTINGS', 'Open Android Settings'),
  ActionInfo('OPEN_DISPLAY_SETTINGS', 'Open Display settings'),
  ActionInfo('OPEN_ACCESSIBILITY_SETTINGS', 'Open Accessibility settings (magnification etc.)'),
  ActionInfo('LAUNCH_APP', 'Launch chosen app', 'Choose the app in Settings.'),
  ActionInfo('PAUSE_TOGGLE', 'Pause / resume tracking'),
];

String actionLabel(String id) =>
    kActions.firstWhere((a) => a.id == id, orElse: () => ActionInfo(id, id)).label;

class GestureInfo {
  final String id;
  final String label;
  final String how;
  const GestureInfo(this.id, this.label, this.how);
}

const kGestures = <GestureInfo>[
  GestureInfo('pinch_click', 'Pinch (quick)', 'Touch thumb and index fingertip together, then release.'),
  GestureInfo('pinch_double', 'Two quick pinches', 'Pinch twice within the double-pinch window. Set to "Do nothing" for faster single taps.'),
  GestureInfo('pinch_hold', 'Pinch and hold', 'Keep pinching without moving for the long-press time.'),
  GestureInfo('pinch_drag', 'Pinch and move', 'Pinch, then move your hand. Set to "Do nothing" to disable dragging.'),
  GestureInfo('swipe_up', 'Open palm sweeps up', 'Open hand, move it quickly upward.'),
  GestureInfo('swipe_down', 'Open palm sweeps down', 'Open hand, move it quickly downward.'),
  GestureInfo('swipe_left', 'Open palm sweeps left', 'Open hand, move it quickly left (as you see it in the preview).'),
  GestureInfo('swipe_right', 'Open palm sweeps right', 'Open hand, move it quickly right.'),
  GestureInfo('open_palm_hold', 'Hold open palm', 'Keep a still open hand for the hold time.'),
  GestureInfo('fist_hold', 'Hold fist', 'Close your hand and keep it still.'),
  GestureInfo('peace_hold', 'Hold two fingers', 'Index and middle finger up, others curled.'),
  GestureInfo('thumbs_up_hold', 'Hold thumbs up', 'Fist with thumb pointing up.'),
  GestureInfo('thumbs_down_hold', 'Hold thumbs down', 'Fist with thumb pointing down.'),
];

class TrackingStatus {
  final bool running, paused, hand, dryRun;
  final int fps;
  final String reason, lastAction;
  const TrackingStatus({
    this.running = false,
    this.paused = false,
    this.hand = false,
    this.dryRun = false,
    this.fps = 0,
    this.reason = '',
    this.lastAction = '',
  });
  factory TrackingStatus.fromMap(Map m) => TrackingStatus(
        running: m['running'] == true,
        paused: m['paused'] == true,
        hand: m['hand'] == true,
        dryRun: m['dryRun'] == true,
        fps: (m['fps'] as num?)?.toInt() ?? 0,
        reason: (m['reason'] as String?) ?? '',
        lastAction: (m['lastAction'] as String?) ?? '',
      );
}

class HandFrame {
  final bool hand;
  final List<double> lm; // 42 values: x,y pairs, mirrored selfie view
  final String pose;
  final double pinch;
  const HandFrame(this.hand, this.lm, this.pose, this.pinch);
}

class Native {
  static const _m = MethodChannel('air_control/methods');
  static const _e = EventChannel('air_control/events');

  static Stream<Map>? _shared;
  static Stream<Map> get events =>
      _shared ??= _e.receiveBroadcastStream().map((e) => Map<dynamic, dynamic>.from(e as Map)).asBroadcastStream();

  static Stream<TrackingStatus> get status =>
      events.where((e) => e['type'] == 'status').map(TrackingStatus.fromMap);

  static Stream<HandFrame> get frames => events.where((e) => e['type'] == 'frame').map((e) => HandFrame(
        e['hand'] == true,
        ((e['lm'] as List?) ?? const []).map((v) => (v as num).toDouble()).toList(),
        (e['pose'] as String?) ?? 'NONE',
        (e['pinch'] as num?)?.toDouble() ?? 0,
      ));

  static Future<Map<String, bool>> permissions() async {
    final r = await _m.invokeMethod<Map>('permissions');
    return {for (final e in (r ?? {}).entries) e.key as String: e.value == true};
  }

  static Future<void> requestCamera() => _m.invokeMethod('requestCamera');
  static Future<void> requestNotifications() => _m.invokeMethod('requestNotifications');
  static Future<void> openAccessibilitySettings() => _m.invokeMethod('openAccessibilitySettings');
  static Future<void> openAppDetails() => _m.invokeMethod('openAppDetails');
  static Future<void> openWriteSettings() => _m.invokeMethod('openWriteSettings');
  static Future<void> openBatterySettings() => _m.invokeMethod('openBatterySettings');
  static Future<void> start() => _m.invokeMethod('start');
  static Future<void> stop() => _m.invokeMethod('stop');
  static Future<void> setPaused(bool p) => _m.invokeMethod('setPaused', {'paused': p});
  static Future<void> setDryRun(bool on) => _m.invokeMethod('setDryRun', {'on': on});
  static Future<void> setFrameStream(bool on) => _m.invokeMethod('setFrameStream', {'on': on});
  static Future<int> sdkInt() async => (await _m.invokeMethod<int>('sdkInt')) ?? 0;
  static Future<String?> testAction(String a) => _m.invokeMethod<String>('testAction', {'action': a});

  static Future<List<Map<String, String>>> installedApps() async {
    final r = await _m.invokeMethod<List>('installedApps');
    return (r ?? []).map((e) => Map<String, String>.from(e as Map)).toList();
  }

  static Future<Map<String, dynamic>> getConfig() async {
    final s = await _m.invokeMethod<String>('getConfig');
    return Map<String, dynamic>.from(jsonDecode(s ?? '{}') as Map);
  }

  static Future<Map<String, dynamic>> defaultConfig() async {
    final s = await _m.invokeMethod<String>('defaultConfig');
    return Map<String, dynamic>.from(jsonDecode(s ?? '{}') as Map);
  }

  static Future<bool> setConfig(Map<String, dynamic> c) async =>
      (await _m.invokeMethod<bool>('setConfig', {'json': jsonEncode(c)})) == true;
}
