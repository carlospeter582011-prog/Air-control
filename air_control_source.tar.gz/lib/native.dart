import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';

/// Every action the native layer understands, with an honest support note.
class ActionInfo {
  final String id;
  final String label;
  final String group;
  final String note;
  const ActionInfo(this.id, this.label, this.group, [this.note = '']);
}

const kActions = <ActionInfo>[
  ActionInfo('NONE', 'Do nothing', 'Other'),
  ActionInfo('TAP', 'Tap at pointer', 'Touch'),
  ActionInfo('DOUBLE_TAP', 'Double tap', 'Touch'),
  ActionInfo('LONG_PRESS', 'Long press', 'Touch'),
  ActionInfo('DRAG', 'Drag and drop', 'Touch', 'Only meaningful on "Pinch and move".'),
  ActionInfo('SCROLL_UP', 'Scroll up (content moves up)', 'Touch', 'Repeats while the gesture is held.'),
  ActionInfo('SCROLL_DOWN', 'Scroll down (content moves down)', 'Touch', 'Repeats while the gesture is held.'),
  ActionInfo('SCROLL_LEFT', 'Scroll left', 'Touch'),
  ActionInfo('SCROLL_RIGHT', 'Scroll right', 'Touch'),
  ActionInfo('SWIPE_UP', 'Swipe up', 'Touch'),
  ActionInfo('SWIPE_DOWN', 'Swipe down', 'Touch'),
  ActionInfo('SWIPE_LEFT', 'Swipe left', 'Touch'),
  ActionInfo('SWIPE_RIGHT', 'Swipe right', 'Touch'),
  ActionInfo('BACK', 'Back', 'Navigation'),
  ActionInfo('HOME', 'Home', 'Navigation'),
  ActionInfo('RECENTS', 'Recent apps', 'Navigation'),
  ActionInfo('NOTIFICATIONS', 'Open notification shade', 'Navigation'),
  ActionInfo('QUICK_SETTINGS', 'Open Quick Settings', 'Navigation'),
  ActionInfo('POWER_DIALOG', 'Power menu', 'Navigation', 'Some phone makers block it.'),
  ActionInfo('LOCK_SCREEN', 'Lock screen', 'Navigation', 'Android 9+.'),
  ActionInfo('SCREENSHOT', 'Take screenshot', 'Navigation', 'Android 9+; protected screens cannot be captured.'),
  ActionInfo('LAUNCH_APP', 'Launch chosen app', 'Navigation', 'Choose the app in Settings.'),
  ActionInfo('OPEN_SETTINGS', 'Open Android Settings', 'Navigation'),
  ActionInfo('OPEN_DISPLAY_SETTINGS', 'Open Display settings', 'Navigation'),
  ActionInfo('OPEN_ACCESSIBILITY_SETTINGS', 'Open Accessibility settings (magnification etc.)', 'Navigation'),
  ActionInfo('VOLUME_UP', 'Volume up (media)', 'Sound and screen', 'Keeps rising while the gesture is held; stops when you stop.'),
  ActionInfo('VOLUME_DOWN', 'Volume down (media)', 'Sound and screen', 'Keeps falling while the gesture is held; stops when you stop.'),
  ActionInfo('VOLUME_PANEL', 'Show volume panel', 'Sound and screen'),
  ActionInfo('MUTE_TOGGLE', 'Mute / unmute media', 'Sound and screen'),
  ActionInfo('PLAY_PAUSE', 'Play / pause media', 'Sound and screen', 'Works with apps that respond to media keys.'),
  ActionInfo('NEXT_TRACK', 'Next track', 'Sound and screen', 'Works with apps that respond to media keys.'),
  ActionInfo('PREV_TRACK', 'Previous track', 'Sound and screen', 'Works with apps that respond to media keys.'),
  ActionInfo('BRIGHTNESS_UP', 'Brightness up', 'Sound and screen', 'Needs "Modify system settings" access. Repeats while held.'),
  ActionInfo('BRIGHTNESS_DOWN', 'Brightness down', 'Sound and screen', 'Needs "Modify system settings" access. Repeats while held.'),
  ActionInfo('SOCIAL_NEXT', 'Next video', 'Social', 'Short style: swipe up. Long style: skip forward 10 s.'),
  ActionInfo('SOCIAL_PREV', 'Previous video', 'Social', 'Short style: swipe down. Long style: skip back 10 s.'),
  ActionInfo('SOCIAL_LIKE', 'Like (double tap on video)', 'Social', 'Short style only.'),
  ActionInfo('SOCIAL_PLAY_PAUSE', 'Play / pause (tap on video)', 'Social'),
  ActionInfo('SOCIAL_COMMENTS', 'Open comments', 'Social', 'Taps a screen position you can adjust. Short style only.'),
  ActionInfo('SOCIAL_SHARE', 'Open share', 'Social', 'Taps a screen position you can adjust. Short style only.'),
  ActionInfo('SOCIAL_COMMENTS_SCROLL_DOWN', 'Scroll comments down', 'Social', 'Repeats while held.'),
  ActionInfo('SOCIAL_COMMENTS_SCROLL_UP', 'Scroll comments up', 'Social', 'Repeats while held.'),
  ActionInfo('TOGGLE_SOCIAL_MODE', 'Turn Social mode on / off', 'Other'),
  ActionInfo('TOGGLE_VIDEO_STYLE', 'Switch short / long video style', 'Other'),
];

String actionLabel(String id) =>
    kActions.firstWhere((a) => a.id == id, orElse: () => ActionInfo(id, id, 'Other')).label;

class GestureInfo {
  final String id;
  final String label;
  final String how;
  final String group;
  const GestureInfo(this.id, this.label, this.how, this.group);
}

const kGestures = <GestureInfo>[
  GestureInfo('pinch_click', 'Pinch (quick)', 'Touch thumb and index fingertip together, then release.', 'Pinch'),
  GestureInfo('pinch_double', 'Two quick pinches', 'Pinch twice within the double-pinch window. Set to "Do nothing" for faster single taps.', 'Pinch'),
  GestureInfo('pinch_hold', 'Pinch and hold', 'Keep pinching without moving for the long-press time.', 'Pinch'),
  GestureInfo('pinch_drag', 'Pinch and move', 'Pinch, then move your hand. Set to "Do nothing" to disable dragging.', 'Pinch'),
  GestureInfo('pinch_middle', 'Thumb + middle finger', 'Touch thumb to middle fingertip, keeping the other three fingers straight.', 'Pinch'),
  GestureInfo('pinch_ring', 'Thumb + ring finger', 'Touch thumb to ring fingertip, keeping the other three fingers straight.', 'Pinch'),
  GestureInfo('pinch_pinky', 'Thumb + little finger', 'Touch thumb to little fingertip, keeping the other three fingers straight.', 'Pinch'),
  GestureInfo('swipe_up', 'Open palm sweeps up', 'Open hand, move it quickly upward.', 'Motion'),
  GestureInfo('swipe_down', 'Open palm sweeps down', 'Open hand, move it quickly downward.', 'Motion'),
  GestureInfo('swipe_left', 'Open palm sweeps left', 'Open hand, move it quickly left (as you see it in the preview).', 'Motion'),
  GestureInfo('swipe_right', 'Open palm sweeps right', 'Open hand, move it quickly right.', 'Motion'),
  GestureInfo('open_palm_hold', 'Hold open palm', 'Keep a still open hand for the hold time.', 'Hold a pose'),
  GestureInfo('fist_hold', 'Hold fist', 'Close your hand (thumb tucked) and keep it still.', 'Hold a pose'),
  GestureInfo('peace_hold', 'Hold two fingers', 'Index and middle finger up, others curled.', 'Hold a pose'),
  GestureInfo('three_hold', 'Hold three fingers', 'Index, middle and ring finger up, little finger curled.', 'Hold a pose'),
  GestureInfo('rock_hold', 'Hold rock sign', 'Index and little finger up, middle and ring curled.', 'Hold a pose'),
  GestureInfo('call_hold', 'Hold call sign', 'Thumb and little finger out, other fingers curled.', 'Hold a pose'),
  GestureInfo('pinky_hold', 'Hold little finger', 'Only the little finger up, thumb tucked.', 'Hold a pose'),
  GestureInfo('thumbs_up_hold', 'Hold thumbs up', 'Fist with thumb pointing up.', 'Hold a pose'),
  GestureInfo('thumbs_down_hold', 'Hold thumbs down', 'Fist with thumb pointing down.', 'Hold a pose'),
];

class TrackingStatus {
  final bool running, hand, dryRun, gated, cameraOn, social;
  final int fps;
  final String reason, lastAction, videoStyle, app;
  const TrackingStatus({
    this.running = false,
    this.hand = false,
    this.dryRun = false,
    this.gated = false,
    this.cameraOn = false,
    this.social = false,
    this.fps = 0,
    this.reason = '',
    this.lastAction = '',
    this.videoStyle = 'short',
    this.app = '',
  });
  factory TrackingStatus.fromMap(Map m) => TrackingStatus(
        running: m['running'] == true,
        hand: m['hand'] == true,
        dryRun: m['dryRun'] == true,
        gated: m['gated'] == true,
        cameraOn: m['cameraOn'] == true,
        social: m['social'] == true,
        fps: (m['fps'] as num?)?.toInt() ?? 0,
        reason: (m['reason'] as String?) ?? '',
        lastAction: (m['lastAction'] as String?) ?? '',
        videoStyle: (m['videoStyle'] as String?) ?? 'short',
        app: (m['app'] as String?) ?? '',
      );
}

class HandFrame {
  final bool hand;
  final List<double> lm; // 42 values: x,y pairs, mirrored selfie view
  final String pose;
  final double pinch;
  const HandFrame(this.hand, this.lm, this.pose, this.pinch);
}

class Native {
  static const _m = MethodChannel('air_control/methods');
  static const _e = EventChannel('air_control/events');

  static Stream<Map>? _shared;
  static Stream<Map> get events =>
      _shared ??= _e.receiveBroadcastStream().map((e) => Map<dynamic, dynamic>.from(e as Map)).asBroadcastStream();

  static Stream<TrackingStatus> get status =>
      events.where((e) => e['type'] == 'status').map(TrackingStatus.fromMap);

  static Stream<HandFrame> get frames => events.where((e) => e['type'] == 'frame').map((e) => HandFrame(
        e['hand'] == true,
        ((e['lm'] as List?) ?? const []).map((v) => (v as num).toDouble()).toList(),
        (e['pose'] as String?) ?? 'NONE',
        (e['pinch'] as num?)?.toDouble() ?? 0,
      ));

  static Future<Map<String, bool>> permissions() async {
    final r = await _m.invokeMethod<Map>('permissions');
    return {for (final e in (r ?? {}).entries) e.key as String: e.value == true};
  }

  static Future<void> requestCamera() => _m.invokeMethod('requestCamera');
  static Future<void> requestNotifications() => _m.invokeMethod('requestNotifications');
  static Future<void> openAccessibilitySettings() => _m.invokeMethod('openAccessibilitySettings');
  static Future<void> openAppDetails() => _m.invokeMethod('openAppDetails');
  static Future<void> openWriteSettings() => _m.invokeMethod('openWriteSettings');
  static Future<void> openBatterySettings() => _m.invokeMethod('openBatterySettings');
  static Future<void> start() => _m.invokeMethod('start');
  static Future<void> stop() => _m.invokeMethod('stop');
  static Future<void> setDryRun(bool on) => _m.invokeMethod('setDryRun', {'on': on});
  static Future<void> setFrameStream(bool on) => _m.invokeMethod('setFrameStream', {'on': on});
  static Future<int> sdkInt() async => (await _m.invokeMethod<int>('sdkInt')) ?? 0;
  static Future<String?> testAction(String a) => _m.invokeMethod<String>('testAction', {'action': a});

  static Future<List<Map<String, String>>> installedApps() async {
    final r = await _m.invokeMethod<List>('installedApps');
    return (r ?? []).map((e) => Map<String, String>.from(e as Map)).toList();
  }

  static Future<Map<String, dynamic>> getConfig() async {
    final s = await _m.invokeMethod<String>('getConfig');
    return Map<String, dynamic>.from(jsonDecode(s ?? '{}') as Map);
  }

  static Future<Map<String, dynamic>> defaultConfig() async {
    final s = await _m.invokeMethod<String>('defaultConfig');
    return Map<String, dynamic>.from(jsonDecode(s ?? '{}') as Map);
  }

  static Future<bool> setConfig(Map<String, dynamic> c) async =>
      (await _m.invokeMethod<bool>('setConfig', {'json': jsonEncode(c)})) == true;
}
