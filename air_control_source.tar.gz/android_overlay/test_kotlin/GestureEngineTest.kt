package __PKG__

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * JVM unit tests for GestureEngine. Run with: ./gradlew :app:testDebugUnitTest
 */
class GestureEngineTest {

    private class Rec : GestureEngine.Output {
        val actions = mutableListOf<String>()
        var drags = 0; var dragEnds = 0
        override fun pointer(x: Float, y: Float) {}
        override fun action(action: String, gesture: String, x: Float, y: Float) { actions += action }
        override fun dragStart(x: Float, y: Float) { drags++ }
        override fun dragMove(x: Float, y: Float) {}
        override fun dragEnd(x: Float, y: Float) { dragEnds++ }
        override fun pauseChanged(paused: Boolean) {}
        override fun info(pose: String, pinchRatio: Float) {}
    }

    private fun cfg() = Config(org.json.JSONObject())

    /**
     * General hand builder. Wrist (0.5,0.9), palm size 0.3. A finger is "extended" when its tip is far from the
     * wrist (y 0.28) and curled when it is near it (y 0.68). thumb: "out", "up", "tucked".
     * thumbTip overrides the thumb tip position (used for pinches).
     */
    private fun build(
        idx: Boolean = false, mid: Boolean = false, ring: Boolean = false, pinky: Boolean = false,
        thumb: String = "tucked", thumbTip: FloatArray? = null,
        idxTipX: Float = 0.45f, mcpX: Float = 0.45f
    ): FloatArray {
        val lm = FloatArray(42)
        fun set(i: Int, x: Float, y: Float) { lm[2 * i] = x; lm[2 * i + 1] = y }
        set(0, 0.5f, 0.9f)
        set(1, 0.42f, 0.82f); set(2, 0.38f, 0.76f); set(3, 0.35f, 0.72f)
        val tt = thumbTip ?: when (thumb) {
            "out" -> floatArrayOf(0.28f, 0.62f)
            "up" -> floatArrayOf(0.37f, 0.40f)
            else -> floatArrayOf(0.42f, 0.70f)
        }
        set(4, tt[0], tt[1])
        fun finger(mcp: Int, x: Float, mcpY: Float, ext: Boolean, tipX: Float = x) {
            set(mcp, if (mcp == 5) mcpX else x, mcpY)
            set(mcp + 1, x, 0.55f)
            set(mcp + 2, x, if (ext) 0.42f else 0.62f)
            set(mcp + 3, tipX, if (ext) 0.28f else 0.68f)
        }
        finger(5, 0.45f, 0.62f, idx, idxTipX)
        finger(9, 0.50f, 0.60f, mid)
        finger(13, 0.55f, 0.62f, ring)
        finger(17, 0.60f, 0.66f, pinky)
        return lm
    }

    private fun run(e: GestureEngine, lm: FloatArray, from: Long, ms: Long, step: Long = 50): Long {
        var t = from
        val end = from + ms
        while (t < end) { e.onHand(lm, t); t += step }
        return t
    }

    // pinch with thumb tip touching index tip (index extended)
    private fun pinch() = build(idx = true, thumbTip = floatArrayOf(0.45f, 0.28f))
    private fun point() = build(idx = true, thumb = "tucked")

    // ------------------------------------------------------------------ original behaviours

    @Test fun holdingPinchFiresLongPressOnceNotTap() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = run(e, point(), 1000, 500)
        run(e, pinch(), t, 3000)
        assertEquals(1, rec.actions.count { it == "LONG_PRESS" })
        assertFalse(rec.actions.contains("TAP"))
    }

    @Test fun shortPinchIsSingleTapAfterDoubleWindow() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = run(e, point(), 1000, 500)
        t = run(e, pinch(), t, 150)
        run(e, point(), t, 1000)
        assertEquals(listOf("TAP"), rec.actions)
    }

    @Test fun twoQuickPinchesAreOneDoubleTap() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = run(e, point(), 1000, 400, 40)
        repeat(2) {
            t = run(e, pinch(), t, 80, 40)
            t = run(e, point(), t, 80, 40)
        }
        run(e, point(), t, 800, 40)
        assertEquals(listOf("DOUBLE_TAP"), rec.actions)
    }

    @Test fun losingHandReleasesDrag() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = run(e, point(), 1000, 500)
        t = run(e, pinch(), t, 50)
        for (k in 1..12) {
            e.onHand(build(idx = true, thumbTip = floatArrayOf(0.45f + 0.02f * k, 0.28f), idxTipX = 0.45f + 0.02f * k, mcpX = 0.45f + 0.02f * k), t)
            t += 50
        }
        assertTrue(rec.drags >= 1)
        e.onNoHand(t + 100)
        e.onNoHand(t + 900)
        assertEquals(rec.drags, rec.dragEnds)
    }

    @Test fun gateSuspensionSendsNoActions() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        e.setPaused(true)
        var t = run(e, point(), 1000, 500)
        t = run(e, pinch(), t, 150)
        run(e, point(), t, 1000)
        assertTrue(rec.actions.isEmpty())
    }

    // ------------------------------------------------------------------ new behaviours

    @Test fun volumeRepeatsWhileHeldAndStopsWhenPoseChanges() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = run(e, build(thumb = "up"), 1000, 3000)
        val whileHeld = rec.actions.count { it == "VOLUME_UP" }
        assertTrue("expected repeats, got $whileHeld", whileHeld >= 6)
        t = run(e, build(), t, 100)                 // fist, thumb tucked: pose changes
        val atChange = rec.actions.count { it == "VOLUME_UP" }
        run(e, build(), t, 1500)
        assertEquals(atChange, rec.actions.count { it == "VOLUME_UP" })
    }

    @Test fun volumeStopsWhenHandDisappears() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        val t = run(e, build(thumb = "up"), 1000, 2000)
        val n = rec.actions.count { it == "VOLUME_UP" }
        e.onNoHand(t + 100); e.onNoHand(t + 1000); e.onNoHand(t + 2000)
        assertEquals(n, rec.actions.count { it == "VOLUME_UP" })
    }

    @Test fun oneShotHoldFiresOnceEvenIfHeldLong() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        run(e, build(idx = true, mid = true, ring = true, pinky = true, thumb = "out"), 1000, 5000)
        assertEquals(listOf("HOME"), rec.actions)
    }

    @Test fun rockSignFiresQuickSettingsOnce() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        run(e, build(idx = true, pinky = true), 1000, 3000)
        assertEquals(listOf("QUICK_SETTINGS"), rec.actions)
    }

    @Test fun threeFingersAndCallSign() {
        val r1 = Rec(); val e1 = GestureEngine(cfg(), r1)
        run(e1, build(idx = true, mid = true, ring = true), 1000, 2500)
        assertEquals(listOf("NOTIFICATIONS"), r1.actions)
        val r2 = Rec(); val e2 = GestureEngine(cfg(), r2)
        run(e2, build(pinky = true, thumb = "out"), 1000, 2500)
        assertEquals(listOf("NEXT_TRACK"), r2.actions)
        val r3 = Rec(); val e3 = GestureEngine(cfg(), r3)
        run(e3, build(pinky = true), 1000, 2500)
        assertEquals(listOf("PREV_TRACK"), r3.actions)
    }

    @Test fun middleFingerPinchIsBackAndFiresOnce() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        // thumb tip touches the (curled) middle fingertip, other three fingers extended
        val lm = build(idx = true, ring = true, pinky = true, thumbTip = floatArrayOf(0.50f, 0.66f))
        run(e, lm, 1000, 2000)
        assertEquals(listOf("BACK"), rec.actions)
    }

    @Test fun fistWithThumbAcrossDoesNotTriggerFingerPinch() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        run(e, build(thumbTip = floatArrayOf(0.50f, 0.66f)), 1000, 3000)
        assertTrue(rec.actions.isEmpty())
    }

    @Test fun sameActionCanBeMappedToManyGestures() {
        val j = org.json.JSONObject()
        val m = org.json.JSONObject()
        m.put("rock_hold", "HOME"); m.put("three_hold", "HOME")
        j.put("mapping", m)
        val c = Config(j)
        assertEquals("HOME", c.mapping("rock_hold"))
        assertEquals("HOME", c.mapping("three_hold"))
        assertEquals("HOME", c.mapping("open_palm_hold"))
    }

    @Test fun socialModeUsesSocialMapping() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        e.setSocial(true)
        var t = run(e, point(), 1000, 400, 40)
        repeat(2) {
            t = run(e, pinch(), t, 80, 40)
            t = run(e, point(), t, 80, 40)
        }
        run(e, point(), t, 800, 40)
        assertEquals(listOf("SOCIAL_LIKE"), rec.actions)
    }

    @Test fun removedPauseActionReadsAsNothing() {
        val j = org.json.JSONObject()
        val m = org.json.JSONObject()
        m.put("fist_hold", "PAUSE_TOGGLE")
        j.put("mapping", m)
        assertEquals("NONE", Config(j).mapping("fist_hold"))
    }

    @Test fun handLossNeverPausesAndGesturesWorkAfterReturn() {
        val rec = Rec(); val e = GestureEngine(cfg(), rec)
        var t = run(e, point(), 1000, 500)
        e.onNoHand(t + 100); e.onNoHand(t + 1500); e.onNoHand(t + 3000)
        assertFalse(e.paused)
        t += 3200
        t = run(e, point(), t, 500)
        t = run(e, pinch(), t, 150)
        run(e, point(), t, 1000)
        assertEquals(listOf("TAP"), rec.actions)
    }
}
