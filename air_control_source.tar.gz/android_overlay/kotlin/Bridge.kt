package __PKG__

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import io.flutter.plugin.common.EventChannel

/**
 * Process-wide state shared by the foreground service, the accessibility service and the Flutter UI.
 * Contains only tracking status text and hand landmarks (never camera frames or screen contents).
 */
object Bridge {
    @Volatile var sink: EventChannel.EventSink? = null
    @Volatile var running = false
    @Volatile var paused = false
    @Volatile var handPresent = false
    @Volatile var fps = 0
    @Volatile var reason = ""
    @Volatile var lastAction = ""
    @Volatile var dryRun = false
    @Volatile var frameStream = false

    private val main = Handler(Looper.getMainLooper())
    private var lastFrameEmit = 0L

    fun emit(map: Map<String, Any?>) {
        val s = sink ?: return
        main.post { try { s.success(map) } catch (_: Exception) { } }
    }

    fun statusMap(): Map<String, Any?> = mapOf(
        "type" to "status",
        "running" to running,
        "paused" to paused,
        "hand" to handPresent,
        "fps" to fps,
        "reason" to reason,
        "lastAction" to lastAction,
        "dryRun" to dryRun
    )

    fun emitStatus() = emit(statusMap())

    fun emitFrame(lm: FloatArray?, pose: String, pinch: Float) {
        if (!frameStream || sink == null) return
        val now = SystemClock.uptimeMillis()
        if (now - lastFrameEmit < 60) return
        lastFrameEmit = now
        emit(mapOf(
            "type" to "frame",
            "hand" to (lm != null),
            "lm" to (lm?.map { it.toDouble() } ?: emptyList<Double>()),
            "pose" to pose,
            "pinch" to pinch.toDouble(),
            "fps" to fps
        ))
    }
}
