package __PKG__

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import androidx.core.content.ContextCompat
import android.graphics.PixelFormat
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Cross-app touch injection and global actions.
 * Declared with canPerformGestures=true and NO event types / no window content retrieval, so it never
 * reads screen contents. The pointer dot is an accessibility overlay window, which needs no extra
 * "draw over other apps" permission.
 */
class AirAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: AirAccessibilityService? = null
        @Volatile var currentPkg: String = ""
        fun isEnabled() = instance != null
        private val IGNORED = setOf(
            "com.android.systemui", "android", "com.google.android.permissioncontroller",
            "com.android.permissioncontroller", "com.samsung.android.app.cocktailbarservice"
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var dot: View? = null
    private var dotParams: WindowManager.LayoutParams? = null
    private var dotSize = 56
    private var dotBig = false
    private var imePkgs: Set<String> = emptySet()

    // drag state
    private var dragStroke: GestureDescription.StrokeDescription? = null
    private var dragLastX = 0f
    private var dragLastY = 0f
    private var dragTargetX = 0f
    private var dragTargetY = 0f
    private var dragBusy = false
    private var dragActive = false

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        refreshImePackages()
        applyConfig()
        Bridge.emitStatus()
    }

    // ------------------------------------------------------------------ floating start / stop button

    private var fab: FabView? = null
    private var fabParams: WindowManager.LayoutParams? = null

    /** Small round button: grey play = stopped, green square = running, amber = running but waiting for a chosen app. */
    private inner class FabView(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var downX = 0f; private var downY = 0f
        private var startPx = 0; private var startPy = 0
        private var moved = false
        private var flashUntil = 0L

        fun flashError() { flashUntil = System.currentTimeMillis() + 900; invalidate(); postDelayed({ invalidate() }, 950) }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val r = w / 2f
            val ring = when {
                System.currentTimeMillis() < flashUntil -> Color.rgb(255, 82, 82)
                !Bridge.running -> Color.rgb(176, 190, 197)
                Bridge.gated -> Color.rgb(255, 193, 7)
                else -> Color.rgb(0, 230, 118)
            }
            p.style = Paint.Style.FILL; p.color = Color.argb(150, 12, 24, 40)
            c.drawCircle(r, r, r - 2f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.07f; p.color = ring
            c.drawCircle(r, r, r - w * 0.07f, p)
            p.style = Paint.Style.FILL; p.color = ring
            if (Bridge.running) {
                val q = w * 0.17f
                c.drawRoundRect(r - q, r - q, r + q, r + q, 3f, 3f, p)
            } else {
                val path = Path()
                path.moveTo(r - w * 0.10f, r - w * 0.20f)
                path.lineTo(r + w * 0.22f, r)
                path.lineTo(r - w * 0.10f, r + w * 0.20f)
                path.close()
                c.drawPath(path, p)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val params = fabParams ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startPx = params.x; startPy = params.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!moved && (Math.abs(dx) > 12 || Math.abs(dy) > 12)) moved = true
                    if (moved) {
                        val (sw, sh) = screenSize()
                        params.x = (startPx + dx).toInt().coerceIn(0, (sw - width).toInt())
                        params.y = (startPy + dy).toInt().coerceIn(0, (sh - height).toInt())
                        try { wm?.updateViewLayout(this, params) } catch (_: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        val (sw, sh) = screenSize()
                        Config.update(this@AirAccessibilityService, "floatX", params.x / sw.toDouble())
                        Config.update(this@AirAccessibilityService, "floatY", params.y / sh.toDouble())
                    } else toggleTracking()
                }
            }
            return true
        }
    }

    private fun toggleTracking() {
        if (Bridge.running) {
            val s = TrackingService.instance
            if (s != null) s.stopTracking("Stopped by you") else { Bridge.running = false; Bridge.emitStatus() }
            return
        }
        try {
            ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START))
        } catch (e: Exception) {
            Bridge.reason = "Android did not allow starting the camera from here. Opening Air Control to start it."
            Bridge.emitStatus()
            fab?.flashError()
            openAppToStart()
        }
    }

    /** Fallback when Android refuses to start the camera service from the background. */
    fun openAppToStart() {
        try {
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("autostart", true))
        } catch (e: Exception) {
            Bridge.reason = "Android would not open Air Control from the button. Open the app and press Start."
            Bridge.emitStatus()
            fab?.flashError()
        }
    }

    /** Shows / hides the floating button according to settings. Safe to call at any time. */
    fun applyConfig() = main.post {
        val cfg = Config.load(this)
        if (cfg.b("floatButton", true)) showFab(cfg) else removeFab()
    }

    private fun showFab(cfg: Config) {
        val (sw, sh) = screenSize()
        val size = (40 * resources.displayMetrics.density).toInt()
        if (fab != null) { refreshFab(); return }
        try {
            val v = FabView(this)
            v.alpha = 0.8f
            val p = WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.START
            p.x = (cfg.f("floatX", 0.90f) * sw).toInt().coerceIn(0, (sw - size).toInt())
            p.y = (cfg.f("floatY", 0.30f) * sh).toInt().coerceIn(0, (sh - size).toInt())
            wm?.addView(v, p)
            fab = v; fabParams = p
        } catch (e: Exception) { fab = null }
    }

    private fun removeFab() {
        val v = fab ?: return
        try { wm?.removeView(v) } catch (_: Exception) { }
        fab = null; fabParams = null
    }

    /** Repaints the button after tracking starts / stops. */
    fun refreshFab() { main.post { fab?.invalidate() } }

    private fun refreshImePackages() {
        imePkgs = try {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) { emptySet() }
    }

    /**
     * Only the package name of the window that came to the front is used (to know which app is open).
     * Nothing about the window's content is read. System UI, keyboards and our own windows are ignored so the
     * "current app" does not flicker when the notification shade or keyboard opens.
     */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg in IGNORED || pkg in imePkgs) return
        if (pkg == currentPkg) return
        currentPkg = pkg
        Bridge.app = pkg
        TrackingService.instance?.onForegroundApp(pkg)
    }
    override fun onInterrupt() { cancelDrag() }

    override fun onUnbind(intent: Intent?): Boolean {
        cancelDrag(); removeDot(); removeFab(); instance = null
        Bridge.reason = "Accessibility access was turned off"
        Bridge.emitStatus()
        return super.onUnbind(intent)
    }

    override fun onDestroy() { cancelDrag(); removeDot(); removeFab(); instance = null; super.onDestroy() }

    fun screenSize(): Pair<Float, Float> {
        val m = resources.displayMetrics
        return Pair(m.widthPixels.toFloat(), m.heightPixels.toFloat())
    }

    // ------------------------------------------------------------------ pointer dot

    fun showDot(show: Boolean, big: Boolean = false) = main.post {
        if (!show) { removeDot(); return@post }
        if (dot != null && big == dotBig) return@post
        if (dot != null) removeDot()
        dotBig = big
        dotSize = if (big) 96 else 56
        try {
            val v = View(this)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.argb(190, 0, 200, 255))
            bg.setStroke(4, Color.WHITE)
            v.background = bg
            val p = WindowManager.LayoutParams(
                dotSize, dotSize,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.START
            wm?.addView(v, p)
            dot = v; dotParams = p
        } catch (e: Exception) { dot = null }
    }

    fun moveDot(x: Float, y: Float) = main.post {
        val v = dot ?: return@post
        val p = dotParams ?: return@post
        p.x = (x - dotSize / 2).toInt(); p.y = (y - dotSize / 2).toInt()
        try { wm?.updateViewLayout(v, p) } catch (_: Exception) { }
    }

    fun flashDot() = main.post {
        val v = dot ?: return@post
        v.animate().cancel()
        v.scaleX = 1.6f; v.scaleY = 1.6f
        v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
    }

    private fun removeDot() {
        val v = dot ?: return
        try { wm?.removeView(v) } catch (_: Exception) { }
        dot = null
    }

    // ------------------------------------------------------------------ touch injection

    private fun stroke(path: Path, start: Long, dur: Long, cont: Boolean = false) =
        GestureDescription.StrokeDescription(path, start, dur.coerceAtLeast(1), cont)

    private fun dispatch(g: GestureDescription, onDone: (() -> Unit)? = null): Boolean {
        return dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { onDone?.invoke() }
            override fun onCancelled(d: GestureDescription?) { onDone?.invoke() }
        }, null)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.Builder().addStroke(stroke(p, 0, 50)).build())
    }

    fun doubleTap(x: Float, y: Float): Boolean {
        val p1 = Path().apply { moveTo(x, y) }
        val p2 = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.Builder()
            .addStroke(stroke(p1, 0, 40)).addStroke(stroke(p2, 140, 40)).build())
    }

    fun longPress(x: Float, y: Float, ms: Long = 700): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.Builder().addStroke(stroke(p, 0, ms)).build())
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 280): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return dispatch(GestureDescription.Builder().addStroke(stroke(p, 0, ms)).build())
    }

    /** dir: "up" scrolls content up (finger moves up) etc. amount is a screen fraction. */
    fun scroll(dir: String, amount: Float): Boolean {
        val (w, h) = screenSize()
        val cx = w / 2; val cy = h / 2
        val dy = h * 0.3f * amount; val dx = w * 0.3f * amount
        return when (dir) {
            "up" -> swipe(cx, cy + dy, cx, cy - dy)
            "down" -> swipe(cx, cy - dy, cx, cy + dy)
            "left" -> swipe(cx + dx, cy, cx - dx, cy)
            "right" -> swipe(cx - dx, cy, cx + dx, cy)
            else -> false
        }
    }

    // ---- drag via continued strokes (API 26+; minSdk is 26)

    @Synchronized fun dragStart(x: Float, y: Float) {
        if (dragActive) cancelDrag()
        val p = Path().apply { moveTo(x, y) }
        val s = stroke(p, 0, 60, true)
        dragStroke = s; dragLastX = x; dragLastY = y
        dragTargetX = x; dragTargetY = y
        dragActive = true; dragBusy = true
        dispatch(GestureDescription.Builder().addStroke(s).build()) { onDragStep() }
    }

    @Synchronized fun dragMove(x: Float, y: Float) {
        if (!dragActive) return
        dragTargetX = x; dragTargetY = y
        if (!dragBusy) pumpDrag(false)
    }

    @Synchronized fun dragEnd(x: Float, y: Float) {
        if (!dragActive) return
        dragTargetX = x; dragTargetY = y
        if (dragBusy) { dragActive = false; pendingEnd = true } else pumpDrag(true)
    }

    private var pendingEnd = false

    @Synchronized private fun onDragStep() {
        dragBusy = false
        if (pendingEnd) { pendingEnd = false; dragActive = true; pumpDrag(true); return }
        if (dragActive && (dragTargetX != dragLastX || dragTargetY != dragLastY)) pumpDrag(false)
    }

    private fun pumpDrag(last: Boolean) {
        val prev = dragStroke ?: run { dragActive = false; return }
        val p = Path().apply { moveTo(dragLastX, dragLastY); lineTo(dragTargetX, dragTargetY) }
        val next = try { prev.continueStroke(p, 0, 50, !last) } catch (e: Exception) { null }
        if (next == null) { dragActive = false; dragStroke = null; return }
        dragLastX = dragTargetX; dragLastY = dragTargetY
        dragStroke = if (last) null else next
        if (last) dragActive = false
        dragBusy = true
        val ok = dispatch(GestureDescription.Builder().addStroke(next).build()) { onDragStep() }
        if (!ok) { dragBusy = false; if (last) dragActive = false }
    }

    /** Releases any held virtual touch immediately. Safe to call at any time. */
    @Synchronized fun cancelDrag() {
        if (dragStroke != null && dragActive) {
            try {
                val p = Path().apply { moveTo(dragLastX, dragLastY) }
                val end = dragStroke!!.continueStroke(p, 0, 1, false)
                dispatchGesture(GestureDescription.Builder().addStroke(end).build(), null, null)
            } catch (_: Exception) { }
        }
        dragStroke = null; dragActive = false; dragBusy = false; pendingEnd = false
    }

    // ------------------------------------------------------------------ high-level actions

    /** Returns null on success or a short human-readable reason on failure. */
    fun perform(action: String, x: Float, y: Float, cfg: Config, style: String = "short"): String? {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (action) {
            "NONE" -> null
            "TAP" -> if (tap(x, y)) { if (cfg.b("clickFeedback", true)) flashDot(); null } else "Tap was rejected by Android"
            "DOUBLE_TAP" -> if (doubleTap(x, y)) { if (cfg.b("clickFeedback", true)) flashDot(); null } else "Double tap rejected"
            "LONG_PRESS" -> if (longPress(x, y)) { if (cfg.b("clickFeedback", true)) flashDot(); null } else "Long press rejected"
            "DRAG" -> null // handled by dragStart/Move/End
            "SCROLL_UP" -> ok(scroll("up", cfg.f("scrollSpeed", 1f).coerceIn(0.3f, 2.5f)))
            "SCROLL_DOWN" -> ok(scroll("down", cfg.f("scrollSpeed", 1f).coerceIn(0.3f, 2.5f)))
            "SCROLL_LEFT" -> ok(scroll("left", cfg.f("scrollSpeed", 1f).coerceIn(0.3f, 2.5f)))
            "SCROLL_RIGHT" -> ok(scroll("right", cfg.f("scrollSpeed", 1f).coerceIn(0.3f, 2.5f)))
            "SWIPE_UP" -> { val (w, h) = screenSize(); ok(swipe(w / 2, h * 0.7f, w / 2, h * 0.3f)) }
            "SWIPE_DOWN" -> { val (w, h) = screenSize(); ok(swipe(w / 2, h * 0.3f, w / 2, h * 0.7f)) }
            "SWIPE_LEFT" -> { val (w, h) = screenSize(); ok(swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)) }
            "SWIPE_RIGHT" -> { val (w, h) = screenSize(); ok(swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)) }
            "BACK" -> ok(performGlobalAction(GLOBAL_ACTION_BACK))
            "HOME" -> ok(performGlobalAction(GLOBAL_ACTION_HOME))
            "RECENTS" -> ok(performGlobalAction(GLOBAL_ACTION_RECENTS))
            "NOTIFICATIONS" -> ok(performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS))
            "QUICK_SETTINGS" -> ok(performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS))
            "POWER_DIALOG" -> ok(performGlobalAction(GLOBAL_ACTION_POWER_DIALOG))
            "LOCK_SCREEN" ->
                if (Build.VERSION.SDK_INT >= 28) ok(performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN))
                else "Lock screen needs Android 9+"
            "SCREENSHOT" ->
                if (Build.VERSION.SDK_INT >= 28) ok(performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT))
                else "Screenshot needs Android 9+"
            "VOLUME_UP" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); null }
            "VOLUME_DOWN" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); null }
            "VOLUME_PANEL" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI); null }
            "MUTE_TOGGLE" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI); null }
            "PLAY_PAUSE" -> media(am, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            "NEXT_TRACK" -> media(am, KeyEvent.KEYCODE_MEDIA_NEXT)
            "PREV_TRACK" -> media(am, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "BRIGHTNESS_UP" -> brightness(+0.1f)
            "BRIGHTNESS_DOWN" -> brightness(-0.1f)
            "OPEN_SETTINGS" -> launch(Intent(Settings.ACTION_SETTINGS))
            "OPEN_DISPLAY_SETTINGS" -> launch(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            "OPEN_ACCESSIBILITY_SETTINGS" -> launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "LAUNCH_APP" -> {
                val pkg = cfg.s("appPackage", "")
                val i = if (pkg.isEmpty()) null else packageManager.getLaunchIntentForPackage(pkg)
                if (i == null) "No app selected for LAUNCH_APP (choose one in Settings)" else launch(i)
            }
            "FOCUS_AND_TAP_FIELD" -> focusField()
            else -> if (action.startsWith("SOCIAL_")) socialAction(action, cfg, style) else "Unknown action $action"
        }
    }

    /**
     * Social-feed helpers. Screen positions are fractions of the screen and are approximate: apps move their
     * buttons between versions, so comment/share positions are adjustable in Social mode settings.
     * "long" style = ordinary horizontal videos (YouTube, Facebook watch): next/previous become +/-10 s seeks
     * (double tap on the right/left edge of the video).
     */
    private fun socialAction(a: String, cfg: Config, style: String): String? {
        val (w, h) = screenSize()
        val long = style == "long"
        val vy = if (w > h) 0.5f else 0.25f   // where a horizontal video sits: centre when landscape, top when portrait
        return when (a) {
            "SOCIAL_NEXT" ->
                if (long) ok(doubleTap(w * 0.85f, h * vy)) else ok(swipe(w * 0.5f, h * 0.72f, w * 0.5f, h * 0.28f, 160))
            "SOCIAL_PREV" ->
                if (long) ok(doubleTap(w * 0.15f, h * vy)) else ok(swipe(w * 0.5f, h * 0.28f, w * 0.5f, h * 0.72f, 160))
            "SOCIAL_LIKE" ->
                if (long) "Like is only available in short-video style" else ok(doubleTap(w * 0.5f, h * 0.45f))
            "SOCIAL_PLAY_PAUSE" -> ok(tap(w * 0.5f, h * (if (long) vy else 0.40f)))
            "SOCIAL_COMMENTS" ->
                if (long) "Comments button position is only set for short-video style"
                else ok(tap(w * cfg.f("socialCommentX", 0.92f), h * cfg.f("socialCommentY", 0.60f)))
            "SOCIAL_SHARE" ->
                if (long) "Share button position is only set for short-video style"
                else ok(tap(w * cfg.f("socialShareX", 0.92f), h * cfg.f("socialShareY", 0.76f)))
            "SOCIAL_COMMENTS_SCROLL_DOWN" -> ok(swipe(w * 0.5f, h * 0.85f, w * 0.5f, h * 0.55f, 220))
            "SOCIAL_COMMENTS_SCROLL_UP" -> ok(swipe(w * 0.5f, h * 0.55f, w * 0.5f, h * 0.85f, 220))
            else -> "Unknown action $a"
        }
    }

    private fun ok(b: Boolean): String? = if (b) null else "Android refused this action in the current app"

    private fun media(am: AudioManager, code: Int): String? {
        return try {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            null
        } catch (e: Exception) { "Media key rejected" }
    }

    private fun launch(i: Intent): String? = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); null
    } catch (e: Exception) { "Could not open that screen" }

    /** Brightness needs WRITE_SETTINGS special access; we never grant it ourselves. */
    private fun brightness(delta: Float): String? {
        if (!Settings.System.canWrite(this)) return "Brightness needs 'Modify system settings' access (Setup → Optional)"
        return try {
            val cr = contentResolver
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (cur + delta * 255).toInt().coerceIn(5, 255))
            null
        } catch (e: Exception) { "Brightness change failed" }
    }

    /**
     * Deliberately NOT implemented via screen inspection: that would require the
     * canRetrieveWindowContent capability, which lets an accessibility service read what is on screen.
     * Air Control keeps that capability off. Point at the field and pinch-tap instead.
     */
    private fun focusField(): String? =
        "Not supported: needs screen-content access, which Air Control keeps off. Point at the field and pinch to tap."
}
