package __PKG__

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground service (type camera) that runs CameraX + MediaPipe Hand Landmarker fully on device.
 * Frames are analysed in memory and discarded; nothing is saved or sent anywhere.
 * Start it only from the visible app (Android 14+ forbids starting camera services from background).
 */
class TrackingService : LifecycleService() {

    companion object {
        const val ACTION_START = "air.START"
        const val ACTION_STOP = "air.STOP"
        const val ACTION_PAUSE = "air.PAUSE"
        const val ACTION_RESUME = "air.RESUME"
        const val ACTION_CONFIG = "air.CONFIG"
        private const val CH = "air_tracking"
        private const val NID = 41
        @Volatile var instance: TrackingService? = null
        const val MODEL = "hand_landmarker.task"
    }

    private lateinit var cfg: Config
    private var engine: GestureEngine? = null
    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private lateinit var exec: ExecutorService
    private var lastFrameMs = 0L
    private var fpsCount = 0
    private var fpsWindow = 0L
    private var lastStatus = 0L
    private var lastHandTs = 0L
    private var lastMpTs = 0L
    @Volatile private var lastPose = "NONE"
    @Volatile private var lastRatio = 0f
    @Volatile private var stopping = false

    private val out = object : GestureEngine.Output {
        override fun pointer(x: Float, y: Float) { AirAccessibilityService.instance?.moveDot(x, y) }

        override fun action(action: String, gesture: String, x: Float, y: Float) {
            Bridge.lastAction = "$gesture → $action"
            if (Bridge.dryRun) { Bridge.emitStatus(); return }
            val svc = AirAccessibilityService.instance
            if (svc == null) { fail("Accessibility access is off; actions cannot run"); return }
            val err = svc.perform(action, x, y, cfg)
            if (err != null) Bridge.lastAction = "$gesture → $action failed: $err"
            Bridge.emitStatus()
        }

        override fun dragStart(x: Float, y: Float) {
            if (!Bridge.dryRun) AirAccessibilityService.instance?.dragStart(x, y)
            Bridge.lastAction = "drag started"
        }
        override fun dragMove(x: Float, y: Float) {
            if (!Bridge.dryRun) AirAccessibilityService.instance?.dragMove(x, y)
        }
        override fun dragEnd(x: Float, y: Float) {
            if (!Bridge.dryRun) AirAccessibilityService.instance?.dragEnd(x, y)
            Bridge.lastAction = "drag released"
        }

        override fun pauseChanged(paused: Boolean) {
            Bridge.paused = paused
            AirAccessibilityService.instance?.cancelDrag()
            updateNotification()
            Bridge.emitStatus()
        }

        override fun info(pose: String, pinchRatio: Float) { lastPose = pose; lastRatio = pinchRatio }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        exec = Executors.newSingleThreadExecutor()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> { stopTracking("Stopped by you"); return START_NOT_STICKY }
            ACTION_PAUSE -> { engine?.setPaused(true); return START_NOT_STICKY }
            ACTION_RESUME -> { engine?.setPaused(false); return START_NOT_STICKY }
            ACTION_CONFIG -> { reloadConfig(); return START_NOT_STICKY }
            else -> startTracking()
        }
        // Not sticky: Android must never restart the camera on its own.
        return START_NOT_STICKY
    }

    private fun startTracking() {
        if (Bridge.running) return
        stopping = false
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            fail("Camera permission is not granted"); stopSelf(); return
        }
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
            } else startForeground(NID, n)
        } catch (e: Exception) {
            fail("Android blocked the camera service: ${e.javaClass.simpleName}. Open Air Control and press Start again.")
            stopSelf(); return
        }
        cfg = Config.load(this)
        val (w, h) = AirAccessibilityService.instance?.screenSize()
            ?: Pair(resources.displayMetrics.widthPixels.toFloat(), resources.displayMetrics.heightPixels.toFloat())
        engine = GestureEngine(cfg, out).also { it.setScreen(w, h) }
        AirAccessibilityService.instance?.showDot(cfg.b("showPointer", true))

        try {
            landmarker = buildLandmarker()
        } catch (e: Exception) {
            fail("Hand model failed to load: ${e.javaClass.simpleName}")
            stopTracking(Bridge.reason); return
        }
        bindCamera()
        Bridge.running = true; Bridge.paused = false; Bridge.reason = ""
        Bridge.emitStatus()
    }

    private fun buildLandmarker(): HandLandmarker {
        val base = BaseOptions.builder().setModelAssetPath(MODEL).build()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(cfg.f("minDetection", 0.5f))
            .setMinHandPresenceConfidence(cfg.f("minPresence", 0.5f))
            .setMinTrackingConfidence(cfg.f("minTracking", 0.5f))
            .setResultListener { r, _ -> onResult(r) }
            .setErrorListener { e -> fail("Tracker error: ${e.javaClass.simpleName}") }
            .build()
        return HandLandmarker.createFromOptions(this, opts)
    }

    private fun bindCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                val p = f.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setTargetResolution(android.util.Size(480, 360))
                    .build()
                analysis.setAnalyzer(exec) { img -> analyze(img) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                fail("Camera could not start: ${e.javaClass.simpleName}")
                stopTracking(Bridge.reason)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(img: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            val minGap = 1000L / cfg.i("maxFps", 20).coerceIn(5, 30)
            if (now - lastFrameMs < minGap || stopping) return
            lastFrameMs = now
            val raw = img.toBitmap()
            val m = Matrix()
            m.postRotate(img.imageInfo.rotationDegrees.toFloat())
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, false)
            var ts = now
            if (ts <= lastMpTs) ts = lastMpTs + 1
            lastMpTs = ts
            landmarker?.detectAsync(BitmapImageBuilder(bmp).build(), ts)
            fpsCount++
            if (now - fpsWindow >= 1000) {
                Bridge.fps = fpsCount; fpsCount = 0; fpsWindow = now
            }
        } catch (e: Exception) {
            // drop the frame; repeated failures surface through the tracker error listener
        } finally {
            img.close()
        }
    }

    private fun onResult(r: HandLandmarkerResult) {
        val t = SystemClock.uptimeMillis()
        val eng = engine ?: return
        val hands = r.landmarks()
        val pref = cfg.s("dominantHand", "any")
        var idx = if (hands.isEmpty()) -1 else 0
        if (hands.size > 1 && pref != "any") {
            // image is not mirrored by MediaPipe handedness for a front camera selfie view; prefer match if present
            val hd = r.handedness()
            for (i in hands.indices) {
                val label = hd.getOrNull(i)?.firstOrNull()?.categoryName() ?: continue
                if ((pref == "right" && label == "Left") || (pref == "left" && label == "Right")) { idx = i; break }
            }
        }
        if (idx < 0) {
            Bridge.handPresent = false
            eng.onNoHand(t)
            Bridge.emitFrame(null, "NONE", 0f)
        } else {
            val l = hands[idx]
            val a = FloatArray(42)
            for (i in 0 until 21) { a[2 * i] = 1f - l[i].x(); a[2 * i + 1] = l[i].y() } // mirror to selfie view
            Bridge.handPresent = true
            lastHandTs = t
            eng.onHand(a, t)
            Bridge.emitFrame(a, lastPose, lastRatio)
        }
        if (t - lastStatus > 700) { lastStatus = t; Bridge.emitStatus() }
        // tracking-lost stall guard: AirAccessibilityService revoked mid-run
        if (cfg.b("showPointer", true) && AirAccessibilityService.instance == null && Bridge.running) {
            Bridge.reason = "Accessibility access is off; actions are not being sent"
        }
    }

    private fun reloadConfig() {
        if (!Bridge.running) return
        cfg = Config.load(this)
        engine?.setConfig(cfg)
        AirAccessibilityService.instance?.showDot(cfg.b("showPointer", true))
    }

    fun stopTracking(why: String) {
        stopping = true
        if (why.isNotEmpty()) Bridge.reason = why
        try { engine?.releaseAll() } catch (_: Exception) { }
        AirAccessibilityService.instance?.cancelDrag()
        AirAccessibilityService.instance?.showDot(false)
        try { provider?.unbindAll() } catch (_: Exception) { }
        try { landmarker?.close() } catch (_: Exception) { }
        landmarker = null; engine = null
        Bridge.running = false; Bridge.paused = false; Bridge.handPresent = false; Bridge.fps = 0
        Bridge.emitStatus()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    private fun fail(msg: String) {
        Bridge.reason = msg
        Bridge.emitStatus()
    }

    override fun onTaskRemoved(rootIntent: Intent?) { super.onTaskRemoved(rootIntent) /* keep running by design */ }

    override fun onDestroy() {
        if (Bridge.running) {
            try { engine?.releaseAll() } catch (_: Exception) { }
            AirAccessibilityService.instance?.cancelDrag()
            AirAccessibilityService.instance?.showDot(false)
            try { provider?.unbindAll() } catch (_: Exception) { }
            try { landmarker?.close() } catch (_: Exception) { }
            Bridge.running = false; Bridge.handPresent = false
            if (Bridge.reason.isEmpty()) Bridge.reason = "Android stopped the tracking service (battery or memory limits). Open Air Control and press Start."
            Bridge.emitStatus()
        }
        exec.shutdown()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(CH, "Hand tracking", NotificationManager.IMPORTANCE_LOW)
            c.description = "Shown while the camera is tracking your hand"
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun pi(action: String, code: Int): PendingIntent {
        val i = Intent(this, TrackingService::class.java).setAction(action)
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE)
        val paused = Bridge.paused
        val b = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Air Control: camera is ON")
            .setContentText(if (paused) "Paused: no actions are sent" else "Tracking your hand")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .addAction(0, if (paused) "Resume" else "Pause", pi(if (paused) ACTION_RESUME else ACTION_PAUSE, 1))
            .addAction(0, "Stop", pi(ACTION_STOP, 2))
        return b.build()
    }

    private fun updateNotification() {
        try { getSystemService(NotificationManager::class.java).notify(NID, buildNotification()) } catch (_: Exception) { }
    }
}
