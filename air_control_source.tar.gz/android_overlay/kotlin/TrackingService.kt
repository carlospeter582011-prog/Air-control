package __PKG__

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground service (type camera) that runs CameraX + MediaPipe Hand Landmarker fully on device.
 * Frames are analysed in memory and discarded; nothing is saved or sent anywhere.
 * Start it only from the visible app (Android 14+ forbids starting camera services from background).
 *
 * It runs until you press Stop. There is no pause feature and nothing pauses it when your hand is not seen.
 * The only suspension is optional per-app mode: with "selected apps" it either stops sending gestures or turns the
 * camera off while another app is in front, and resumes by itself when a chosen app is opened.
 */
class TrackingService : LifecycleService() {

    companion object {
        const val ACTION_START = "air.START"
        const val ACTION_STOP = "air.STOP"
        const val ACTION_CONFIG = "air.CONFIG"
        private const val CH = "air_tracking"
        private const val NID = 41
        @Volatile var instance: TrackingService? = null
        const val MODEL = "hand_landmarker.task"
    }

    private lateinit var cfg: Config
    private var engine: GestureEngine? = null
    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private lateinit var exec: ExecutorService
    private val main = Handler(Looper.getMainLooper())
    private var lastFrameMs = 0L
    private var fpsCount = 0
    private var fpsWindow = 0L
    private var lastStatus = 0L
    private var lastMpTs = 0L
    @Volatile private var lastPose = "NONE"
    @Volatile private var lastRatio = 0f
    @Volatile private var stopping = false
    @Volatile private var wantCamera = false
    private var binding = false
    private var socialForced: Boolean? = null     // set by the TOGGLE_SOCIAL_MODE gesture action
    private var styleOverride: String? = null     // set by the TOGGLE_VIDEO_STYLE gesture action

    private fun videoStyle(): String = styleOverride ?: cfg.s("videoStyle", "short")

    private val out = object : GestureEngine.Output {
        override fun pointer(x: Float, y: Float) { AirAccessibilityService.instance?.moveDot(x, y) }

        override fun action(action: String, gesture: String, x: Float, y: Float) {
            Bridge.lastAction = "$gesture → $action"
            if (action == "TOGGLE_SOCIAL_MODE") {
                socialForced = !Bridge.social
                main.post { evaluate() }
                return
            }
            if (action == "TOGGLE_VIDEO_STYLE") {
                styleOverride = if (videoStyle() == "short") "long" else "short"
                main.post { evaluate() }
                return
            }
            if (Bridge.dryRun) { Bridge.emitStatus(); return }
            val svc = AirAccessibilityService.instance
            if (svc == null) { fail("Accessibility access is off; actions cannot run"); return }
            val err = svc.perform(action, x, y, cfg, videoStyle())
            if (err != null) Bridge.lastAction = "$gesture → $action failed: $err"
            Bridge.emitStatus()
        }

        override fun dragStart(x: Float, y: Float) {
            if (!Bridge.dryRun) AirAccessibilityService.instance?.dragStart(x, y)
            Bridge.lastAction = "drag started"
        }
        override fun dragMove(x: Float, y: Float) {
            if (!Bridge.dryRun) AirAccessibilityService.instance?.dragMove(x, y)
        }
        override fun dragEnd(x: Float, y: Float) {
            if (!Bridge.dryRun) AirAccessibilityService.instance?.dragEnd(x, y)
            Bridge.lastAction = "drag released"
        }

        override fun pauseChanged(paused: Boolean) {
            // only used by the per-app gate
            AirAccessibilityService.instance?.cancelDrag()
        }

        override fun info(pose: String, pinchRatio: Float) { lastPose = pose; lastRatio = pinchRatio }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        exec = Executors.newSingleThreadExecutor()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> { stopTracking("Stopped by you"); return START_NOT_STICKY }
            ACTION_CONFIG -> { reloadConfig(); return START_NOT_STICKY }
            else -> startTracking()
        }
        // Not sticky: Android must never restart the camera on its own.
        return START_NOT_STICKY
    }

    private fun startTracking() {
        if (Bridge.running) return
        stopping = false
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            fail("Camera permission is not granted"); stopSelf(); return
        }
        cfg = Config.load(this)
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
            } else startForeground(NID, n)
        } catch (e: Exception) {
            fail("Android blocked the camera service: ${e.javaClass.simpleName}. Open Air Control and press Start again.")
            stopSelf()
            return
        }
        val (w, h) = AirAccessibilityService.instance?.screenSize()
            ?: Pair(resources.displayMetrics.widthPixels.toFloat(), resources.displayMetrics.heightPixels.toFloat())
        engine = GestureEngine(cfg, out).also { it.setScreen(w, h) }
        socialForced = null; styleOverride = null

        try {
            landmarker = buildLandmarker()
        } catch (e: Exception) {
            fail("Hand model failed to load: ${e.javaClass.simpleName}")
            stopTracking(Bridge.reason); return
        }
        Bridge.running = true; Bridge.paused = false; Bridge.reason = ""
        evaluate()
    }

    // ------------------------------------------------------------------ per-app gate + social mode

    private fun appAllowed(pkg: String): Boolean {
        if (Bridge.frameStream) return true          // live test / calibration screen is always allowed
        if (cfg.s("appMode", "all") != "selected") return true
        return pkg in cfg.list("apps")
    }

    private fun socialActive(pkg: String): Boolean {
        socialForced?.let { return it }
        return when (cfg.s("socialMode", "off")) {
            "on" -> true
            "auto" -> pkg in cfg.list("socialApps")
            else -> false
        }
    }

    /** Called by the accessibility service (main thread) when another app comes to the front. */
    fun onForegroundApp(pkg: String) {
        main.post { if (Bridge.running) evaluate() }
    }

    /** Re-applies the per-app gate, camera state, social mode and pointer size. Main thread. */
    private fun evaluate() {
        val eng = engine ?: return
        val pkg = AirAccessibilityService.currentPkg
        val allowed = appAllowed(pkg)
        val camOff = cfg.s("outsideBehavior", "gestures_off") == "camera_off"
        Bridge.gated = !allowed
        eng.setPaused(!allowed)
        setCamera(allowed || !camOff)

        val soc = socialActive(pkg)
        eng.setSocial(soc)
        Bridge.social = soc
        Bridge.videoStyle = videoStyle()
        AirAccessibilityService.instance?.showDot(cfg.b("showPointer", true) && allowed, soc)

        if (!allowed && AirAccessibilityService.instance == null) {
            Bridge.reason = "Per-app mode needs accessibility access to see which app is open"
        } else if (Bridge.reason.startsWith("Per-app mode needs")) {
            Bridge.reason = ""
        }
        updateNotification()
        Bridge.emitStatus()
    }

    // ------------------------------------------------------------------ camera

    private fun buildLandmarker(): HandLandmarker {
        val base = BaseOptions.builder().setModelAssetPath(MODEL).build()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(cfg.f("minDetection", 0.5f))
            .setMinHandPresenceConfidence(cfg.f("minPresence", 0.5f))
            .setMinTrackingConfidence(cfg.f("minTracking", 0.5f))
            .setResultListener { r, _ -> onResult(r) }
            .setErrorListener { e -> fail("Tracker error: ${e.javaClass.simpleName}") }
            .build()
        return HandLandmarker.createFromOptions(this, opts)
    }

    private fun setCamera(on: Boolean) {
        wantCamera = on
        if (on && !Bridge.cameraOn && !binding) bindCamera()
        else if (!on && (Bridge.cameraOn || binding)) unbindCamera()
    }

    private fun bindCamera() {
        binding = true
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            binding = false
            if (!wantCamera || stopping) return@addListener
            try {
                val p = f.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setTargetResolution(android.util.Size(480, 360))
                    .build()
                analysis.setAnalyzer(exec) { img -> analyze(img) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
                Bridge.cameraOn = true
                Bridge.emitStatus()
            } catch (e: Exception) {
                fail("Camera could not start: ${e.javaClass.simpleName}. If Air Control is in the background, open it and press Start again.")
                Bridge.cameraOn = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun unbindCamera() {
        try { provider?.unbindAll() } catch (_: Exception) { }
        Bridge.cameraOn = false
        Bridge.handPresent = false
        Bridge.fps = 0
        engine?.releaseAll()
    }

    private fun analyze(img: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            val minGap = 1000L / cfg.i("maxFps", 20).coerceIn(5, 30)
            if (now - lastFrameMs < minGap || stopping || !wantCamera) return
            lastFrameMs = now
            val raw = img.toBitmap()
            val m = Matrix()
            m.postRotate(img.imageInfo.rotationDegrees.toFloat())
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, false)
            var ts = now
            if (ts <= lastMpTs) ts = lastMpTs + 1
            lastMpTs = ts
            landmarker?.detectAsync(BitmapImageBuilder(bmp).build(), ts)
            fpsCount++
            if (now - fpsWindow >= 1000) {
                Bridge.fps = fpsCount; fpsCount = 0; fpsWindow = now
            }
        } catch (e: Exception) {
            // drop the frame; repeated failures surface through the tracker error listener
        } finally {
            img.close()
        }
    }

    private fun onResult(r: HandLandmarkerResult) {
        val t = SystemClock.uptimeMillis()
        val eng = engine ?: return
        val hands = r.landmarks()
        val pref = cfg.s("dominantHand", "any")
        var idx = if (hands.isEmpty()) -1 else 0
        if (hands.size > 1 && pref != "any") {
            val hd = r.handedness()
            for (i in hands.indices) {
                val label = hd.getOrNull(i)?.firstOrNull()?.categoryName() ?: continue
                if ((pref == "right" && label == "Left") || (pref == "left" && label == "Right")) { idx = i; break }
            }
        }
        if (idx < 0) {
            Bridge.handPresent = false
            eng.onNoHand(t)
            Bridge.emitFrame(null, "NONE", 0f)
        } else {
            val l = hands[idx]
            val a = FloatArray(42)
            for (i in 0 until 21) { a[2 * i] = 1f - l[i].x(); a[2 * i + 1] = l[i].y() } // mirror to selfie view
            Bridge.handPresent = true
            eng.onHand(a, t)
            Bridge.emitFrame(a, lastPose, lastRatio)
        }
        if (t - lastStatus > 700) { lastStatus = t; Bridge.emitStatus() }
        if (AirAccessibilityService.instance == null && Bridge.running && Bridge.reason.isEmpty()) {
            Bridge.reason = "Accessibility access is off; actions are not being sent"
        }
    }

    private fun reloadConfig() {
        if (!Bridge.running) return
        cfg = Config.load(this)
        engine?.setConfig(cfg)
        main.post { evaluate() }
    }

    fun stopTracking(why: String) {
        stopping = true
        wantCamera = false
        if (why.isNotEmpty()) Bridge.reason = why
        try { engine?.releaseAll() } catch (_: Exception) { }
        AirAccessibilityService.instance?.cancelDrag()
        AirAccessibilityService.instance?.showDot(false)
        try { provider?.unbindAll() } catch (_: Exception) { }
        try { landmarker?.close() } catch (_: Exception) { }
        landmarker = null; engine = null
        Bridge.running = false; Bridge.paused = false; Bridge.handPresent = false; Bridge.fps = 0
        Bridge.gated = false; Bridge.cameraOn = false; Bridge.social = false
        Bridge.emitStatus()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    private fun fail(msg: String) {
        Bridge.reason = msg
        Bridge.emitStatus()
    }

    override fun onDestroy() {
        if (Bridge.running) {
            wantCamera = false
            try { engine?.releaseAll() } catch (_: Exception) { }
            AirAccessibilityService.instance?.cancelDrag()
            AirAccessibilityService.instance?.showDot(false)
            try { provider?.unbindAll() } catch (_: Exception) { }
            try { landmarker?.close() } catch (_: Exception) { }
            Bridge.running = false; Bridge.handPresent = false; Bridge.cameraOn = false; Bridge.gated = false
            if (Bridge.reason.isEmpty()) Bridge.reason = "Android stopped the tracking service (battery or memory limits). Open Air Control and press Start."
            Bridge.emitStatus()
        }
        exec.shutdown()
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(CH, "Hand tracking", NotificationManager.IMPORTANCE_LOW)
            c.description = "Shown while Air Control is running"
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun pi(action: String, code: Int): PendingIntent {
        val i = Intent(this, TrackingService::class.java).setAction(action)
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE)
        val text = when {
            Bridge.gated && !Bridge.cameraOn -> "Camera off until you open a chosen app"
            Bridge.gated -> "Camera on, gestures off until you open a chosen app"
            Bridge.social -> "Social mode: camera is ON"
            else -> "Camera is ON and tracking your hand"
        }
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_air)
            .setContentTitle("Air Control is running")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .addAction(0, "Stop", pi(ACTION_STOP, 2))
            .build()
    }

    private fun updateNotification() {
        try { getSystemService(NotificationManager::class.java).notify(NID, buildNotification()) } catch (_: Exception) { }
    }
}
