package __PKG__

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Pure-Kotlin gesture logic (no Android dependencies, so it is JVM-unit-testable).
 *
 * Input: 21 hand landmarks as x,y pairs (normalized 0..1, upright, mirrored like a selfie view)
 * plus a millisecond timestamp. Output: pointer position, discrete actions and drag events via [Output].
 *
 * Behaviour rules:
 *  - one-shot gestures fire once per entry into a pose; holding never repeats them
 *  - EXCEPT actions in [REPEATING] (volume, brightness, scrolling): while the gesture is held they repeat every
 *    repeatMs, and stop the moment the pose changes or the hand is lost
 *  - there is NO pause gesture and NO pausing when the hand is lost; the only suspension is the app gate
 *    (setPaused is used by the service when a non-selected app is in front)
 *  - a held drag is released when the hand is gone longer than lostTimeoutMs (so a touch is never stuck)
 */
class GestureEngine(initial: Config, private val out: Output) {

    interface Output {
        fun pointer(x: Float, y: Float)
        fun action(action: String, gesture: String, x: Float, y: Float)
        fun dragStart(x: Float, y: Float)
        fun dragMove(x: Float, y: Float)
        fun dragEnd(x: Float, y: Float)
        fun pauseChanged(paused: Boolean)
        fun info(pose: String, pinchRatio: Float)
    }

    enum class Pose { NONE, POINT, PINCH, PEACE, THREE, ROCK, CALL, PINKY, OPEN, FIST, THUMB_UP, THUMB_DOWN, OTHER }

    companion object {
        val REPEATING = setOf(
            "VOLUME_UP", "VOLUME_DOWN", "BRIGHTNESS_UP", "BRIGHTNESS_DOWN",
            "SCROLL_UP", "SCROLL_DOWN", "SOCIAL_COMMENTS_SCROLL_UP", "SOCIAL_COMMENTS_SCROLL_DOWN"
        )
        private val FINGER_PINCH = arrayOf("", "pinch_middle", "pinch_ring", "pinch_pinky")
        private val TIPS = intArrayOf(8, 12, 16, 20)
    }

    private class Sample(val t: Long, val x: Float, val y: Float)

    /** True only while the app gate suspends gestures. Not user-controllable. */
    @Volatile
    var paused = false
        private set

    private var cfg = initial
    private var social = false
    private var screenW = 1080f
    private var screenH = 2400f

    // smoothing
    private var haveSm = false
    private var smTipX = 0f
    private var smTipY = 0f
    private var smMcpX = 0f
    private var smMcpY = 0f

    // pointer
    private var ptrX = 540f
    private var ptrY = 1200f
    private var relPrevX = Float.NaN
    private var relPrevY = Float.NaN
    private val hist = ArrayDeque<Sample>()

    // index pinch
    private var pinching = false
    private var pinchStartT = 0L
    private var startX = 0f
    private var startY = 0f
    private var startMapX = 0f
    private var startMapY = 0f
    private var dragging = false
    private var longFired = false
    private var pendingTapT = -1L
    private var pendX = 0f
    private var pendY = 0f

    // other-finger pinch (1 = middle, 2 = ring, 3 = pinky), -1 = none
    private var fingerPinch = -1

    // pose
    private var candidate = Pose.NONE
    private var candidateCount = 0
    private var stablePose = Pose.NONE
    private var poseSince = 0L
    private var holdFired = false
    private var repeatKey: String? = null
    private var lastRepeat = 0L

    // palm motion
    private val palmHist = ArrayDeque<Sample>()
    private var lastDiscrete = -100000L
    private var lastSeen = 0L

    @Synchronized fun setConfig(c: Config) { cfg = c }

    @Synchronized fun setScreen(w: Float, h: Float) { if (w > 0 && h > 0) { screenW = w; screenH = h } }

    @Synchronized fun setSocial(s: Boolean) { social = s }

    @Synchronized fun setPaused(p: Boolean) {
        if (p == paused) return
        paused = p
        releaseAllLocked()
        out.pauseChanged(p)
    }

    @Synchronized fun releaseAll() = releaseAllLocked()

    /** Called for every result without a usable hand. */
    @Synchronized fun onNoHand(t: Long) {
        tickLocked(t)
        if (lastSeen != 0L && t - lastSeen > cfg.i("lostTimeoutMs", 500)) {
            releaseAllLocked()
            out.info("NONE", 0f)
        }
    }

    @Synchronized fun onHand(lm: FloatArray, t: Long) {
        lastSeen = t
        val palm = max(d(lm, 0, 9), 0.001f)
        val ratios = FloatArray(4) { d(lm, 4, TIPS[it]) / palm }
        val ratio = ratios[0]
        val ext = booleanArrayOf(ex(lm, 8, 6), ex(lm, 12, 10), ex(lm, 16, 14), ex(lm, 20, 18))
        val thumbOut = d(lm, 4, 17) > d(lm, 3, 17) * 1.1f && d(lm, 4, 5) > 0.5f * palm

        smooth(lm)

        // ---- pinches (never while the app gate has gestures suspended)
        val on = 0.2f + 0.3f * pinchSens()
        val off = on * 1.4f
        if (!paused) {
            if (pinching) {
                if (ratio > off) endPinch(t)
            } else if (fingerPinch >= 0) {
                if (ratios[fingerPinch] > off) fingerPinch = -1
            } else {
                val others = min(ratios[1], min(ratios[2], ratios[3]))
                // index pinch: the index finger must be reasonably open (not curled onto the palm)
                val indexOpen = d(lm, 5, 8) > 0.45f * palm
                if (indexOpen && ratio < on && ratio <= others) {
                    startPinch(t)
                } else {
                    // pinch with middle / ring / pinky: that finger must be the closest to the thumb and the
                    // other three fingers must all be extended (an "OK sign" style pinch). This keeps a fist,
                    // the rock sign (thumb resting on curled fingers) and similar poses from triggering it.
                    var best = -1
                    var bestR = on
                    for (f in 1..3) {
                        if (ratios[f] < bestR && ratios[f] < ratio) { best = f; bestR = ratios[f] }
                    }
                    if (best > 0) {
                        var extCount = 0
                        for (f in 0..3) if (f != best && ext[f]) extCount++
                        if (extCount == 3) {
                            fingerPinch = best
                            fireWithCooldown(FINGER_PINCH[best], ptrX, ptrY, t)
                        }
                    }
                }
            }
        } else if (pinching) {
            endPinch(t)
        }

        // ---- pose
        val raw = when {
            pinching -> Pose.PINCH
            fingerPinch >= 0 -> Pose.OTHER
            !ext[0] && !ext[1] && !ext[2] && !ext[3] -> {
                if (thumbOut) {
                    val tipY = lm[9]
                    val top = min(lm[1], lm[11])
                    val bottom = max(lm[1], lm[11])
                    when {
                        tipY < top - 0.3f * palm -> Pose.THUMB_UP
                        tipY > bottom + 0.3f * palm -> Pose.THUMB_DOWN
                        else -> Pose.OTHER
                    }
                } else Pose.FIST
            }
            ext[0] && !ext[1] && !ext[2] && !ext[3] -> Pose.POINT
            ext[0] && ext[1] && !ext[2] && !ext[3] -> Pose.PEACE
            ext[0] && ext[1] && ext[2] && !ext[3] -> Pose.THREE
            ext[0] && ext[1] && ext[2] && ext[3] -> Pose.OPEN
            ext[0] && !ext[1] && !ext[2] && ext[3] -> Pose.ROCK
            !ext[0] && !ext[1] && !ext[2] && ext[3] -> if (thumbOut) Pose.CALL else Pose.PINKY
            else -> Pose.OTHER
        }
        if (raw == candidate) candidateCount++ else { candidate = raw; candidateCount = 1 }
        if (candidateCount >= 3 && candidate != stablePose) {
            stablePose = candidate
            poseSince = t
            holdFired = false
            repeatKey = null        // repeating stops the moment the pose changes
        }

        // ---- pointer
        val pointerActive = !paused && (pinching || raw == Pose.POINT || stablePose == Pose.POINT)
        if (pointerActive) updatePointer(t) else { relPrevX = Float.NaN; relPrevY = Float.NaN }

        // ---- pinch behaviour (drag / long press)
        if (pinching && !paused) {
            val moved = hypot(ptrX - startX, ptrY - startY)
            if (!dragging && !longFired && moved > 0.04f * screenW && cfg.mapping("pinch_drag", social) == "DRAG") {
                dragging = true
                out.dragStart(startX, startY)
            }
            if (dragging) out.dragMove(ptrX, ptrY)
            else if (!longFired && moved <= 0.04f * screenW &&
                t - pinchStartT >= cfg.i("longPressMs", 600)) {
                longFired = true
                fire("pinch_hold", startX, startY)
            }
        }

        // ---- palm motion: swipes + hold-restart
        if (stablePose == Pose.OPEN && !paused) handleSwipe(lm, t) else palmHist.clear()
        if (stablePose == Pose.OPEN || stablePose == Pose.PEACE) restartHoldIfMoving(lm, t)

        // ---- hold gestures (one-shot) and repeating actions (volume etc.)
        if (!paused) handleHold(t)

        tickLocked(t)
        out.info(raw.name, ratio)
    }

    // ------------------------------------------------------------------ internals

    private fun pinchSens(): Float {
        val s = cfg.f("pinchSensitivity", 0.5f)
        return if (social) min(1f, s + 0.2f) else s
    }

    private fun holdMs(): Int {
        val h = cfg.i("holdMs", 800)
        return if (social) min(h, 550) else h
    }

    private fun cooldownMs(): Int {
        val c = cfg.i("cooldownMs", 900)
        return if (social) min(c, 600) else c
    }

    private fun holdKey(p: Pose): String? = when (p) {
        Pose.OPEN -> "open_palm_hold"
        Pose.FIST -> "fist_hold"
        Pose.PEACE -> "peace_hold"
        Pose.THREE -> "three_hold"
        Pose.ROCK -> "rock_hold"
        Pose.CALL -> "call_hold"
        Pose.PINKY -> "pinky_hold"
        Pose.THUMB_UP -> "thumbs_up_hold"
        Pose.THUMB_DOWN -> "thumbs_down_hold"
        else -> null
    }

    private fun handleHold(t: Long) {
        val key = holdKey(stablePose) ?: return
        val action = cfg.mapping(key, social)
        if (action == "NONE") return
        if (!holdFired) {
            if (t - poseSince < holdMs()) return
            holdFired = true
            if (action in REPEATING) {
                repeatKey = key
                lastRepeat = t
                fire(key, ptrX, ptrY)            // first step is immediate; no global cooldown
            } else {
                fireWithCooldown(key, ptrX, ptrY, t)
            }
        } else if (repeatKey == key && t - lastRepeat >= cfg.i("repeatMs", 250).coerceAtLeast(80)) {
            lastRepeat = t
            fire(key, ptrX, ptrY)
        }
    }

    private fun d(lm: FloatArray, a: Int, b: Int) =
        hypot(lm[2 * a] - lm[2 * b], lm[2 * a + 1] - lm[2 * b + 1])

    /** Finger is extended when its tip is farther from the wrist than its PIP joint. */
    private fun ex(lm: FloatArray, tip: Int, pip: Int) = d(lm, 0, tip) > d(lm, 0, pip) * 1.05f

    private fun smooth(lm: FloatArray) {
        val alpha = 1f - cfg.f("smoothing", 0.5f).coerceIn(0f, 1f) * 0.92f
        val tx = lm[16]; val ty = lm[17]; val mx = lm[10]; val my = lm[11]
        if (!haveSm) {
            smTipX = tx; smTipY = ty; smMcpX = mx; smMcpY = my; haveSm = true
            return
        }
        // tiny dead zone suppresses sensor jitter when the hand is still
        if (hypot(tx - smTipX, ty - smTipY) > 0.0015f) {
            smTipX += alpha * (tx - smTipX); smTipY += alpha * (ty - smTipY)
        }
        if (hypot(mx - smMcpX, my - smMcpY) > 0.0015f) {
            smMcpX += alpha * (mx - smMcpX); smMcpY += alpha * (my - smMcpY)
        }
    }

    private fun speed() = cfg.f("pointerSpeed", 1f) * (if (social) 0.85f else 1f)

    private fun mapX(nx: Float): Float {
        val lo = cfg.f("calXMin", 0.2f); val hi = max(cfg.f("calXMax", 0.8f), lo + 0.05f)
        val u = ((nx - lo) / (hi - lo)).coerceIn(0f, 1f)
        return (0.5f + (u - 0.5f) * speed()).coerceIn(0f, 1f) * screenW
    }

    private fun mapY(ny: Float): Float {
        val lo = cfg.f("calYMin", 0.2f); val hi = max(cfg.f("calYMax", 0.7f), lo + 0.05f)
        val v = ((ny - lo) / (hi - lo)).coerceIn(0f, 1f)
        return (0.5f + (v - 0.5f) * speed()).coerceIn(0f, 1f) * screenH
    }

    private fun updatePointer(t: Long) {
        val srcX = if (pinching) smMcpX else smTipX
        val srcY = if (pinching) smMcpY else smTipY
        if (cfg.s("pointerMode", "absolute") == "absolute") {
            if (pinching) {
                ptrX = (startX + (mapX(srcX) - startMapX)).coerceIn(0f, screenW)
                ptrY = (startY + (mapY(srcY) - startMapY)).coerceIn(0f, screenH)
            } else {
                ptrX = mapX(srcX); ptrY = mapY(srcY)
            }
        } else {
            if (!relPrevX.isNaN()) {
                val dx = srcX - relPrevX; val dy = srcY - relPrevY
                val mag = hypot(dx, dy)
                val gain = speed() * (1f + cfg.f("pointerAccel", 0.3f) * min(mag * 25f, 3f))
                val spanX = max(cfg.f("calXMax", 0.8f) - cfg.f("calXMin", 0.2f), 0.05f)
                val spanY = max(cfg.f("calYMax", 0.7f) - cfg.f("calYMin", 0.2f), 0.05f)
                ptrX = (ptrX + dx / spanX * screenW * gain).coerceIn(0f, screenW)
                ptrY = (ptrY + dy / spanY * screenH * gain).coerceIn(0f, screenH)
            }
            relPrevX = srcX; relPrevY = srcY
        }
        hist.addLast(Sample(t, ptrX, ptrY))
        while (hist.size > 12 || (hist.size > 1 && t - hist.first().t > 400)) hist.removeFirst()
        out.pointer(ptrX, ptrY)
    }

    private fun startPinch(t: Long) {
        // Use the pointer position from ~120 ms ago: the fingertip moves while the pinch closes.
        var s: Sample? = null
        for (h in hist) { if (h.t <= t - 120) s = h }
        if (s == null && hist.isNotEmpty()) s = hist.first()
        startX = s?.x ?: ptrX
        startY = s?.y ?: ptrY
        startMapX = mapX(smMcpX); startMapY = mapY(smMcpY)
        ptrX = startX; ptrY = startY
        relPrevX = smMcpX; relPrevY = smMcpY
        pinching = true
        pinchStartT = t
        dragging = false
        longFired = false
    }

    private fun endPinch(t: Long) {
        pinching = false
        relPrevX = Float.NaN; relPrevY = Float.NaN
        if (dragging) {
            dragging = false
            out.dragEnd(ptrX, ptrY)
            return
        }
        if (longFired) { longFired = false; return }
        if (t - pinchStartT < 40) return // noise
        val dbl = cfg.mapping("pinch_double", social) != "NONE"
        if (dbl && pendingTapT >= 0 && t - pendingTapT <= cfg.i("doublePinchMs", 350)) {
            pendingTapT = -1
            fire("pinch_double", pendX, pendY)
        } else if (!dbl) {
            fire("pinch_click", startX, startY)
        } else {
            pendingTapT = t; pendX = startX; pendY = startY
        }
    }

    private fun tickLocked(t: Long) {
        if (pendingTapT >= 0 && t - pendingTapT > cfg.i("doublePinchMs", 350)) {
            pendingTapT = -1
            if (!paused) fire("pinch_click", pendX, pendY)
        }
    }

    private fun handleSwipe(lm: FloatArray, t: Long) {
        palmHist.addLast(Sample(t, lm[18], lm[19]))
        while (palmHist.size > 1 && t - palmHist.first().t > 350) palmHist.removeFirst()
        val a = palmHist.first()
        val dx = lm[18] - a.x
        val dy = lm[19] - a.y
        val dist = hypot(dx, dy)
        if (dist < cfg.f("swipeDistance", 0.18f)) return
        val key = when {
            abs(dx) > abs(dy) * 1.8f -> if (dx > 0) "swipe_right" else "swipe_left"
            abs(dy) > abs(dx) * 1.8f -> if (dy > 0) "swipe_down" else "swipe_up"
            else -> null
        }
        palmHist.clear()
        if (key != null) fireWithCooldown(key, ptrX, ptrY, t)
    }

    private fun restartHoldIfMoving(lm: FloatArray, t: Long) {
        if (palmHist.isEmpty()) return
        val a = palmHist.first()
        if (hypot(lm[18] - a.x, lm[19] - a.y) > 0.06f) poseSince = t
    }

    private fun fireWithCooldown(gesture: String, x: Float, y: Float, t: Long) {
        val action = cfg.mapping(gesture, social)
        if (action == "NONE") return
        if (t - lastDiscrete < cooldownMs()) return
        lastDiscrete = t
        fire(gesture, x, y)
    }

    private fun fire(gesture: String, x: Float, y: Float) {
        val action = cfg.mapping(gesture, social)
        if (action == "NONE" || paused) return
        out.action(action, gesture, x, y)
    }

    private fun releaseAllLocked() {
        if (dragging) out.dragEnd(ptrX, ptrY)
        dragging = false
        pinching = false
        fingerPinch = -1
        longFired = false
        pendingTapT = -1
        candidate = Pose.NONE; candidateCount = 0; stablePose = Pose.NONE; holdFired = true
        repeatKey = null
        palmHist.clear(); hist.clear()
        haveSm = false
        relPrevX = Float.NaN; relPrevY = Float.NaN
        lastSeen = 0L
    }
}
