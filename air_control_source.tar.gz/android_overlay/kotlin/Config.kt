package __PKG__

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Native source of truth for settings. Stored as one JSON string in private SharedPreferences.
 * Stored values are merged over defaults, so Flutter always receives a complete map.
 *
 * Gesture -> action maps: "mapping" (normal) and "socialMapping" (used while Social mode is active).
 * Any number of gestures may map to the same action.
 */
class Config(stored: JSONObject) {
    val json: JSONObject = merge(stored)

    fun f(k: String, d: Float): Float = json.optDouble(k, d.toDouble()).toFloat()
    fun i(k: String, d: Int): Int = json.optInt(k, d)
    fun b(k: String, d: Boolean): Boolean = json.optBoolean(k, d)
    fun s(k: String, d: String): String = json.optString(k, d)

    fun list(k: String): Set<String> {
        val a = json.optJSONArray(k) ?: return emptySet()
        val out = LinkedHashSet<String>()
        for (n in 0 until a.length()) {
            val v = a.optString(n, "")
            if (v.isNotEmpty()) out.add(v)
        }
        return out
    }

    /** Action for a gesture. In social mode the social profile wins, then the normal mapping. */
    fun mapping(gesture: String, social: Boolean = false): String {
        if (social) {
            val sv = json.optJSONObject("socialMapping")?.optString(gesture, "") ?: ""
            val v = if (sv.isNotEmpty()) sv else (DEFAULT_SOCIAL[gesture] ?: "")
            if (v.isNotEmpty()) return clean(v)
        }
        val nv = json.optJSONObject("mapping")?.optString(gesture, "") ?: ""
        return clean(if (nv.isNotEmpty()) nv else (DEFAULT_MAPPING[gesture] ?: "NONE"))
    }

    companion object {
        /** Actions that no longer exist (pausing was removed) read as "do nothing". */
        private val REMOVED = setOf("PAUSE_TOGGLE")
        private fun clean(a: String) = if (a in REMOVED) "NONE" else a

        val DEFAULT_MAPPING = linkedMapOf(
            "pinch_click" to "TAP",
            "pinch_double" to "DOUBLE_TAP",
            "pinch_hold" to "LONG_PRESS",
            "pinch_drag" to "DRAG",
            "pinch_middle" to "BACK",
            "pinch_ring" to "HOME",
            "pinch_pinky" to "RECENTS",
            "swipe_up" to "SCROLL_DOWN",
            "swipe_down" to "SCROLL_UP",
            "swipe_left" to "BACK",
            "swipe_right" to "RECENTS",
            "open_palm_hold" to "HOME",
            "fist_hold" to "NONE",
            "peace_hold" to "PLAY_PAUSE",
            "three_hold" to "NOTIFICATIONS",
            "rock_hold" to "QUICK_SETTINGS",
            "call_hold" to "NEXT_TRACK",
            "pinky_hold" to "PREV_TRACK",
            "thumbs_up_hold" to "VOLUME_UP",
            "thumbs_down_hold" to "VOLUME_DOWN"
        )

        /** Only the gestures that differ in Social mode; the rest fall back to the normal mapping. */
        val DEFAULT_SOCIAL = linkedMapOf(
            "pinch_double" to "SOCIAL_LIKE",
            "pinch_hold" to "SOCIAL_PLAY_PAUSE",
            "swipe_up" to "SOCIAL_NEXT",
            "swipe_down" to "SOCIAL_PREV",
            "swipe_right" to "SOCIAL_COMMENTS",
            "peace_hold" to "SOCIAL_LIKE",
            "three_hold" to "SOCIAL_COMMENTS",
            "rock_hold" to "SOCIAL_SHARE",
            "call_hold" to "SOCIAL_COMMENTS_SCROLL_DOWN",
            "pinky_hold" to "SOCIAL_COMMENTS_SCROLL_UP",
            "fist_hold" to "TOGGLE_VIDEO_STYLE"
        )

        val DEFAULT_SOCIAL_APPS = listOf(
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.instagram.android",
            "com.google.android.youtube", "com.facebook.katana", "com.facebook.lite"
        )

        fun defaults(): JSONObject {
            val j = JSONObject()
            j.put("smoothing", 0.5)
            j.put("minDetection", 0.5)
            j.put("minPresence", 0.5)
            j.put("minTracking", 0.5)
            j.put("pointerMode", "absolute")
            j.put("pointerSpeed", 1.0)
            j.put("pointerAccel", 0.3)
            j.put("calXMin", 0.2)
            j.put("calXMax", 0.8)
            j.put("calYMin", 0.2)
            j.put("calYMax", 0.7)
            j.put("pinchSensitivity", 0.5)
            j.put("longPressMs", 600)
            j.put("doublePinchMs", 350)
            j.put("swipeDistance", 0.18)
            j.put("scrollSpeed", 1.0)
            j.put("cooldownMs", 900)
            j.put("holdMs", 800)
            j.put("repeatMs", 250)          // volume etc. repeat interval while the gesture is held
            j.put("lostTimeoutMs", 500)     // a held drag is released if the hand is gone this long
            j.put("dominantHand", "any")
            j.put("showPointer", true)
            j.put("clickFeedback", true)
            j.put("maxFps", 20)
            j.put("appPackage", "")
            // per-app control
            j.put("appMode", "all")                    // all | selected
            j.put("outsideBehavior", "gestures_off")   // gestures_off | camera_off
            j.put("apps", JSONArray())
            // social mode
            j.put("socialMode", "off")                 // off | on | auto
            j.put("videoStyle", "short")               // short | long
            j.put("socialApps", JSONArray(DEFAULT_SOCIAL_APPS))
            j.put("floatButton", true)         // small always-on-screen start/stop button
            j.put("floatX", 0.90)              // position as fractions of the screen (top-left of the button)
            j.put("floatY", 0.30)
            j.put("socialCommentX", 0.92)
            j.put("socialCommentY", 0.60)
            j.put("socialShareX", 0.92)
            j.put("socialShareY", 0.76)
            val m = JSONObject()
            for ((k, v) in DEFAULT_MAPPING) m.put(k, v)
            j.put("mapping", m)
            val sm = JSONObject()
            for ((k, v) in DEFAULT_SOCIAL) sm.put(k, v)
            j.put("socialMapping", sm)
            return j
        }

        private fun mergeMap(out: JSONObject, stored: JSONObject, key: String, defs: Map<String, String>) {
            val sm = stored.optJSONObject(key) ?: return
            val om = out.getJSONObject(key)
            val mk = sm.keys()
            while (mk.hasNext()) {
                val g = mk.next()
                om.put(g, sm.optString(g, defs[g] ?: "NONE"))
            }
        }

        private fun merge(stored: JSONObject): JSONObject {
            val out = defaults()
            val keys = stored.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                if (k == "mapping" || k == "socialMapping") continue
                if (out.has(k)) out.put(k, stored.get(k))
            }
            mergeMap(out, stored, "mapping", DEFAULT_MAPPING)
            mergeMap(out, stored, "socialMapping", DEFAULT_SOCIAL)
            return out
        }

        private fun prefs(ctx: Context) =
            ctx.applicationContext.getSharedPreferences("air_control", Context.MODE_PRIVATE)

        fun load(ctx: Context): Config {
            val raw = prefs(ctx).getString("config", null)
            val j = try { if (raw == null) JSONObject() else JSONObject(raw) } catch (e: Exception) { JSONObject() }
            return Config(j)
        }

        /** Changes one key (used by the service to remember the floating button position). */
        fun update(ctx: Context, key: String, value: Any) {
            val j = load(ctx).json
            j.put(key, value)
            prefs(ctx).edit().putString("config", j.toString()).apply()
        }

        /** Returns false if the JSON is invalid. */
        fun save(ctx: Context, raw: String): Boolean {
            return try {
                val merged = Config(JSONObject(raw)).json
                prefs(ctx).edit().putString("config", merged.toString()).apply()
                true
            } catch (e: Exception) {
                false
            }
        }
    }
}
