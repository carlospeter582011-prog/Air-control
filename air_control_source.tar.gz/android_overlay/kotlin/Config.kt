package __PKG__

import android.content.Context
import org.json.JSONObject

/**
 * Native source of truth for settings. Stored as one JSON string in private SharedPreferences.
 * Stored values are merged over DEFAULTS, so Flutter always receives a complete map.
 */
class Config(stored: JSONObject) {
    val json: JSONObject = merge(stored)

    fun f(k: String, d: Float): Float = json.optDouble(k, d.toDouble()).toFloat()
    fun i(k: String, d: Int): Int = json.optInt(k, d)
    fun b(k: String, d: Boolean): Boolean = json.optBoolean(k, d)
    fun s(k: String, d: String): String = json.optString(k, d)

    fun mapping(gesture: String): String {
        val v = json.optJSONObject("mapping")?.optString(gesture, "") ?: ""
        return if (v.isNotEmpty()) v else (DEFAULT_MAPPING[gesture] ?: "NONE")
    }

    companion object {
        val DEFAULT_MAPPING = linkedMapOf(
            "pinch_click" to "TAP",
            "pinch_double" to "DOUBLE_TAP",
            "pinch_hold" to "LONG_PRESS",
            "pinch_drag" to "DRAG",
            "swipe_up" to "SCROLL_DOWN",
            "swipe_down" to "SCROLL_UP",
            "swipe_left" to "BACK",
            "swipe_right" to "RECENTS",
            "open_palm_hold" to "HOME",
            "fist_hold" to "PAUSE_TOGGLE",
            "peace_hold" to "PLAY_PAUSE",
            "thumbs_up_hold" to "VOLUME_UP",
            "thumbs_down_hold" to "VOLUME_DOWN"
        )

        fun defaults(): JSONObject {
            val j = JSONObject()
            j.put("smoothing", 0.5)
            j.put("minDetection", 0.5)
            j.put("minPresence", 0.5)
            j.put("minTracking", 0.5)
            j.put("pointerMode", "absolute")
            j.put("pointerSpeed", 1.0)
            j.put("pointerAccel", 0.3)
            j.put("calXMin", 0.2)
            j.put("calXMax", 0.8)
            j.put("calYMin", 0.2)
            j.put("calYMax", 0.7)
            j.put("pinchSensitivity", 0.5)
            j.put("longPressMs", 600)
            j.put("doublePinchMs", 350)
            j.put("swipeDistance", 0.18)
            j.put("scrollSpeed", 1.0)
            j.put("cooldownMs", 900)
            j.put("holdMs", 800)
            j.put("lostTimeoutMs", 500)
            j.put("dominantHand", "any")
            j.put("showPointer", true)
            j.put("clickFeedback", true)
            j.put("maxFps", 20)
            j.put("appPackage", "")
            val m = JSONObject()
            for ((k, v) in DEFAULT_MAPPING) m.put(k, v)
            j.put("mapping", m)
            return j
        }

        private fun merge(stored: JSONObject): JSONObject {
            val out = defaults()
            val keys = stored.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                if (k == "mapping") {
                    val sm = stored.optJSONObject("mapping") ?: continue
                    val om = out.getJSONObject("mapping")
                    val mk = sm.keys()
                    while (mk.hasNext()) {
                        val g = mk.next()
                        om.put(g, sm.optString(g, DEFAULT_MAPPING[g] ?: "NONE"))
                    }
                } else if (out.has(k)) {
                    out.put(k, stored.get(k))
                }
            }
            return out
        }

        private fun prefs(ctx: Context) =
            ctx.applicationContext.getSharedPreferences("air_control", Context.MODE_PRIVATE)

        fun load(ctx: Context): Config {
            val raw = prefs(ctx).getString("config", null)
            val j = try { if (raw == null) JSONObject() else JSONObject(raw) } catch (e: Exception) { JSONObject() }
            return Config(j)
        }

        /** Returns false if the JSON is invalid. */
        fun save(ctx: Context, raw: String): Boolean {
            return try {
                val merged = Config(JSONObject(raw)).json
                prefs(ctx).edit().putString("config", merged.toString()).apply()
                true
            } catch (e: Exception) {
                false
            }
        }
    }
}
