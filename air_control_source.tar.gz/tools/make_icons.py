#!/usr/bin/env python3
"""Draws the Air Control logo and writes every icon the app needs. Run: python3 tools/make_icons.py"""
import math
import os
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
RES = os.path.join(ROOT, "android_overlay", "res")
S = 1024  # master canvas


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def gradient(size, c1, c2, angle_deg=70):
    w, h = size
    img = Image.new("RGB", size)
    px = img.load()
    a = math.radians(angle_deg)
    dx, dy = math.cos(a), math.sin(a)
    mx = abs(dx) * w + abs(dy) * h
    for y in range(h):
        for x in range(w):
            t = ((x - w / 2) * dx + (y - h / 2) * dy) / mx + 0.5
            px[x, y] = lerp(c1, c2, max(0.0, min(1.0, t)))
    return img


def hand_mask():
    """White-on-black silhouette of an open hand with a gap above the index finger for the pointer dot."""
    m = Image.new("L", (S * 2, S * 2), 0)
    d = ImageDraw.Draw(m)
    k = 2  # supersample

    def rr(x0, y0, x1, y1, r):
        d.rounded_rectangle([x0 * k, y0 * k, x1 * k, y1 * k], radius=r * k, fill=255)

    rr(372, 520, 652, 772, 96)                      # palm
    for cx, top, bottom in [(412, 372, 580), (484, 296, 580), (556, 332, 580), (622, 420, 592)]:
        rr(cx - 31, top, cx + 31, bottom, 31)       # fingers
    # thumb: capsule rotated about its start
    th = Image.new("L", (S * 2, S * 2), 0)
    td = ImageDraw.Draw(th)
    td.rounded_rectangle([0, 0, 64 * k, 230 * k], radius=32 * k, fill=255)
    th = th.crop((0, 0, 64 * k, 230 * k)).rotate(38, expand=True, resample=Image.BICUBIC)
    m.paste(255, (320 * k - th.width // 2 + 20 * k, 590 * k - th.height // 2 + 10 * k), th)
    return m.resize((S, S), Image.LANCZOS)


def layer_foreground(mask, color_top=(120, 235, 255), color_bot=(0, 150, 230)):
    fg = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    grad = gradient((S, S), color_top, color_bot, 80).convert("RGBA")
    fg.paste(grad, (0, 0), mask)
    # pointer dot + ring above the index finger
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    cx, cy = 412, 300
    gd.ellipse([cx - 44, cy - 44, cx + 44, cy + 44], fill=(120, 235, 255, 140))
    glow = glow.filter(ImageFilter.GaussianBlur(18))
    fg = Image.alpha_composite(glow, fg)
    d = ImageDraw.Draw(fg)
    d.ellipse([cx - 34, cy - 34, cx + 34, cy + 34], outline=(255, 255, 255, 255), width=9)
    d.ellipse([cx - 13, cy - 13, cx + 13, cy + 13], fill=(255, 255, 255, 255))
    return fg


def monochrome(mask):
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out.paste((255, 255, 255, 255), (0, 0), mask)
    d = ImageDraw.Draw(out)
    cx, cy = 412, 300
    d.ellipse([cx - 34, cy - 34, cx + 34, cy + 34], outline=(255, 255, 255, 255), width=9)
    d.ellipse([cx - 13, cy - 13, cx + 13, cy + 13], fill=(255, 255, 255, 255))
    return out


def fit(img, scale):
    """Shrinks the layer into the centre so it stays inside the adaptive-icon safe zone."""
    c = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    n = int(S * scale)
    r = img.resize((n, n), Image.LANCZOS)
    c.paste(r, ((S - n) // 2, (S - n) // 2), r)
    return c


def zoom(img, f):
    """Enlarges the layer about its centre (crops the empty margin)."""
    n = int(S * f)
    r = img.resize((n, n), Image.LANCZOS)
    o = (n - S) // 2
    return r.crop((o, o, o + S, o + S))


def rounded_tile(img_rgb, radius_frac=0.22):
    s = img_rgb.size[0]
    mask = Image.new("L", (s * 2, s * 2), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, s * 2 - 1, s * 2 - 1], radius=int(s * 2 * radius_frac), fill=255)
    mask = mask.resize((s, s), Image.LANCZOS)
    out = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    out.paste(img_rgb, (0, 0), mask)
    return out


def save(img, path, size):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.resize((size, size), Image.LANCZOS).save(path)


def main():
    mask = hand_mask()
    fg = layer_foreground(mask)          # hand is ~52% of the canvas: inside the 61% adaptive safe zone
    mono = monochrome(mask)
    bg = gradient((S, S), (8, 22, 42), (14, 74, 110), 65)

    dens_fg = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
    dens_legacy = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
    for dn, sz in dens_fg.items():
        save(fg, os.path.join(RES, f"mipmap-{dn}", "ic_launcher_foreground.png"), sz)
        save(mono, os.path.join(RES, f"mipmap-{dn}", "ic_launcher_monochrome.png"), sz)

    # legacy full icon = background tile + hand (hand a little larger than the adaptive version)
    full = Image.alpha_composite(bg.convert("RGBA"), zoom(layer_foreground(mask), 1.35))
    tile = rounded_tile(full.convert("RGB"))
    for dn, sz in dens_legacy.items():
        save(tile, os.path.join(RES, f"mipmap-{dn}", "ic_launcher.png"), sz)

    # in-app logo
    os.makedirs(os.path.join(ROOT, "assets"), exist_ok=True)
    save(tile, os.path.join(ROOT, "assets", "logo.png"), 512)
    print("icons written")


if __name__ == "__main__":
    main()
