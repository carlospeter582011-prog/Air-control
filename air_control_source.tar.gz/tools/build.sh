#!/usr/bin/env bash
# Builds Air Control APKs from this source tree.
# Needs: Flutter (stable, Dart >= 3.3), JDK 17+, Android SDK (platform 35, build-tools), internet access
# to pub.dev, Google Maven, storage.googleapis.com (model download). Run from anywhere.
#
#   tools/build.sh            # debug + release APK, runs tests first
#   SKIP_TESTS=1 tools/build.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG="com.carlos.aircontrol"
PKG_DIR="${PKG//./\/}"
MODEL_URL="https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"
OUT="$ROOT/dist"

cd "$ROOT"
echo "== flutter doctor"
flutter --version
flutter doctor -v || true

echo "== generate Android platform project"
if [ ! -d android ]; then
  flutter create --platforms android --org com.carlos --project-name air_control --no-pub .
fi

APP=android/app
SRC="$APP/src/main"

echo "== apply overlay"
rm -f "$APP/build.gradle" "$APP/build.gradle.kts"
sed "s/__PKG__/$PKG/g" android_overlay/app_build.gradle.kts > "$APP/build.gradle.kts"

rm -rf "$SRC/kotlin" "$SRC/java"
mkdir -p "$SRC/kotlin/$PKG_DIR" "$APP/src/test/kotlin/$PKG_DIR" "$SRC/res/xml" "$SRC/assets"
for f in android_overlay/kotlin/*.kt; do
  sed "s/__PKG__/$PKG/g" "$f" > "$SRC/kotlin/$PKG_DIR/$(basename "$f")"
done
for f in android_overlay/test_kotlin/*.kt; do
  sed "s/__PKG__/$PKG/g" "$f" > "$APP/src/test/kotlin/$PKG_DIR/$(basename "$f")"
done
cp android_overlay/res/xml/*.xml "$SRC/res/xml/"
cp android_overlay/res/values/air_strings.xml "$SRC/res/values/air_strings.xml"
cp android_overlay/AndroidManifest.xml "$SRC/AndroidManifest.xml"

echo "== hand landmarker model"
if [ ! -s "$SRC/assets/hand_landmarker.task" ]; then
  curl -fL --retry 3 -o "$SRC/assets/hand_landmarker.task" "$MODEL_URL"
fi
SZ=$(stat -c %s "$SRC/assets/hand_landmarker.task")
[ "$SZ" -gt 1000000 ] || { echo "model download looks wrong ($SZ bytes)"; exit 1; }
echo "model bytes: $SZ"

echo "== dependencies + static analysis"
flutter pub get
flutter analyze --no-fatal-infos

if [ -z "${SKIP_TESTS:-}" ]; then
  echo "== Dart tests"
  flutter test
  echo "== Kotlin gesture-engine unit tests"
  (cd android && ./gradlew :app:testDebugUnitTest --no-daemon)
fi

echo "== build APKs"
flutter build apk --debug --target-platform android-arm64
flutter build apk --release --target-platform android-arm64

mkdir -p "$OUT"
cp build/app/outputs/flutter-apk/app-debug.apk "$OUT/air_control-debug.apk"
cp build/app/outputs/flutter-apk/app-release.apk "$OUT/air_control-release.apk"

echo "== verify"
for a in "$OUT"/*.apk; do
  [ -s "$a" ] || { echo "EMPTY: $a"; exit 1; }
  echo "$(basename "$a"): $(stat -c %s "$a") bytes"
done
if command -v aapt >/dev/null 2>&1 || [ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then
  AAPT="$(command -v aapt || ls "${ANDROID_HOME:-$ANDROID_SDK_ROOT}"/build-tools/*/aapt | tail -1)"
  "$AAPT" dump badging "$OUT/air_control-release.apk" | grep -E "^package|sdkVersion|uses-permission" || true
fi
echo "Done. APKs in $OUT"
