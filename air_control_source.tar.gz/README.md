# Air Control

Private Android app that lets you control your phone with hand gestures seen by the front camera.
Flutter UI + Kotlin native layer, MediaPipe Hand Landmarker on device, no internet permission, no ads, no analytics.

> **Status: source complete, APK not yet built.** See `docs/TEST_REPORT.md` for exactly what was and was not verified.

- Package: `com.carlos.aircontrol` · version 1.0.0 (1) · minSdk 26 (Android 8.0) · arm64-v8a only
- Hand model: `hand_landmarker.task` (float16) downloaded at build time from Google's MediaPipe model storage

## Build the APK

**Option A – your computer** (Flutter stable + JDK 17 + Android SDK 35 installed):

```bash
bash tools/build.sh
# APKs: dist/air_control-debug.apk, dist/air_control-release.apk
```

The script generates the Android project, applies `android_overlay/`, downloads the model, runs analyze + tests, builds both APKs.
Use `SKIP_TESTS=1 bash tools/build.sh` to skip tests.

**Option B – GitHub Actions (nothing to install):** push this folder to a new private GitHub repo (branch `main`),
open Actions → "Build Air Control APK" → Run workflow, download the `air-control-apks` artifact.

The release APK is signed with the debug key, which is fine for sideloading. Use your own keystore if you want updates signed consistently across machines.

## Install

1. Copy `air_control-release.apk` to the phone, open it, allow "install unknown apps" for your file manager/browser when asked.
2. Open Air Control.

## First run

Home → **Permissions and setup**:
1. **Camera** – allow.
2. **Accessibility** – Settings → Accessibility → Installed apps → *Air Control hand gestures* → On. If it is greyed out (Android 13+ sideloaded apps): Settings → Apps → Air Control → ⋮ → **Allow restricted settings**, then retry.
3. **Notifications** – allow (shows the camera-on indicator with Pause/Stop).
4. Optional: *Modify system settings* (brightness only) and unrestricted battery.

Then **Live test and calibration** (safe test mode) → calibrate four corners → back to Home → **Start tracking**.
Start tracking only while the app is visible; Android 14+ does not allow starting camera services from the background.

## Background use and Samsung (Galaxy A23, One UI)

- Settings → Apps → Air Control → Battery → **Unrestricted**
- Settings → Battery → Background usage limits → **Never sleeping apps** → add Air Control; turn off "Put unused apps to sleep"
- Tracking does not restart by itself after a reboot, a crash or Android killing it. The app shows why it stopped; press Start again.

## Gesture reference (defaults, all remappable)

| Gesture | Action |
|---|---|
| Index finger up, moving | Move pointer |
| Quick pinch | Tap |
| Two quick pinches | Double tap |
| Pinch and hold (still) | Long press |
| Pinch and move | Drag and drop (released when you open the pinch, lose the hand, pause or stop) |
| Open palm sweep up / down | Scroll down / up |
| Open palm sweep left / right | Back / Recents |
| Open palm held | Home |
| Fist held | Pause / resume |
| Two fingers held | Play / pause |
| Thumbs up / down held | Volume up / down |

Held poses fire once, then need a cooldown and a new pose. A hand pose held longer never repeats an action.

## Troubleshooting

- *Nothing happens in other apps*: accessibility off, test mode on, or the screen is protected (banking apps, lock screen, some system dialogs ignore injected touches by design).
- *Jittery pointer*: raise Smoothing, improve light, recalibrate.
- *Accidental taps*: lower Pinch sensitivity, raise Cooldown, put a plain background behind your hand.
- *Stops by itself*: check the reason on Home; apply the Samsung battery settings.
- *Stuck touch*: press Pause or Stop; it is released immediately.

## Limitations (by design or by Android)

- No brightness change without the manual "Modify system settings" grant.
- Media keys only reach apps that handle them. Volume changes the media stream.
- "Focus and tap text field" is not implemented: it would need screen-content access, which this app deliberately does not request. Point and pinch instead.
- Screenshot / lock / power-menu actions need Android 9+ and may be blocked by the phone maker.
- One hand only in 1.0; two-hand gestures are not implemented.
- Magnification: opens Accessibility settings only; there is no direct toggle API.
- Camera use stops when another app takes the camera, and Android may stop it under battery limits.
- The pointer dot is an accessibility overlay; on some apps/screens Android hides it.

## Privacy

Camera frames are analysed in memory and discarded. The release APK declares no INTERNET permission (Flutter adds it to debug builds only, for hot reload). Settings are stored privately on the phone. The accessibility service is declared without `canRetrieveWindowContent` and without event types, so it cannot read your screen. The camera-on notification cannot be hidden.

## Layout

```
lib/                      Flutter UI (setup wizard, live test + calibration, settings, mapping editor, help)
android_overlay/kotlin/   GestureEngine (pure logic), TrackingService (CameraX + MediaPipe), AirAccessibilityService, MainActivity, Config, Bridge
android_overlay/          manifest, accessibility config, Gradle file applied over the generated project
tools/build.sh            one-shot build + verify
.github/workflows/        CI build
docs/TEST_REPORT.md       what was verified and what was not
```
